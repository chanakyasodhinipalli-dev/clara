from __future__ import annotations
from typing import List, Optional, Literal, Dict
from pydantic import BaseModel
import pandas as pd
from openpyxl import load_workbook
from dataclasses import dataclass
import re
from mapping import HELP_TEXT

DType = Literal["text","number","email","enum","date","bool"]

class Field(BaseModel):
    sheet: str
    name: str
    key: str
    required: bool
    dtype: DType
    enum_values: Optional[List[str]] = None
    help: Optional[str] = None

class TemplateSchema(BaseModel):
    fields: List[Field]

def infer_dtype(header: str) -> DType:
    # simple heuristics by header hints
    h = header.lower()
    if "email" in h:
        return "email"
    if "date" in h or "yyyy" in h:
        return "date"
    if "enabled" in h or h.startswith("is_") or "yes/no" in h:
        return "bool"
    if "count" in h or "number" in h or "volume" in h:
        return "number"
    if "type" in h or "classification" in h or "enum" in h:
        return "enum"
    return "text"

def normalize_key(name: str) -> str:
    return re.sub(r'[^a-z0-9_]+','_', name.strip().lower().replace(" ", "_")).strip("_")

def read_enum_values(ws) -> Dict[str, List[str]]:
    # optional sheet named 'Dictionaries' listing enums as:
    # Column A: Field Key, Columns B..: allowed values
    enums: Dict[str, List[str]] = {}
    if ws is None:
        return enums
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or not row[0]:
            continue
        key = str(row[0]).strip()
        values = [str(v).strip() for v in row[1:] if v not in (None, "")]
        if values:
            enums[key] = values
    return enums

def parse_workbook(path: str) -> TemplateSchema:
    wb = load_workbook(path, data_only=True)
    enums = read_enum_values(wb["Dictionaries"]) if "Dictionaries" in wb.sheetnames else {}

    fields: List[Field] = []
    for sheet in wb.sheetnames:
        if sheet == "Dictionaries":
            continue
        ws = wb[sheet]
        # Assume first row is header
        headers = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
        if not any(headers):
            continue
        for head in headers:
            if not head:
                continue
            name = str(head)
            required = name.endswith("*") or "(required)" in name.lower()
            clean = name.replace("*", "").replace("(required)", "").strip()
            key = normalize_key(clean)
            dtype = infer_dtype(clean)
            help_text = HELP_TEXT.get(key)
            enum_values = enums.get(key) if dtype == "enum" else None
            fields.append(Field(sheet=sheet, name=clean, key=key, required=required,
                                dtype=dtype, enum_values=enum_values, help=help_text))
    return TemplateSchema(fields=fields)
