from excel_schema import TemplateSchema, Field
from dor_validator import dor_check

def test_dor_rules():
    schema = TemplateSchema(fields=[
        Field(sheet='Summary', name='Partner Name', key='partner_name', required=True, dtype='text'),
        Field(sheet='Integration', name='Kafka Enabled', key='kafka_enabled', required=False, dtype='bool'),
        Field(sheet='Kafka', name='Kafka Topic', key='kafka_topic', required=False, dtype='text'),
    ])
    pct, errs = dor_check(schema, {'partner_name': 'Acme', 'kafka_enabled':'yes'})
    assert any('kafka_topic' in e for e in errs)
