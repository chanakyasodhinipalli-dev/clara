import os
from excel_schema import parse_workbook

def test_parse_template():
    path = os.path.join('assets','templates','intake_template.xlsx')
    schema = parse_workbook(path)
    assert len(schema.fields) > 10
    required = [f for f in schema.fields if f.required]
    assert any(f.key == 'partner_name' for f in required)
