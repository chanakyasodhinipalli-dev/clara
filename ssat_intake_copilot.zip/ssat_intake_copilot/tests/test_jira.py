import httpx
import types
from jira_client import create_issue

class DummyResp:
    def __init__(self, status_code, data):
        self.status_code = status_code
        self._data = data
        self.text = 'x'
    def json(self):
        return self._data

def test_create_issue_monkeypatch(monkeypatch):
    import jira_client
    # fake settings
    monkeypatch.setenv('JIRA_BASE_URL', 'https://example.atlassian.net')
    monkeypatch.setenv('JIRA_EMAIL', 'a@b.c')
    monkeypatch.setenv('JIRA_API_TOKEN', 'token')
    from importlib import reload
    reload(jira_client)
    def fake_post(url, headers=None, json=None):
        return DummyResp(201, {'key':'SSAT-123'})
    client = types.SimpleNamespace(post=fake_post)
    monkeypatch.setattr(httpx, 'Client', lambda timeout: client)
    key, url = jira_client.create_issue('s','d')
    assert key == 'SSAT-123'
    assert url.endswith('/browse/SSAT-123')
