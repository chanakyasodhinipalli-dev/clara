from __future__ import annotations
from typing import Dict, List

# Minimal bootstrap help and conditional rules
HELP_TEXT: Dict[str, str] = {
    "partner_name": "Official name of the partner or application requesting onboarding.",
    "contact_email": "Primary contact email for coordination (format: user@example.com).",
    "kafka_enabled": "Select 'Yes' if Kafka integration is required for this intake.",
    "kafka_topic": "Provide the Kafka topic to be provisioned/used (e.g., ssat.partner.ingest).",
    "integration_type": "Pick from enum values: API, NAS, Kafka.",
    "data_classification": "Data classification level (Public, Internal, Confidential, Restricted).",
}

# Conditional requirements
CONDITIONAL_RULES: Dict[str, Dict] = {
    "kafka_topic": {"requires": ["kafka_enabled"], "predicate_truthy": True},
}
