from __future__ import annotations
from typing import Dict

class SessionStore:
    """Simple in-memory session store (Streamlit's session_state compatible)."""
    def __init__(self):
        self._state: Dict[str, object] = {}

    def get(self, key: str, default=None):
        return self._state.get(key, default)

    def set(self, key: str, value):
        self._state[key] = value

    def reset(self):
        self._state.clear()
