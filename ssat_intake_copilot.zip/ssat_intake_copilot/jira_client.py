from __future__ import annotations
import base64
from typing import Tuple, Optional
import httpx
from config import settings
import os

class JiraError(Exception):
    pass

def _auth_headers() -> dict:
    if not settings.JIRA_EMAIL or not settings.JIRA_API_TOKEN:
        raise JiraError("Jira credentials are not configured")
    token = f"{settings.JIRA_EMAIL}:{settings.JIRA_API_TOKEN}".encode()
    return {
        "Authorization": "Basic " + base64.b64encode(token).decode(),
        "Accept": "application/json"
    }

def create_issue(summary: str, description: str, fields: Optional[dict]=None) -> Tuple[str, str]:
    if not settings.JIRA_BASE_URL:
        raise JiraError("Jira base URL is not configured")
    payload = {
        "fields": {
            "project": {"key": settings.JIRA_PROJECT_KEY},
            "summary": summary,
            "description": description,
            "issuetype": {"name": settings.JIRA_ISSUE_TYPE},
        }
    }
    if fields:
        payload["fields"].update(fields)
    url = settings.JIRA_BASE_URL.rstrip("/") + "/rest/api/3/issue"
    with httpx.Client(timeout=30.0) as client:
        resp = client.post(url, headers=_auth_headers(), json=payload)
        if resp.status_code not in (200,201):
            raise JiraError(f"Create issue failed: {resp.status_code} {resp.text}")
        data = resp.json()
        key = data.get("key")
        issue_url = settings.JIRA_BASE_URL.rstrip("/") + f"/browse/{key}"
        return key, issue_url

def attach_file(issue_key: str, path: str) -> None:
    url = settings.JIRA_BASE_URL.rstrip("/") + f"/rest/api/3/issue/{issue_key}/attachments"
    headers = _auth_headers()
    headers["X-Atlassian-Token"] = "no-check"
    filename = os.path.basename(path)
    with open(path, "rb") as f, httpx.Client(timeout=60.0) as client:
        resp = client.post(url, headers=headers, files={"file": (filename, f, "application/octet-stream")})
        if resp.status_code not in (200,201):
            raise JiraError(f"Attach file failed: {resp.status_code} {resp.text}")
