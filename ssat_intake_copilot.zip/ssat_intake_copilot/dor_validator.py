from __future__ import annotations
from typing import Dict, List, Tuple
from excel_schema import TemplateSchema, Field
from utils import ValidationError
from mapping import CONDITIONAL_RULES

def _validate_value(field: Field, value) -> List[str]:
    errs: List[str] = []
    if value is None or (isinstance(value, str) and not value.strip()):
        if field.required:
            errs.append("Required value missing")
        return errs
    v = str(value).strip()
    if field.dtype == "email":
        if "@" not in v or "." not in v.split("@")[-1]:
            errs.append("Invalid email format")
    elif field.dtype == "number":
        try:
            float(v)
        except Exception:
            errs.append("Not a number")
    elif field.dtype == "bool":
        if v.lower() not in {"yes","no","true","false","1","0"}:
            errs.append("Expected boolean (yes/no)")
    elif field.dtype == "enum":
        if field.enum_values and v not in field.enum_values:
            errs.append(f"Value must be one of: {', '.join(field.enum_values)}")
    return errs

def cross_field_rules(answers: Dict[str, str]) -> List[str]:
    errs: List[str] = []
    # kafka_topic requires kafka_enabled truthy
    rule = CONDITIONAL_RULES.get("kafka_topic")
    if rule:
        dep = rule["requires"][0]
        if answers.get(dep, "").strip().lower() in {"yes","true","1"} and not answers.get("kafka_topic"):
            errs.append("Kafka is enabled but 'kafka_topic' is missing")
    return errs

def dor_check(schema: TemplateSchema, answers: Dict[str, str]) -> Tuple[float, List[str]]:
    required = [f for f in schema.fields if f.required]
    filled = 0
    errors: List[str] = []
    for f in required:
        val = answers.get(f.key)
        v_errs = _validate_value(f, val)
        errors.extend([f"{f.key}: {e}" for e in v_errs])
        if not v_errs and val not in (None, ""):
            filled += 1
    errors.extend(cross_field_rules(answers))
    pct = (filled / max(len(required),1)) * 100.0
    return pct, errors
