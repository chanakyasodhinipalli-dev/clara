from __future__ import annotations
from typing import Dict, Tuple, List
from mapping import HELP_TEXT

COMMANDS = {"/help","/back","/skip","/summary","/export"}

def handle(user_text: str, current_field_key: str | None, enum_values: List[str] | None) -> Tuple[str, Dict]:
    t = user_text.strip()
    meta: Dict = {}
    if t in COMMANDS:
        return f"Command recognized: {t}", {"intent": t.lstrip("/")}
    if t.lower().startswith("help") or t.lower().startswith("/help"):
        tip = HELP_TEXT.get(current_field_key or "", "No help available.")
        return f"Help: {tip}", meta
    if enum_values:
        # strict match or ask to pick
        if t in enum_values:
            return "Noted.", meta
        else:
            opts = ", ".join(enum_values)
            return f"Please choose one of: {opts}", meta
    # accept value as-is
    return "Noted.", meta
