from __future__ import annotations
import streamlit as st
import pandas as pd
from io import BytesIO
from typing import Optional, List
from openpyxl import load_workbook, Workbook
from config import settings
from excel_schema import parse_workbook, TemplateSchema
from intake_engine import ChatState, build_prompt_queue, next_field, apply_answer, summary
from dor_validator import dor_check
from deterministic_path.rule_engine import handle as rule_handle
from ai_path.ai_controller import respond as ai_respond
from jira_client import create_issue, attach_file
from utils import gen_session_id, now_iso
import structlog
import os
from datetime import datetime

logger = structlog.get_logger()

st.set_page_config(page_title="SSAT Intake Copilot", layout="wide")

if "store" not in st.session_state:
    st.session_state.store = {}
store = st.session_state.store

def get_state() -> ChatState:
    if "chat" not in store:
        store["chat"] = ChatState()
    return store["chat"]

def save_workbook(wb, path: str):
    wb.save(path)

with st.sidebar:
    st.title("SSAT Intake Copilot")
    mode = st.radio("Mode", ["Upload & Validate", "Guided Build"])
    st.caption(f"AI Enabled: **{settings.AI_ENABLED}**")
    uploaded = None
    if mode == "Upload & Validate":
        uploaded = st.file_uploader("Upload Intake Workbook (.xlsx)", type=["xlsx"])
    if st.button("Start New Intake"):
        store.clear()
        st.rerun()

st.header("Chat")
chat_state = get_state()

def load_schema_from_template() -> TemplateSchema:
    tpl_path = os.path.join("assets", "templates", "intake_template.xlsx")
    return parse_workbook(tpl_path)

def load_schema_from_upload(uploaded) -> TemplateSchema:
    with open("uploaded.xlsx", "wb") as f:
        f.write(uploaded.getbuffer())
    return parse_workbook("uploaded.xlsx")

if "schema" not in store:
    if mode == "Upload & Validate" and uploaded:
        store["schema"] = load_schema_from_upload(uploaded)
        st.success("Workbook parsed. Ready to validate.")
    elif mode == "Guided Build":
        store["schema"] = load_schema_from_template()
        st.info("Template loaded. Let's begin.")
    else:
        st.stop()

schema: TemplateSchema = store["schema"]

if "queue" not in store:
    fields = build_prompt_queue(schema)
    store["queue"] = [f.key for f in fields]
    chat_state.reset(store["queue"])

# Chat transcript area
placeholder = st.container()
with placeholder:
    field = next_field(chat_state, schema)
    if field:
        st.write(f"**Field:** {field.name}  
_Type_: {field.dtype}" + (f"  
_Options_: {', '.join(field.enum_values)}" if field.enum_values else ""))
        user_text = st.text_input("Your answer (/help, /back, /skip, /summary, /export)", key=f"input_{field.key}")
        if st.button("Send", key=f"send_{field.key}"):
            if user_text.strip() == "/back":
                chat_state.current_index = max(0, chat_state.current_index - 1)
                st.rerun()
            elif user_text.strip() == "/skip":
                chat_state.current_index += 1
                st.rerun()
            elif user_text.strip() == "/summary":
                st.info(summary(schema, chat_state.answers))
            elif user_text.strip() == "/export":
                st.session_state["export_request"] = True
                st.rerun()
            else:
                # Route to AI or rule-based
                if settings.AI_ENABLED:
                    msg, meta = ai_respond(user_text, field.key, field.help, field.enum_values)
                else:
                    msg, meta = rule_handle(user_text, field.key, field.enum_values or [])
                st.write(msg)
                # Accept answer directly unless it is a command-only
                if not user_text.strip().startswith("/"):
                    apply_answer(chat_state, field, user_text.strip())
                    chat_state.current_index += 1
                st.rerun()
    else:
        st.success("All fields prompted. You can export the workbook and create the Jira ticket.")

# Top actions
col1, col2, col3 = st.columns(3)
with col1:
    if st.button("Summary"):
        pct, errs = dor_check(schema, chat_state.answers)
        st.write(f"**DoR Coverage:** {pct:.1f}%")
        if errs:
            st.warning("Gaps:\n- " + "\n- ".join(errs))
        else:
            st.success("No gaps detected.")
with col2:
    if st.button("Download Workbook") or st.session_state.get("export_request"):
        # open template or uploaded and fill values by header name
        if mode == "Upload & Validate" and uploaded:
            path = "uploaded.xlsx"
        else:
            path = os.path.join("assets", "templates", "intake_template.xlsx")
        wb = load_workbook(path)
        for sheet in wb.sheetnames:
            if sheet == "Dictionaries":
                continue
            ws = wb[sheet]
            headers = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
            for col, head in enumerate(headers, start=1):
                if not head: continue
                name = str(head).replace("*","").replace("(required)","").strip()
                key = name.lower().replace(" ", "_")
                # try normalized
                key_norm = "".join(ch if ch.isalnum() or ch=="_" else "_" for ch in key).strip("_")
                val = chat_state.answers.get(key_norm)
                if val is not None:
                    ws.cell(row=2, column=col, value=val)
        out = BytesIO()
        wb.save(out); out.seek(0)
        st.download_button("Download Completed Workbook", data=out.getvalue(), file_name="completed_intake.xlsx", mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        st.session_state["export_request"] = False
with col3:
    if st.button("Create Jira Ticket"):
        session_id = store.get("session_id") or gen_session_id()
        store["session_id"] = session_id
        pct, errs = dor_check(schema, chat_state.answers)
        path = os.path.join("completed_intake.xlsx")
        # save current workbook to disk for attachment
        tpl = os.path.join("assets", "templates", "intake_template.xlsx")
        wb = load_workbook(tpl)
        for sheet in wb.sheetnames:
            if sheet == "Dictionaries":
                continue
            ws = wb[sheet]
            headers = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
            for col, head in enumerate(headers, start=1):
                if not head: continue
                name = str(head).replace("*","").replace("(required)","").strip()
                key = name.lower().replace(" ", "_")
                key_norm = "".join(ch if ch.isalnum() or ch=="_" else "_" for ch in key).strip("_")
                val = chat_state.answers.get(key_norm)
                if val is not None:
                    ws.cell(row=2, column=col, value=val)
        wb.save(path)
        summary_text = f"SSAT Intake – {{chat_state.answers.get('partner_name','UnknownPartner')}} – {datetime.utcnow().date()}"
        desc = f"Path: {{'Upload' if mode=='Upload & Validate' else 'Guided'}}\nDoR: {pct:.1f}%\nMissing: {', '.join(errs) if errs else 'None'}\nSession: {session_id}\nTimestamp: {now_iso()}"
        try:
            key, url = create_issue(summary_text, desc, fields=None)
            attach_file(key, path)
            st.success(f"Created Jira issue **{key}**. [Open in Jira]({{url}})")
        except Exception as e:
            st.error(f"Jira operation failed: {e}")
