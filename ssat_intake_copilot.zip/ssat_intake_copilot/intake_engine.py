from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from excel_schema import TemplateSchema, Field
from dor_validator import dor_check
from mapping import CONDITIONAL_RULES, HELP_TEXT

@dataclass
class ChatState:
    mode: str = "upload"  # 'upload' or 'guided'
    answers: Dict[str, str] = field(default_factory=dict)
    current_index: int = 0
    ordered_keys: List[str] = field(default_factory=list)

    def reset(self, ordered_keys: List[str]):
        self.answers.clear()
        self.current_index = 0
        self.ordered_keys = ordered_keys

def build_prompt_queue(schema: TemplateSchema) -> List[Field]:
    # Required first, then others
    req = [f for f in schema.fields if f.required]
    opt = [f for f in schema.fields if not f.required]
    # de-duplicate by key preserving first occurrence
    seen = set()
    ordered: List[Field] = []
    for group in (req, opt):
        for f in group:
            if f.key not in seen:
                seen.add(f.key)
                ordered.append(f)
    return ordered

def next_field(state: ChatState, schema: TemplateSchema) -> Optional[Field]:
    if state.current_index >= len(state.ordered_keys):
        return None
    key = state.ordered_keys[state.current_index]
    for f in schema.fields:
        if f.key == key:
            return f
    return None

def apply_answer(state: ChatState, field: Field, value: str) -> None:
    state.answers[field.key] = value

def summary(schema: TemplateSchema, answers: Dict[str, str]) -> str:
    pct, errors = dor_check(schema, answers)
    lines = [f"DoR Coverage: {pct:.1f}%"]
    if errors:
        lines.append("Gaps:")
        lines.extend([f" - {e}" for e in errors])
    else:
        lines.append("No gaps detected.")
    return "\n".join(lines)
