from __future__ import annotations
from typing import List
import difflib

def classify_intent(text: str) -> str:
    t = text.strip().lower()
    if t.startswith("/help"): return "help"
    if t.startswith("/back"): return "back"
    if t.startswith("/skip"): return "skip"
    if t.startswith("/summary"): return "summary"
    if t.startswith("/export"): return "export"
    return "answer"

def score_answer(text: str) -> float:
    # naive completeness score
    length = len(text.strip())
    if length == 0: return 0.0
    return min(1.0, 0.2 + length/100.0)

def suggest_enum(text: str, enum_values: List[str]) -> str | None:
    t = text.strip()
    if not t: return None
    match = difflib.get_close_matches(t, enum_values, n=1, cutoff=0.5)
    return match[0] if match else None
