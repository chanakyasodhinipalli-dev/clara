from __future__ import annotations
from typing import Dict, Tuple
from .nlp_utils import classify_intent, score_answer, suggest_enum
from mapping import HELP_TEXT

def respond(user_text: str, current_field_key: str | None, schema_field_help: str | None, enum_values: list[str] | None) -> Tuple[str, Dict]:
    """AI-assisted chat response builder (no external LLM dependency in MVP)."""
    intent = classify_intent(user_text)
    meta: Dict = {"intent": intent}
    if intent == "help":
        tip = schema_field_help or HELP_TEXT.get(current_field_key or "", "No help available.")
        return f"Here's some guidance: {tip}", meta
    if enum_values:
        guess = suggest_enum(user_text, enum_values)
        if guess:
            meta["enum_guess"] = guess
            return f"Got it. Did you mean: '{guess}'? If yes, reply 'yes'.", meta
    score = score_answer(user_text)
    meta["confidence"] = score
    if score < 0.4:
        return "I'm not fully confident. Could you rephrase or provide an example?", meta
    return "Noted.", meta
