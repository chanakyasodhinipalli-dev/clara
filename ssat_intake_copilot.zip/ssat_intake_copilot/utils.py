from __future__ import annotations
import uuid
from datetime import datetime, timezone
from typing import TypedDict, Any, Dict
import structlog

logger = structlog.get_logger()

class AppError(Exception):
    pass

class ValidationError(AppError):
    def __init__(self, field_key: str, message: str):
        super().__init__(f"{field_key}: {message}")
        self.field_key = field_key
        self.message = message

def gen_session_id() -> str:
    return uuid.uuid4().hex[:12]

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
