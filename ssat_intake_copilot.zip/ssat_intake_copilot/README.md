# SSAT Intake Copilot (MVP)

A single-page Streamlit app that turns an **Intake Request Excel workbook** into a **chat-driven intake experience**. It supports two user paths:

- **Path A – Upload & Validate**: Parse a provided workbook, run DoR checks, chat to collect fixes, write updates, and create a Jira ticket at the **SSAT** level (with the workbook attached).
- **Path B – Guided Build**: Start from the canonical template, guide the user through required → conditional → optional fields with examples, produce a completed workbook, and create a Jira ticket.

The app exposes an **AI_ENABLED** toggle to switch between **AI-assisted** and **deterministic** (rule-based) flows. Both paths keep identical UX and outputs; AI only enhances guidance.

## Tech Stack

- **Frontend/UI**: Streamlit (single page, chat UI)
- **Core**: Python 3.11+, pandas, openpyxl
- **Integrations**: httpx (Jira REST), optional pydantic
- **Config**: `.env` via `python-dotenv`
- **Logging**: structlog (JSON)
- **Tests**: pytest

See `requirements.txt` for packages.

## Quick Start

```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env  # update Jira creds and AI flag
streamlit run app.py
```

## Usage

- In the **sidebar** select **Upload & Validate** (Path A) or **Guided Build** (Path B).
- For Path A, upload your completed Intake workbook. The chat will show DoR gaps and collect fixes, then let you **Download Workbook** and **Create Jira Ticket**.
- For Path B, the app loads the canonical template from `assets/templates/intake_template.xlsx`, guides you to fill fields (with examples from `assets/references/`), then **Download Workbook** and **Create Jira Ticket**.

## Structure

```
ssat_intake_copilot/
  app.py
  config.py
  excel_schema.py
  dor_validator.py
  intake_engine.py
  jira_client.py
  mapping.py
  storage.py
  utils.py
  ai_path/
    ai_controller.py
    nlp_utils.py
  deterministic_path/
    rule_engine.py
  assets/
    templates/
      intake_template.xlsx
    references/
      example_intake_01.xlsx
      example_intake_02.xlsx
  tests/
    test_schema.py
    test_dor.py
    test_jira.py
  .env.example
  README.md
  requirements.txt
```

## Notes

- **Templates & References**: The parser infers required fields by `*` markers and consults `mapping.py` for help text. Enum lists are supplied by dictionary/lookup areas.
- **DoR (Definition of Ready)**: `dor_validator.py` checks missing requireds, malformed values, and cross-field rules (e.g., Kafka on ⇒ Kafka topic required).
- **AI Toggle**: `AI_ENABLED=true` uses `ai_path/ai_controller.py`; `false` uses `deterministic_path/rule_engine.py`.
- **Next Steps**: DB persistence, Enterprise SSO, and pluggable LLM providers.
