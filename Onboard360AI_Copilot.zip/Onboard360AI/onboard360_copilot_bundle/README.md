# OnBoard360 AI Copilot — Enterprise Bundle

Contents
- PROMPT.txt — Enterprise copilot prompt (system definition).
- app/ — FastAPI app (MCP-like tools, validation, PDF, email, Jira/Confluence).
- templates/form.html — HTML template for PDF rendering.
- config/questions_catalog.yaml — Question catalog.
- requirements.txt

## Run
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
export PYTHONPATH=.
uvicorn app.main:app --reload --port 8080
```

## Flow
- POST /mcp/create_form
- POST /mcp/propose_draft  (form_id, message=free text)
- POST /mcp/followups
- POST /mcp/validate_form
- POST /mcp/render_pdf
- POST /integrations/notify_review (SMTP)
- POST /integrations/jira
- POST /integrations/confluence

All endpoints are implemented without stubs. External calls require valid credentials.
