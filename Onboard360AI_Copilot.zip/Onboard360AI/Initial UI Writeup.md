A UI web application with user login and logout features implemented. Welcome message on header, something similar to "Welcome to Onboard360 AI, a one-stop for all your ICMP Onboarding Journey".

Use configured static users with static passwords for authentication and authorization.

Use casbin for RBAC security setup.

Different type of users and how their UI should look like:

1. Partner Users: Horizontal tabbed approach in the navigation show the below features: 

* Dashboard: Show graphical representation of draft intakes, submitted intakes, completed intakes based on logged in user. Click on the number, display the list below in tabular format with the key, summary, status, fix version, target version.  
* Raise New Intake: Integrated Chatbot with file upload feature and previous history
* Track my Intakes: Show collapsible list of intakes with the key and summary in the title, In the details show various states of the onboarding progress where completed should be disabled and greyed out, on-going should be in either green or yellow or red based on stage, to be taken up has to be in white
* My Action Items: A tabular structure with on  a click of a row, populate the details in the right side expandable area. On demand by click of a chat button, chat bot has to be opened to work on the allocated task

1. Onboarding Team Member: Horizontal tabbed approach in the navigation show the below features:

* Dashboard: Total features allocated view: on extended can see the tasks, pending partner responses list, pending my actions, pending team actions
* Current Sprint Activities: Detailed tasks by feature in collapsible list per feature. On demand by click of a chat button, chat bot has to be opened to work on the allocated task
* My Action Items: A tabular structure with on  a click of a row, populate the details in the right side expandable area. On demand by click of a chat button, chat bot has to be opened to work on the allocated task
* Team Action Items: A tabular structure with on  a click of a row, populate the details in the right side expandable area. On demand by click of a chat button, chat bot has to be opened to work on the allocated task

1. ICMP Leadership: Horizontal tabbed approach in the navigation show the below features:

* Dashboard: Show multiple graphical representation for Intakes by status, Intakes by LOB, Intakes by LOB and Status (filterable), Ongoing Features, Features in Risk, Delayed Features, Trends and pattern identification, etc.,.
* My Action Items

1. Product Owner / Scrum Master: Horizontal tabbed approach in the navigation show the below features:  

* Dashboard: Show multiple graphical representation for specific scrum team Ongoing Features, Features in Risk, Delayed Features, Trends and pattern identification, etc.,.

* Current Sprint Activities: Detailed tasks by feature in collapsible list per feature. On demand by click of a chat button, chat bot has to be opened to work on the allocated task
* My Action Items: A tabular structure with on  a click of a row, populate the details in the right side expandable area. On demand by click of a chat button, chat bot has to be opened to work on the allocated task

Team Action Items: A tabular structure with on  a click of a row, populate the details in the right side expandable area. On demand by click of a chat button, chat bot has to be opened to work on the allocated task



Based on config value for each set of users and each set of navigation menu item, populate the test data or get it runtime by invoking API

