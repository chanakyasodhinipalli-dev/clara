import React, { useEffect, useRef, useState } from 'react'
import { api } from '../api/client'
export default function ChatDrawer({ open, onClose }:{open:boolean; onClose:()=>void}){
  const [threadId,setThreadId]=useState<string|undefined>(undefined); const [messages,setMessages]=useState<any[]>([])
  const inputRef = useRef<HTMLInputElement>(null)
  useEffect(()=>{ if(open && inputRef.current){ inputRef.current.focus() } },[open])
  async function send(){ const text=inputRef.current!.value.trim(); if(!text) return
    const res=await api('/api/chat/send',{method:'POST', body: JSON.stringify({ threadId, message: text })})
    setThreadId(res.threadId); setMessages(res.messages); inputRef.current!.value='' }
  if(!open) return null
  return (<div style={{position:'fixed',top:0,right:0,width:420,height:'100vh',background:'#fff',boxShadow:'-4px 0 8px rgba(0,0,0,.2)',display:'flex',flexDirection:'column'}}>
    <div style={{padding:12,borderBottom:'1px solid #eee',display:'flex',justifyContent:'space-between'}}><b>Copilot</b><button onClick={onClose}>✕</button></div>
    <div style={{flex:1,overflowY:'auto',padding:12}}>{messages.map((m,i)=>(<div key={i} style={{marginBottom:8}}><div style={{fontSize:12,color:'#666'}}>{m.role}</div><div>{m.text}</div></div>))}</div>
    <div style={{padding:12,borderTop:'1px solid #eee',display:'flex',gap:8}}><input ref={inputRef} placeholder="summary: ..., lob: ..., target: v1" style={{flex:1}}/><button onClick={send}>Send</button></div>
  </div>)
}
