import React, { useState } from 'react'
import { Outlet, Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../store/auth'
import ChatDrawer from './ChatDrawer'
import { api } from '../api/client'
export default function AppShell(){
  const { user, setUser } = useAuth(); const nav = useNavigate(); const [open,setOpen]=useState(false)
  async function logout(){ await api('/api/auth/logout',{method:'POST'}); setUser(undefined); nav('/login') }
  return (<div style={{fontFamily:'system-ui, sans-serif'}}>
    <header style={{display:'flex',justifyContent:'space-between',padding:'12px 16px',background:'#0b5ed7',color:'#fff'}}>
      <div>Welcome to <b>Onboard360 AI</b> — a one‑stop for all your ICMP Onboarding Journey</div>
      <div>{user ? <><span style={{marginRight:12}}>{user.fullName} ({user.role})</span><button onClick={()=>setOpen(true)} style={{marginRight:8}}>Open Copilot</button><button onClick={logout}>Logout</button></>:<Link to='/login' style={{color:'#fff'}}>Login</Link>}</div>
    </header>
    <nav style={{display:'flex',gap:12,padding:'8px 16px',borderBottom:'1px solid #eee'}}><Link to='/partner'>Partner</Link><Link to='/lead'>Leadership</Link></nav>
    <main style={{padding:16}}><Outlet/></main><ChatDrawer open={open} onClose={()=>setOpen(false)}/>
  </div>)
}
