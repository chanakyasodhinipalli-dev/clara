import React, { useEffect, useState } from 'react'
import { api } from '../../api/client'
export default function LeadDashboard(){
  const [data,setData]=useState<any>(); useEffect(()=>{ api('/api/lead/dashboard').then(setData) },[])
  if(!data) return <div>Loading...</div>
  return (<div><h2>Leadership Dashboard</h2><pre style={{background:'#f6f8fa',padding:12}}>{JSON.stringify(data,null,2)}</pre></div>)
}
