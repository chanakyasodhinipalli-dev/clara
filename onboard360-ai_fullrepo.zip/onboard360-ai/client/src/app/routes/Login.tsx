import React, { useRef } from 'react'
import { api } from '../../api/client'
import { useAuth } from '../../store/auth'
import { useNavigate } from 'react-router-dom'
export default function Login(){
  const userRef=useRef<HTMLInputElement>(null); const passRef=useRef<HTMLInputElement>(null)
  const { setUser } = useAuth(); const nav=useNavigate()
  async function submit(e:React.FormEvent){ e.preventDefault(); const res=await api('/api/auth/login',{method:'POST', body: JSON.stringify({ username:userRef.current!.value, password:passRef.current!.value })}); setUser(res.user); nav('/') }
  return (<form onSubmit={submit} style={{maxWidth:360,margin:'10vh auto',display:'grid',gap:12}}><h2>Login</h2>
    <input ref={userRef} placeholder="username (partner1)" defaultValue="partner1"/><input ref={passRef} placeholder="password (P@ssw0rd!)" type="password" defaultValue="P@ssw0rd!"/><button type="submit">Login</button></form>)
}
