import React, { useEffect, useState } from 'react'
import { api } from '../../api/client'
export default function PartnerDashboard(){
  const [data,setData]=useState<any>(); useEffect(()=>{ api('/api/partner/dashboard').then(setData).catch(console.error) },[])
  if(!data) return <div>Loading...</div>
  return (<div><h2>Partner Dashboard</h2><div style={{display:'flex',gap:12}}><Stat label="Draft" value={data.draft}/><Stat label="Submitted" value={data.submitted}/><Stat label="Completed" value={data.completed}/></div>
  <h3 style={{marginTop:16}}>My Intakes</h3><table border={1} cellPadding={6}><thead><tr><th>Key</th><th>Summary</th><th>Status</th><th>LOB</th></tr></thead>
  <tbody>{data.list.map((i:any)=>(<tr key={i.key}><td>{i.key}</td><td>{i.summary}</td><td>{i.status}</td><td>{i.lob}</td></tr>))}</tbody></table></div>)
}
function Stat({label,value}:{label:string; value:number}){ return <div style={{padding:12,background:'#f4f6fa',border:'1px solid #e1e4e8'}}><div>{label}</div><div style={{fontSize:24}}>{value}</div></div> }
