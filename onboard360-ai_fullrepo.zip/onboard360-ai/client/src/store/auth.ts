import { create } from 'zustand'
export type User = { id:string; username:string; role:string; fullName:string }
export const useAuth = create<{user?:User; setUser:(u?:User)=>void}>(set=>({user:undefined,setUser:(u)=>set({user:u})}))
