import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import Login from './app/routes/Login'
import PartnerDashboard from './app/routes/PartnerDashboard'
import LeadDashboard from './app/routes/LeadDashboard'
import AppShell from './components/AppShell'
const qc = new QueryClient()
createRoot(document.getElementById('root')!).render(<React.StrictMode>
  <QueryClientProvider client={qc}><BrowserRouter>
    <Routes>
      <Route path='/login' element={<Login/>} />
      <Route path='/' element={<AppShell/>}>
        <Route index element={<Navigate to='/partner'/>} />
        <Route path='partner' element={<PartnerDashboard/>} />
        <Route path='lead' element={<LeadDashboard/>} />
      </Route>
    </Routes>
  </BrowserRouter></QueryClientProvider></React.StrictMode>)
