# Onboard360 AI — Full Stack (Windows-Ready)
## Backend (FastAPI)
1. `cd server`
2. `python -m venv .venv` and activate it
3. `pip install -r requirements.txt`
4. `copy .env.example .env`
5. `uvicorn app.main:app --reload --port 8000`
## Frontend (React + Vite)
1. `cd client`
2. `npm install`
3. `npm run dev`
Login with **partner1 / P@ssw0rd!**. Open Copilot (top right) and try: `summary: New partner onboarding, lob: CIB, target: v1`
