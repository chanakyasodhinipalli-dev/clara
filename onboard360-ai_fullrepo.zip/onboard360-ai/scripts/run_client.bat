@echo off
cd /d %~dp0\..\client
npm install
npm run dev
