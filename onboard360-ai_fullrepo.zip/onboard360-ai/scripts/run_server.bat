@echo off
cd /d %~dp0\..\server
python -m venv .venv
call .venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env >nul
uvicorn app.main:app --reload --port 8000
