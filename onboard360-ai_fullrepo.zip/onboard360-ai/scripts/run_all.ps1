Start-Process powershell -ArgumentList '-NoExit','-Command','& { ./scripts/run_server.bat }'
Start-Process powershell -ArgumentList '-NoExit','-Command','& { ./scripts/run_client.bat }'
