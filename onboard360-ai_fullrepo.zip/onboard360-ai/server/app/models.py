from pydantic import BaseModel, Field
from typing import List, Optional, Literal
from datetime import date
class Stage(BaseModel):
    name: str
    state: Literal['completed', 'ongoing', 'todo']
    health: Optional[Literal['green', 'yellow', 'red']] = None
class Intake(BaseModel):
    key: str
    summary: str
    status: str
    fixVersion: Optional[str] = None
    targetVersion: Optional[str] = None
    ownerUserId: str
    lob: Optional[str] = None
    stages: List[Stage] = []
class ActionItem(BaseModel):
    id: str
    title: str
    relatedKey: Optional[str] = None
    assignee: str
    dueDate: Optional[date] = None
    status: str
    details: str
class Task(BaseModel):
    id: str
    title: str
    status: str
    owner: str
    relatedKey: Optional[str] = None
    storyPoints: Optional[int] = None
    sprint: Optional[str] = None
class Feature(BaseModel):
    key: str
    name: str
    riskLevel: Optional[str] = None
    delayed: Optional[bool] = False
    tasks: List[Task] = []
class User(BaseModel):
    id: str
    username: str
    role: str
    fullName: str
class LoginRequest(BaseModel):
    username: str
    password: str
class LoginResponse(BaseModel):
    user: User
    token: str
