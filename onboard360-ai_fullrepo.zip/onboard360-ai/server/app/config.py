from pydantic import BaseModel
import os
class Settings(BaseModel):
    DATA_SOURCE: str = os.getenv("DATA_SOURCE", "mock")
    JWT_SECRET: str = os.getenv("JWT_SECRET", "dev-secret")
    AI_ENABLED: bool = os.getenv("AI_ENABLED", "true").lower() == "true"
    CSRF_ENABLED: bool = os.getenv("CSRF_ENABLED", "true").lower() == "true"
    CORS_ORIGINS: str = os.getenv("CORS_ORIGINS", "*")
settings = Settings()
FEATURES_JSON = {
  "partner": { "dashboard": "mock", "raiseIntake": "api", "track": "mock", "myActions": "api" },
  "otm":     { "dashboard": "api", "sprint": "api", "myActions": "mock", "teamActions": "api" },
  "lead":    { "dashboard": "api", "myActions": "api" },
  "po":      { "dashboard": "api", "sprint": "api", "myActions": "api", "teamActions": "api" }
}
