from fastapi import Request, HTTPException
from .config import settings
from .auth import decode_jwt
from .models import User
import json
def get_current_user(request: Request) -> User:
    token = request.cookies.get("session")
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        claims = decode_jwt(token, settings.JWT_SECRET)
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")
    with open((request.app.state.data_dir / "users.json"), "r", encoding="utf-8") as f:
        data = json.load(f)
    user = next((u for u in data if u["id"] == claims.get("sub")), None)
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return User(id=user["id"], username=user["username"], role=user["role"], fullName=user["fullName"])
