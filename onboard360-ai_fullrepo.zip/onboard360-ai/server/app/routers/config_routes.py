from fastapi import APIRouter
from ..config import settings, FEATURES_JSON
router = APIRouter(prefix="/api", tags=["config"])
@router.get("/config")
def get_config():
    return {"dataSource": settings.DATA_SOURCE, "featureFlagsPerRole": FEATURES_JSON}
