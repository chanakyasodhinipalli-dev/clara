from fastapi import APIRouter, UploadFile, File, Request, Depends
from ..services.repositories import MockRepo, ApiRepo
from ..config import settings
from ..deps import get_current_user
from ..services.chat_service import send_message
import uuid, shutil
router = APIRouter(prefix="/api/chat", tags=["chat"])
def get_repo(request: Request):
    return ApiRepo(request.app.state.data_dir) if settings.DATA_SOURCE=='api' else MockRepo(request.app.state.data_dir)
@router.post("/send")
def send(request: Request, payload: dict, user=Depends(get_current_user)):
    repo = get_repo(request); return send_message(repo, user, payload.get("threadId"), payload.get("message",""))
@router.post("/upload")
def upload(request: Request, file: UploadFile = File(...), user=Depends(get_current_user)):
    upload_dir = request.app.state.uploads_dir; fid = f"{uuid.uuid4()}_{file.filename}"
    dest = upload_dir / fid
    with dest.open("wb") as f: shutil.copyfileobj(file.file, f)
    return {"fileId": fid, "name": file.filename, "size": dest.stat().st_size}
