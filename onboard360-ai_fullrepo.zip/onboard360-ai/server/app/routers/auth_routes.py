from fastapi import APIRouter, Response, HTTPException
from ..models import LoginRequest
from ..auth import verify_password, issue_tokens, set_session_cookies
from ..config import settings
from pathlib import Path
import json
router = APIRouter(prefix="/api/auth", tags=["auth"])
@router.post("/login")
def login(payload: LoginRequest, response: Response):
    users_path = Path(__file__).resolve().parent.parent / "data" / "users.json"
    users = json.loads(users_path.read_text(encoding="utf-8"))
    user = next((u for u in users if u["username"] == payload.username), None)
    if not user or not verify_password(payload.password, user["hashed_password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token, csrf = issue_tokens(user, settings.JWT_SECRET)
    set_session_cookies(response, token, csrf)
    public = {k: user[k] for k in ["id","username","role","fullName"]}
    return {"user": public, "token": token}
@router.post("/logout")
def logout(response: Response):
    response.delete_cookie("session"); response.delete_cookie("csrf_token"); return {"ok": True}
