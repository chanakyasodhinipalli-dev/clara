from fastapi import APIRouter, Depends, Request
from ..rbac import authorize_dependency
from ..services.repositories import MockRepo, ApiRepo
from ..config import settings
from ..deps import get_current_user
from ..services.partner_service import dashboard
from ..models import Intake
import uuid
router = APIRouter(prefix="/api/partner", tags=["partner"])
def get_repo(request: Request):
    return ApiRepo(request.app.state.data_dir) if settings.DATA_SOURCE=='api' else MockRepo(request.app.state.data_dir)
@router.get("/dashboard", dependencies=[Depends(authorize_dependency("partner:dashboard","read"))])
def partner_dashboard(request: Request, user=Depends(get_current_user)):
    repo = get_repo(request); return dashboard(repo, user.id)
@router.get("/intakes", dependencies=[Depends(authorize_dependency("partner:track","read"))])
def list_intakes(request: Request, user=Depends(get_current_user)):
    repo = get_repo(request); return [i for i in repo.intakes if i.get("ownerUserId")==user.id]
@router.post("/intakes")
def create_intake(payload: Intake, request: Request, user=Depends(get_current_user)):
    repo = get_repo(request); new_item = payload.dict()
    if not new_item.get("key"): new_item["key"] = f"INT-{str(uuid.uuid4())[:8]}"
    repo.intakes.append(new_item); return new_item
