from fastapi import APIRouter, Depends, Request
from ..rbac import authorize_dependency
from ..services.repositories import MockRepo, ApiRepo
from ..config import settings
from ..services.lead_service import charts
from ..deps import get_current_user
router = APIRouter(prefix="/api/lead", tags=["lead"])
def get_repo(request: Request):
    return ApiRepo(request.app.state.data_dir) if settings.DATA_SOURCE=='api' else MockRepo(request.app.state.data_dir)
@router.get("/dashboard", dependencies=[Depends(authorize_dependency("lead:dashboard","read"))])
def dashboard(request: Request, user=Depends(get_current_user)):
    repo = get_repo(request); return charts(repo)
