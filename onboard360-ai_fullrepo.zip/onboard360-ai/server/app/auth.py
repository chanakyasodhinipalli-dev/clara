from datetime import datetime, timedelta, timezone
from typing import Dict, Any
import jwt
from fastapi import Response, Request, HTTPException

def looks_bcrypt(h: str) -> bool:
    return h.startswith("$2a$") or h.startswith("$2b$") or h.startswith("$2y$")

# Optional bcrypt; only used at runtime if installed
try:
    from passlib.context import CryptContext  # type: ignore
    _pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
except Exception:
    _pwd = None

def verify_password(password: str, stored: str) -> bool:
    # Accept either bcrypt hash (if passlib available) or plaintext match
    if _pwd and looks_bcrypt(stored):
        try:
            return _pwd.verify(password, stored)
        except Exception:
            return False
    return password == stored

def encode_jwt(payload: Dict[str, Any], secret: str, expires_minutes: int = 120) -> str:
    to_encode = payload.copy()
    to_encode["exp"] = datetime.now(timezone.utc) + timedelta(minutes=expires_minutes)
    return jwt.encode(to_encode, secret, algorithm="HS256")

def decode_jwt(token: str, secret: str) -> Dict[str, Any]:
    return jwt.decode(token, secret, algorithms=["HS256"])

def issue_tokens(user: Dict[str, Any], secret: str):
    csrf = user["id"][::-1]
    token = encode_jwt({"sub": user["id"], "uname": user["username"], "role": user["role"]}, secret)
    return token, csrf

def set_session_cookies(response: Response, token: str, csrf: str):
    response.set_cookie("session", token, httponly=True, samesite="lax")
    response.set_cookie("csrf_token", csrf, httponly=False, samesite="lax")

def require_csrf(request: Request):
    csrf_cookie = request.cookies.get("csrf_token")
    csrf_header = request.headers.get("x-csrf")
    if csrf_cookie != csrf_header:
        raise HTTPException(status_code=403, detail="CSRF check failed")
