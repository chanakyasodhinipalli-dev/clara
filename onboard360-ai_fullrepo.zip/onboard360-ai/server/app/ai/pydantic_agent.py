from pydantic import BaseModel, Field, ValidationError
from typing import Optional, List, Dict, Any
class Stage(BaseModel):
    name: str
    state: str
    health: Optional[str] = None
class IntakeForm(BaseModel):
    summary: str = Field(..., min_length=5)
    lob: str
    targetVersion: Optional[str]
    stages: List[Stage] = []
def parse_free_text_to_form(text: str) -> IntakeForm:
    parts = {k.strip().lower(): v.strip() for k,v in [p.split(':',1) for p in text.split(',') if ':' in p]}
    summary = parts.get('summary', text[:80])
    lob = parts.get('lob', 'Unknown')
    target = parts.get('target') or parts.get('targetversion')
    return IntakeForm(summary=summary, lob=lob, targetVersion=target, stages=[])
def validate_form(form: Dict[str, Any]) -> Dict[str, Any]:
    try:
        valid = IntakeForm(**form)
        return {'ok': True, 'data': valid.dict()}
    except ValidationError as e:
        return {'ok': False, 'errors': e.errors()}
