from typing import Dict, Any
def orchestrate_agents(event: Dict[str, Any]) -> Dict[str, Any]:
    return {'intent': 'validate_form' if 'form' in event else 'parse_text', 'handledBy': 'adk_stub'}
