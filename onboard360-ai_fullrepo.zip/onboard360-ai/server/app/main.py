from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path
from .config import settings
from .routers import auth_routes, partner_routes, lead_routes, chat_routes, config_routes
def create_app():
    app = FastAPI(title="Onboard360 AI")
    app.add_middleware(CORSMiddleware, allow_origins=["*"] if settings.CORS_ORIGINS=="*" else settings.CORS_ORIGINS.split(","),
                       allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
    app.state.root_dir = Path(__file__).parent
    app.state.data_dir = app.state.root_dir / "data"
    app.state.uploads_dir = app.state.root_dir / "static" / "uploads"
    (app.state.data_dir / "chat_threads.json").touch(exist_ok=True)
    if (app.state.data_dir / "chat_threads.json").read_text().strip() == "":
        (app.state.data_dir / "chat_threads.json").write_text("{}", encoding="utf-8")
    app.include_router(auth_routes.router); app.include_router(config_routes.router)
    app.include_router(partner_routes.router); app.include_router(lead_routes.router)
    app.include_router(chat_routes.router); return app
app = create_app()
