from .repositories import MockRepo
def charts(repo: MockRepo):
    return {'charts': repo.charts}
