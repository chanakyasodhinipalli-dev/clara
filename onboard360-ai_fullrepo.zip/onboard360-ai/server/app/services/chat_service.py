import uuid, time
from typing import Dict, Any
from ..ai.pydantic_agent import parse_free_text_to_form, validate_form
from ..ai.mcp_router import create_jira_ticket, publish_confluence_record, generate_pdf
def new_thread(repo) -> str:
    tid = str(uuid.uuid4()); repo.threads[tid] = {'messages': []}; repo.save_threads(); return tid
def send_message(repo, user, thread_id: str, message: str) -> Dict[str, Any]:
    if not thread_id or thread_id not in repo.threads:
        thread_id = new_thread(repo)
    thread = repo.threads[thread_id]
    thread['messages'].append({'role':'user','text':message,'ts':time.time()})
    form = parse_free_text_to_form(message)
    val = validate_form(form.dict())
    if val['ok']:
        pdf = generate_pdf(val['data'])
        jira = create_jira_ticket({'summary': val['data']['summary'], 'lob': val['data']['lob']})
        conf = publish_confluence_record({'intake': val['data']})
        reply = f"Validated intake. Created {jira['id']} and record {conf['id']}. PDF: {pdf['objectKey']}"
    else:
        reply = f"Validation errors: {val['errors']}"
    thread['messages'].append({'role':'assistant','text':reply,'ts':time.time()}); repo.save_threads()
    return {'threadId': thread_id, 'messages': thread['messages']}
