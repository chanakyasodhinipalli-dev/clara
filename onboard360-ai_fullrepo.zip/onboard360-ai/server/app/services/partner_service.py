from .repositories import MockRepo
from typing import Dict, Any
def dashboard(repo: MockRepo, user_id: str) -> Dict[str, Any]:
    mine = [i for i in repo.intakes if i.get('ownerUserId') == user_id]
    stats = {'draft':0,'submitted':0,'completed':0}
    for i in mine:
        s = i.get('status','draft'); stats[s] = stats.get(s,0)+1
    return {**stats, 'list': mine}
