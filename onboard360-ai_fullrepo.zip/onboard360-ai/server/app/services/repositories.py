import json
from pathlib import Path
class MockRepo:
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self._load()
    def _load(self):
        self.intakes = json.loads((self.data_dir / 'mock' / 'intakes.json').read_text(encoding='utf-8'))
        self.action_items = json.loads((self.data_dir / 'mock' / 'action_items.json').read_text(encoding='utf-8'))
        self.features = json.loads((self.data_dir / 'mock' / 'features.json').read_text(encoding='utf-8'))
        charts = (self.data_dir / 'mock' / 'charts.json')
        self.charts = json.loads(charts.read_text(encoding='utf-8')) if charts.exists() else {}
        threads = (self.data_dir / 'chat_threads.json')
        if not threads.exists(): threads.write_text("{}", encoding="utf-8")
        txt = threads.read_text(encoding='utf-8').strip() or "{}"
        self.threads = json.loads(txt)
    def save_threads(self):
        (self.data_dir / 'chat_threads.json').write_text(json.dumps(self.threads, indent=2), encoding='utf-8')
class ApiRepo(MockRepo):
    pass
