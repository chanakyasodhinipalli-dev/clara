import casbin
from fastapi import Depends, HTTPException
from .models import User
from .deps import get_current_user
from pathlib import Path
_enforcer = None
def get_enforcer():
    global _enforcer
    if _enforcer is None:
        model = str(Path(__file__).parent / "casbin" / "model.conf")
        policy = str(Path(__file__).parent / "casbin" / "policy.csv")
        _enforcer = casbin.Enforcer(model, policy)
    return _enforcer
def authorize_dependency(obj: str, act: str):
    def _dep(user: User = Depends(get_current_user)):
        enf = get_enforcer()
        if not enf.enforce(user.role, obj, act):
            raise HTTPException(status_code=403, detail="Forbidden")
        return True
    return _dep
