from pydantic import BaseSettings, Field

class Settings(BaseSettings):
    app_name: str = "OnBoard360 Copilot"
    env: str = "prod"
    secret_key: str = Field(default="CHANGE_ME")
    allowed_origins: list[str] = ["*"]

    smtp_host: str = "smtp.example.com"; smtp_port: int = 587
    smtp_user: str = "user@example.com"; smtp_password: str = "PASS_CHANGE_ME"
    email_from: str = "no-reply@onboard360.ai"

    jira_base_url: str = "https://jira.example.com"
    jira_user: str = "jira_user@example.com"; jira_api_token: str = "JIRA_TOKEN"; jira_project_key: str = "ONB"

    conf_base_url: str = "https://confluence.example.com"
    conf_user: str = "conf_user@example.com"; conf_api_token: str = "CONF_TOKEN"; conf_space_key: str = "ONB"

    data_dir: str = "/tmp/onboard360_data"; pdf_dir: str = "/tmp/onboard360_data/pdfs"
    log_json: bool = True
    class Config: env_file = ".env"

settings = Settings()
