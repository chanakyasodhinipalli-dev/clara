import re
from app.domain.models import IntakeForm
from pydantic import ValidationError

RE_EMAIL = re.compile(r"([\w\.-]+@[\w\.-]+\.[A-Za-z]{2,})")
RE_GB = re.compile(r"(\d+(?:\.\d+)?)\s*(tb|gb)", re.I)
RE_RET = re.compile(r"(3 months|6 months|1 year|3 years|5 years|7 years|10 years|indefinite)", re.I)

REQUIRED = [
    "partner.full_name","partner.contact_email",
    "use_case.title","use_case.description",
    "data.categories","governance.retention_period",
    "capacity.estimated_monthly_volume_gb","apg.product_tier","integration.kafka_required"
]

def parse_bulk_text_to_form(text: str) -> dict:
    email = (RE_EMAIL.search(text) or [None])[0]
    vol = None
    m = RE_GB.search(text)
    if m:
        num, unit = m.groups()
        num = float(num)
        vol = int(num * (1024 if unit.lower() == "tb" else 1))
    ret = (RE_RET.search(text) or [None])[0]
    partner = None
    m3 = re.search(r"partner (?:is|=)\s*([A-Za-z0-9 &.,-]+)", text, re.I)
    if m3: partner = m3.group(1).strip().rstrip(".")
    title = None
    m4 = re.search(r"project (?:is|=)\s*([A-Za-z0-9 &.,-]+)", text, re.I)
    if m4: title = m4.group(1).strip().rstrip(".")
    kafka_required = True if re.search(r"need (a )?kafka", text, re.I) else None
    kafka_topic = None
    m5 = re.search(r"kafka topic (?:called|named|=)\s*([a-z0-9._-]+)", text, re.I)
    if m5: kafka_topic = m5.group(1)

    return {
        "partner": {"full_name": partner or "", "contact_email": email or ""},
        "use_case": {"title": title or "", "description": ""},
        "data": {"categories": [], "contains_pii": None},
        "governance": {"retention_period": ret},
        "capacity": {"estimated_monthly_volume_gb": vol, "peak_tps": None},
        "apg": {"product_tier": None},
        "integration": {"kafka_required": kafka_required, "kafka_topic_name": kafka_topic},
        "timeline": {"go_live_date": None},
        "attachments": {"links": []},
        "attestation_agreed": False
    }

def _get_path(d: dict, path: str):
    cur = d
    for p in path.split("."):
        if p not in cur: return None
        cur = cur[p]
    return cur

def find_missing(form: dict) -> list[str]:
    return [p for p in REQUIRED if _get_path(form, p) in (None, "", [])]

def propose(message: str, prior: dict|None=None) -> dict:
    draft = parse_bulk_text_to_form(message)
    if prior:
        def merge(a,b):
            for k,v in b.items():
                if isinstance(v, dict) and isinstance(a.get(k), dict):
                    merge(a[k], v)
                else:
                    a[k] = v
        merge(draft, prior)
    return draft

def validate_form(form: dict):
    try:
        IntakeForm.model_validate(form)
        return True, []
    except ValidationError as e:
        errors = [f"{'.'.join(map(str,err['loc']))}: {err['msg']}" for err in e.errors()]
        return False, errors

def friendly_followups(missing: list[str]) -> str:
    mapping = {
        "partner.full_name": "What is your partner organization’s exact legal name?",
        "partner.contact_email": "What email should we use for onboarding updates?",
        "use_case.title": "What should we call your project/use case (a short title)?",
        "use_case.description": "Describe the use case in 2–4 sentences so reviewers understand scope.",
        "data.categories": "Which data categories are involved? (PII, PCI, PHI, etc.)",
        "governance.retention_period": "What is the required retention period (e.g., 7 years)?",
        "capacity.estimated_monthly_volume_gb": "What is the estimated monthly data volume in GB?",
        "apg.product_tier": "Which APIGEE product tier do you need (Sandbox/Bronze/Silver/Gold/Platinum)?",
        "integration.kafka_required": "Do you need a Kafka topic (yes/no)?"
    }
    return "I still need a few details:\n" + "\n".join(f"- {mapping.get(m, m)}" for m in missing)
