from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Any
from enum import Enum

class FormStatus(str, Enum):
    DRAFT="DRAFT"; READY_FOR_REVIEW="READY_FOR_REVIEW"; SENT_FOR_REVIEW="SENT_FOR_REVIEW"
    CHANGES_REQUESTED="CHANGES_REQUESTED"; RESUBMITTED="RESUBMITTED"; APPROVED="APPROVED"

class Applicant(BaseModel):
    full_name: str = Field(..., min_length=3, max_length=120)
    contact_email: EmailStr

class DataSection(BaseModel):
    categories: List[str] = []
    contains_pii: Optional[bool] = None

class Governance(BaseModel):
    retention_period: Optional[str] = None

class Capacity(BaseModel):
    estimated_monthly_volume_gb: Optional[int] = Field(None, ge=0, le=1_000_000)
    peak_tps: Optional[int] = Field(None, ge=0, le=20_000)

class APG(BaseModel):
    product_tier: Optional[str] = None

class Integration(BaseModel):
    kafka_required: Optional[bool] = None
    kafka_topic_name: Optional[str] = None

class Timeline(BaseModel):
    go_live_date: Optional[str] = None

class Attachments(BaseModel):
    links: List[str] = []

class UseCase(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None

class IntakeForm(BaseModel):
    partner: Applicant
    use_case: UseCase
    data: DataSection = DataSection()
    governance: Governance = Governance()
    capacity: Capacity = Capacity()
    apg: APG = APG()
    integration: Integration = Integration()
    timeline: Timeline = Timeline()
    attachments: Attachments = Attachments()
    attestation_agreed: bool = False

class ProposeResponse(BaseModel):
    form: dict
    missing: List[str]

class ValidateResponse(BaseModel):
    ok: bool
    errors: List[str] = []
