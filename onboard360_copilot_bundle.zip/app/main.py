from fastapi import FastAPI, Body
from fastapi.middleware.cors import CORSMiddleware
from app.config.settings import settings
from app.domain.models import ProposeResponse, ValidateResponse, FormStatus
from app.ai.agents import propose, find_missing, validate_form, friendly_followups
from app.services.pdf_service import render_pdf
from app.services.storage_service import persist_json
from app.services.email_service import send_email
from app.services.jira_service import create_issue
from app.services.confluence_service import create_page
from app.services.observability import audit
from pathlib import Path
import uuid, json

app = FastAPI(title=settings.app_name)
app.add_middleware(CORSMiddleware, allow_origins=settings.allowed_origins,
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

FORMS: dict[str, dict] = {}; VERSIONS: dict[str, int] = {}

@app.post("/mcp/create_form")
def create_form():
    form_id = str(uuid.uuid4()); FORMS[form_id] = {}; VERSIONS[form_id] = 0
    audit("form.created", {"form_id": form_id}); return {"form_id": form_id}

@app.post("/mcp/propose_draft", response_model=ProposeResponse)
def mcp_propose(form_id: str = Body(...), message: str = Body(...)):
    prior = FORMS.get(form_id, {}); draft = propose(message, prior); FORMS[form_id] = draft
    missing = find_missing(draft); audit("form.proposed", {"form_id": form_id, "missing": missing})
    return {"form": draft, "missing": missing}

@app.post("/mcp/validate_form", response_model=ValidateResponse)
def mcp_validate(form_id: str = Body(...)):
    form = FORMS.get(form_id) or {}; ok, errors = validate_form(form)
    audit("form.validated", {"form_id": form_id, "ok": ok, "errors": errors}); return {"ok": ok, "errors": errors}

@app.post("/mcp/followups")
def mcp_followups(form_id: str = Body(...)):
    form = FORMS.get(form_id) or {}; missing = find_missing(form)
    return {"missing": missing, "message": friendly_followups(missing)}

@app.post("/mcp/render_pdf")
def mcp_render_pdf(form_id: str = Body(...)):
    VERSIONS[form_id] += 1; version = VERSIONS[form_id]
    out_pdf = render_pdf(FORMS[form_id], form_id, version, FormStatus.READY_FOR_REVIEW.value, "templates", settings.pdf_dir)
    json_path = persist_json(settings.data_dir, form_id, version, FORMS[form_id])
    audit("form.rendered", {"form_id": form_id, "version": version, "pdf": out_pdf, "json": json_path})
    return {"pdf_path": out_pdf, "json_path": json_path, "version": version}

@app.post("/integrations/notify_review")
def notify_review(form_id: str = Body(...), to_email: str = Body(...)):
    version = VERSIONS.get(form_id, 1); pdf_path = str(Path(settings.pdf_dir) / f"{form_id}_v{version}.pdf")
    send_email(settings.smtp_host, settings.smtp_port, settings.smtp_user, settings.smtp_password,
               settings.email_from, to_email, f"OnBoard360 Review Request: {form_id} v{version}",
               "Please review the attached PDF and reply with comments.", [pdf_path])
    audit("notify.review", {"form_id": form_id, "to": to_email}); return {"status": "sent"}

@app.post("/integrations/jira")
def create_jira_issue(form_id: str = Body(...), summary: str = Body(..., embed=True)):
    body = json.dumps(FORMS.get(form_id, {}), indent=2)
    res = create_issue(settings.jira_base_url, settings.jira_user, settings.jira_api_token,
                       settings.jira_project_key, summary, body)
    audit("jira.created", {"form_id": form_id, "issue": res}); return res

@app.post("/integrations/confluence")
def create_conf_page(form_id: str = Body(...), title: str = Body(..., embed=True)):
    html = f"<h1>OnBoard360 Form {form_id}</h1><pre>{json.dumps(FORMS.get(form_id, {}), indent=2)}</pre>"
    res = create_page(settings.conf_base_url, settings.conf_user, settings.conf_api_token,
                      settings.conf_space_key, title, html)
    audit("confluence.created", {"form_id": form_id, "page": res}); return res
