from jinja2 import Environment, FileSystemLoader
from weasyprint import HTML
from pathlib import Path

def render_pdf(form: dict, form_id: str, version: int, status: str, template_dir: str, out_dir: str) -> str:
    env = Environment(loader=FileSystemLoader(template_dir))
    tpl = env.get_template("form.html")
    html = tpl.render(form=form, form_id=form_id, version=version, status=status)
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    out_path = Path(out_dir) / f"{form_id}_v{version}.pdf"
    HTML(string=html).write_pdf(out_path.as_posix())
    return out_path.as_posix()
