import smtplib
from email.message import EmailMessage

def send_email(smtp_host: str, smtp_port: int, smtp_user: str, smtp_password: str,
               sender: str, to: str, subject: str, body: str, attachments: list[str]|None=None):
    msg = EmailMessage()
    msg["From"] = sender; msg["To"] = to; msg["Subject"] = subject
    msg.set_content(body)
    for a in attachments or []:
        with open(a, "rb") as f: data = f.read()
        msg.add_attachment(data, maintype="application", subtype="pdf", filename=a.split("/")[-1])
    with smtplib.SMTP(smtp_host, smtp_port) as server:
        server.starttls(); server.login(smtp_user, smtp_password); server.send_message(msg)
