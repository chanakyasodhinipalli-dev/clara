import requests
def create_page(base_url: str, user: str, token: str, space_key: str, title: str, html: str):
    url = f"{base_url}/rest/api/content/"
    payload = {"type": "page","title": title,"space": {"key": space_key},"body": {"storage": {"value": html, "representation": "storage"}}}
    r = requests.post(url, json=payload, auth=(user, token), timeout=30); r.raise_for_status(); return r.json()
