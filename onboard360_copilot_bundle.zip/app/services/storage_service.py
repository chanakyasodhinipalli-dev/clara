from pathlib import Path
import json
def persist_json(base_dir: str, form_id: str, version: int, data: dict) -> str:
    Path(base_dir).mkdir(parents=True, exist_ok=True)
    p = Path(base_dir) / f"{form_id}_v{version}.json"
    p.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return p.as_posix()
