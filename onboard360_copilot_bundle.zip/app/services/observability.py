import json, sys, time
def audit(event_type: str, payload: dict):
    record = {"ts": time.time(), "event_type": event_type, "payload": payload}
    sys.stdout.write(json.dumps(record) + "\n"); sys.stdout.flush()
