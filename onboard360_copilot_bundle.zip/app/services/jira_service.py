import requests
def create_issue(base_url: str, user: str, token: str, project_key: str, summary: str, description: str):
    url = f"{base_url}/rest/api/2/issue"
    payload = {"fields": {"project": {"key": project_key},"summary": summary,"description": description,"issuetype": {"name": "Task"}}}
    r = requests.post(url, json=payload, auth=(user, token), timeout=30); r.raise_for_status(); return r.json()
