# Onboard360 AI — Jira Scope Dashboard (MVP)

This MVP lets you:
- Search a **Jira issue key** (restricted by project key).
- Fetch **parent/child/linked issues** recursively up to a depth.
- Parse issue descriptions to extract **Acceptance Criteria** and derive **scopes**.
- Display scopes and a **graph** of relationships in a Streamlit dashboard.

## Quick Start
1. `python -m venv .venv && source .venv/bin/activate`
2. `pip install -r requirements.txt`
3. Copy `.env.example` to `.env` and fill Jira creds.
4. `streamlit run app.py`

> Note: You need Jira API access and an API token.
