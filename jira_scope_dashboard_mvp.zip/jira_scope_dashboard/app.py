import os
import re
import json
import networkx as nx
from pyvis.network import Network
import httpx
import streamlit as st
from pydantic import BaseModel, Field
from markdown import markdown
from io import StringIO

# ------------------ Config & Auth ------------------
st.set_page_config(page_title="Jira Scope Dashboard", layout="wide")
st.title("Onboard360 AI · Jira Scope Dashboard (MVP)")

with st.sidebar:
    st.subheader("Jira Connection")
    jira_base = st.text_input("Jira Base URL", value=os.getenv("JIRA_BASE_URL","https://your-domain.atlassian.net"))
    jira_email = st.text_input("Jira User Email", value=os.getenv("JIRA_EMAIL",""), type="default")
    jira_token = st.text_input("Jira API Token", value=os.getenv("JIRA_API_TOKEN",""), type="password")
    project_key_restrict = st.text_input("Restrict to Project Key", value=os.getenv("JIRA_PROJECT_KEY","SSAT"))
    st.caption("We will only traverse issues within this project key.")
    st.divider()
    root_issue_key = st.text_input("Root Issue Key (e.g., SSAT-1234)")
    max_depth = st.slider("Traversal depth", 1, 6, 3)
    run_btn = st.button("Fetch & Analyze")

headers = {"Accept":"application/json"}

def jira_client():
    auth = (jira_email, jira_token) if jira_email and jira_token else None
    client = httpx.Client(base_url=jira_base, auth=auth, timeout=30.0)
    return client

def get_issue(key:str):
    with jira_client() as client:
        r = client.get(f"/rest/api/3/issue/{key}", headers=headers, params={"expand":"renderedFields"})
        r.raise_for_status()
        return r.json()

def within_project(key:str, project_key:str):
    try:
        return key.upper().startswith(project_key.upper()+"-")
    except:
        return False

# ------------------ Models ------------------
class ScopeItem(BaseModel):
    id: str
    text: str
    status: str = "Not Started"

class IssueNode(BaseModel):
    key: str
    summary: str
    status: str
    issue_type: str
    parent: str|None = None
    children: list[str] = Field(default_factory=list)
    links: list[str] = Field(default_factory=list)
    scopes: list[ScopeItem] = Field(default_factory=list)

# ------------------ Parsing ------------------
AC_HEADERS = [r"^Acceptance Criteria", r"^AC:?", r"^Acceptance:" ]
BULLET = re.compile(r"^(?:[-*]|\d+\.)\s+", re.I)

def extract_acceptance_criteria(desc_text:str)->list[str]:
    if not desc_text:
        return []
    lines = [l.strip() for l in desc_text.splitlines()]
    ac_block = []
    in_ac = False
    for ln in lines:
        if any(re.match(h, ln, flags=re.I) for h in AC_HEADERS):
            in_ac = True
            continue
        if in_ac:
            if ln=="" or re.match(r"^[A-Za-z].*: $", ln):  # naive new section
                if ac_block:
                    break
                else:
                    continue
            ac_block.append(ln)
    # normalize bullets
    items = []
    for ln in ac_block:
        if BULLET.match(ln):
            items.append(BULLET.sub("", ln))
        elif ln:
            items.append(ln)
    if len(items)==1 and ';' in items[0]:
        items = [x.strip() for x in items[0].split(';') if x.strip()]
    return [i for i in items if i]

def default_workflow_steps(text:str)->list[str]:
    steps = []
    lower = text.lower()
    if any(k in lower for k in ["intake","request","form"]): steps.append("Intake Ready")
    if any(k in lower for k in ["api","kafka","topic","iam","apg","key","subscription"]): steps.append("Integration Setup")
    if any(k in lower for k in ["test","uat","validate","sample"]): steps.append("Validation/UAT")
    if any(k in lower for k in ["release","deploy","transition","prod"]): steps.append("Release Prep")
    if not steps: steps = ["Design", "Build", "Validate", "Release"]
    return steps

# ------------------ Traversal ------------------
def collect_tree(root_key:str, project_key:str, max_depth:int=3):
    g = nx.DiGraph()
    nodes: dict[str, IssueNode] = {}
    seen = set()

    def add_issue(key, depth=0, via=None):
        if key in seen or depth>max_depth: return
        seen.add(key)
        try:
            data = get_issue(key)
        except Exception as e:
            st.error(f"Failed to fetch {key}: {e}")
            return

        fields = data.get("fields",{})
        summary = fields.get("summary","(no summary)")
        status = (fields.get("status") or {}).get("name","Unknown")
        issue_type = (fields.get("issuetype") or {}).get("name","Issue")
        desc = fields.get("description") or fields.get("renderedFields",{}).get("description","")

        ac_items = extract_acceptance_criteria(desc if isinstance(desc,str) else "")
        scopes = []
        for i, it in enumerate(ac_items, start=1):
            steps = default_workflow_steps(it)
            scopes.append(ScopeItem(id=f"{key}-S{i}", text=it, status="Not Started"))

        node = IssueNode(
            key=key, summary=summary, status=status, issue_type=issue_type,
            parent=None, children=[], links=[], scopes=scopes
        )
        nodes[key] = node
        g.add_node(key, label=f"{key}: {summary}", status=status, type=issue_type)

        if via:
            node.parent = via
            nodes[via].children.append(key)
            g.add_edge(via, key)

        for stask in fields.get("subtasks",[]) or []:
            skey = stask.get("key")
            if skey and within_project(skey, project_key):
                add_issue(skey, depth+1, via=key)

        parent = (fields.get("parent") or {}).get("key")
        if parent and within_project(parent, project_key):
            if parent not in nodes:
                add_issue(parent, depth+1, via=None)
            nodes[key].parent = parent
            nodes[parent].children.append(key)
            g.add_edge(parent, key)

        for link in fields.get("issuelinks",[]) or []:
            inward = (link.get("inwardIssue") or {}).get("key")
            outward = (link.get("outwardIssue") or {}).get("key")
            for lk in [inward, outward]:
                if lk and within_project(lk, project_key):
                    nodes[key].links.append(lk)
                    add_issue(lk, depth+1, via=key)

    add_issue(root_key, 0, None)
    return g, nodes

# ------------------ UI actions ------------------
if run_btn:
    if not (jira_base and jira_email and jira_token and root_issue_key and project_key_restrict):
        st.error("Please provide Jira base URL, credentials, project key, and a root issue key.")
        st.stop()

    if not within_project(root_issue_key, project_key_restrict):
        st.error(f"Root key {root_issue_key} is not within project {project_key_restrict}")
        st.stop()

    g, nodes = collect_tree(root_issue_key, project_key_restrict, max_depth=max_depth)

    st.subheader("Issue Summary")
    root = nodes.get(root_issue_key)
    if root:
        st.markdown(f"**{root.key} — {root.summary}**  \\ Status: `{root.status}`  | Type: `{root.issue_type}` ")

    with st.expander("Hierarchy & Scopes", expanded=True):
        for key, node in nodes.items():
            st.markdown(f"### {key} · {node.summary}  \\ _{node.issue_type}_ · **{node.status}**")
            if node.scopes:
                for s in node.scopes:
                    st.progress(0, text=f"{s.id}: {s.text} · {s.status}")
            if node.children:
                st.caption("Children: " + ", ".join(node.children))
            if node.links:
                st.caption("Links: " + ", ".join(node.links))
            st.markdown("---")

    st.subheader("Graph of Parent/Child & Links (project-restricted)")
    net = Network(height="600px", width="100%", bgcolor="#ffffff", font_color="black", directed=True)
    for n, data in g.nodes(data=True):
        lbl = data.get("label", n)
        color = "#a3d5ff"
        if data.get("type") == "Epic": color = "#ffd1a3"
        if data.get("type") == "Story": color = "#d1ffa3"
        if data.get("type") == "Task": color = "#f2f2f2"
        net.add_node(n, label=lbl, color=color)
    for u, v in g.edges():
        net.add_edge(u, v)
    html_path = "graph.html"
    net.show(html_path)
    with open(html_path, "r", encoding="utf-8") as f:
        st.components.v1.html(f.read(), height=620, scrolling=True)

    st.subheader("Acceptance Criteria → Derived Scopes (all nodes)")
    scopes = []
    for node in nodes.values():
        for s in node.scopes:
            scopes.append({"issue": node.key, "scope_id": s.id, "text": s.text, "status": s.status})
    if scopes:
        st.dataframe(scopes, use_container_width=True)
    else:
        st.info("No acceptance criteria detected. Add 'Acceptance Criteria' section in issue descriptions to seed scopes.")

    st.success("Done.")

else:
    st.info("Enter Jira connection details and a root issue key, then click **Fetch & Analyze**.")
