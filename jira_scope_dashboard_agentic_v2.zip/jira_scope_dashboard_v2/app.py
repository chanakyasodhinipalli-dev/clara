
import os
import re
import json
import time
import pandas as pd
import plotly.express as px
import networkx as nx
from pyvis.network import Network
import httpx
import streamlit as st
from pydantic import BaseModel, Field
from markdown import markdown
from datetime import date, timedelta
from io import StringIO

# ====================== Agentic A Toolkit (lightweight) ======================
class AgentContext(BaseModel):
    jira_base: str
    jira_email: str
    jira_token: str
    project_key: str

class BaseAgent:
    def __init__(self, ctx: AgentContext):
        self.ctx = ctx

class FetchAgent(BaseAgent):
    def client(self):
        return httpx.Client(base_url=self.ctx.jira_base, auth=(self.ctx.jira_email, self.ctx.jira_token), timeout=30.0)
    def get_issue(self, key: str):
        with self.client() as c:
            r = c.get(f"/rest/api/3/issue/{key}", params={"expand":"renderedFields"})
            r.raise_for_status()
            return r.json()

class ParseAgent(BaseAgent):
    AC_HEADERS = [r"^Acceptance Criteria", r"^AC:?", r"^Acceptance:" ]
    BULLET = re.compile(r"^(?:[-*]|\d+\.)\s+", re.I)
    def extract_acceptance_criteria(self, desc_text: str)->list[str]:
        if not desc_text: return []
        lines = [l.strip() for l in desc_text.splitlines()]
        ac_block, in_ac = [], False
        for ln in lines:
            if any(re.match(h, ln, flags=re.I) for h in self.AC_HEADERS):
                in_ac = True; continue
            if in_ac:
                if ln=="" or re.match(r"^[A-Za-z].*:\s*$", ln):
                    if ac_block: break
                    else: continue
                ac_block.append(ln)
        items = []
        for ln in ac_block:
            if self.BULLET.match(ln): items.append(self.BULLET.sub("", ln))
            elif ln: items.append(ln)
        if len(items)==1 and ";" in items[0]:
            items = [x.strip() for x in items[0].split(";") if x.strip()]
        return [i for i in items if i]
    def detect_dependencies(self, text: str)->list[str]:
        if not text: return []
        keys = re.findall(r"\b[A-Z]{2,10}-\d+\b", text)
        words = ["blocked by", "depends on", "dependency", "waiting for"]
        if any(w in text.lower() for w in words): 
            return list(set(keys))
        return list(set(keys))

class ScopeAgent(BaseAgent):
    WORKFLOW = ["Design","Build","Validate","Release"]
    def derive_steps(self, text: str)->list[str]:
        lower = text.lower()
        s = []
        if any(k in lower for k in ["intake","request","form"]): s.append("Design")
        if any(k in lower for k in ["api","kafka","topic","iam","apg","key","subscription"]): s.append("Build")
        if any(k in lower for k in ["test","uat","validate","sample"]): s.append("Validate")
        if any(k in lower for k in ["release","deploy","transition","prod"]): s.append("Release")
        return s or self.WORKFLOW[:]
    def risk_score(self, due: date, status: str)->int:
        score = 0
        if due:
            days = (due - date.today()).days
            if days < 0: score += min(20, abs(days))
            elif days <= 2: score += 5
        if status in ["Blocked","Waiting"]: score += 10
        return score

class GraphAgent(BaseAgent):
    def build_graph(self, nodes, edges):
        g = nx.DiGraph()
        for k, data in nodes.items():
            g.add_node(k, **data)
        for u, v in edges:
            g.add_edge(u, v)
        return g
    def render(self, g):
        net = Network(height="620px", width="100%", bgcolor="#ffffff", font_color="black", directed=True)
        for n, data in g.nodes(data=True):
            lbl = data.get("label", n)
            color = data.get("color", "#a3d5ff")
            net.add_node(n, label=lbl, color=color, title=lbl)
        for u, v in g.edges():
            net.add_edge(u, v)
        html_path = "graph.html"
        net.show(html_path)
        return html_path

class SyncAgent(BaseAgent):
    def add_comment(self, issue_key: str, text: str):
        with httpx.Client(base_url=self.ctx.jira_base, auth=(self.ctx.jira_email, self.ctx.jira_token)) as c:
            body = {"body": text}
            r = c.post(f"/rest/api/3/issue/{issue_key}/comment", json=body)
            if r.status_code not in (200,201): 
                return False, r.text
            return True, None

# ====================== Data Models ======================
class ScopeItem(BaseModel):
    id: str
    text: str
    step_index: int = 0
    due_date: date|None = None
    owner: str|None = None
    status: str = "Not Started"
    dependencies: list[str] = Field(default_factory=list)

class IssueNode(BaseModel):
    key: str
    summary: str
    status: str
    issue_type: str
    parent: str|None = None
    children: list[str] = Field(default_factory=list)
    links: list[str] = Field(default_factory=list)
    scopes: list[ScopeItem] = Field(default_factory=list)

# ====================== Helpers ======================
def within_project(key:str, project_key:str):
    try: return key.upper().startswith(project_key.upper()+"-")
    except: return False

@st.cache_data(show_spinner=False)
def fetch_tree(ctx: AgentContext, root_key: str, max_depth: int=3):
    fetch = FetchAgent(ctx); parse = ParseAgent(ctx)
    nodes = {}
    edges = []
    seen = set()

    def add_issue(key, depth=0, via=None):
        if key in seen or depth>max_depth: return
        seen.add(key)
        try:
            data = fetch.get_issue(key)
        except Exception as e:
            st.error(f"Failed to fetch {key}: {e}")
            return
        fields = data.get("fields", {})
        summary = fields.get("summary","(no summary)")
        status  = (fields.get("status") or {}).get("name","Unknown")
        issue_type = (fields.get("issuetype") or {}).get("name","Issue")
        desc = fields.get("description") or (data.get("renderedFields") or {}).get("description","")
        desc_text = desc if isinstance(desc,str) else ""

        ac_items = parse.extract_acceptance_criteria(desc_text)
        scopes = []
        scope_agent = ScopeAgent(ctx)
        for i, it in enumerate(ac_items, start=1):
            deps = parse.detect_dependencies(desc_text)
            scopes.append(ScopeItem(
                id=f"{key}-S{i}", text=it, dependencies=[d for d in deps if d!=key]
            ))
        nodes[key] = {
            "label": f"{key}: {summary}",
            "status": status,
            "type": issue_type,
            "color": "#ffd1a3" if issue_type=="Epic" else "#d1ffa3" if issue_type=="Story" else "#a3d5ff"
        }
        if via: edges.append((via, key))

        # subtasks
        for stask in fields.get("subtasks",[]) or []:
            skey = stask.get("key")
            if skey and within_project(skey, ctx.project_key):
                add_issue(skey, depth+1, via=key)
        # parent
        parent = (fields.get("parent") or {}).get("key")
        if parent and within_project(parent, ctx.project_key):
            if parent not in nodes: add_issue(parent, depth+1)
            edges.append((parent, key))
        # links
        for link in fields.get("issuelinks",[]) or []:
            inward = (link.get("inwardIssue") or {}).get("key")
            outward = (link.get("outwardIssue") or {}).get("key")
            for lk in [inward, outward]:
                if lk and within_project(lk, ctx.project_key):
                    edges.append((key, lk))
                    add_issue(lk, depth+1, via=key)

        return ac_items

    add_issue(root_key, 0, None)
    return nodes, edges

# ====================== UI ======================
st.set_page_config(page_title="Onboard360 · Jira Scope Dashboard", layout="wide")
st.title("Onboard360 AI · Jira Scope Dashboard (Agentic MVP)")

with st.sidebar:
    st.subheader("Jira Connection")
    jira_base = st.text_input("Jira Base URL", value=os.getenv("JIRA_BASE_URL","https://your-domain.atlassian.net"))
    jira_email = st.text_input("Jira User Email", value=os.getenv("JIRA_EMAIL",""))
    jira_token = st.text_input("Jira API Token", value=os.getenv("JIRA_API_TOKEN",""), type="password")
    project_key = st.text_input("Project Key Restriction", value=os.getenv("JIRA_PROJECT_KEY","SSAT"))
    root_issue = st.text_input("Root Issue Key", placeholder=f"{project_key}-1234")
    depth = st.slider("Traversal Depth", 1, 6, 3)
    if st.button("Fetch & Build Graph"):
        st.session_state["_ctx"] = AgentContext(
            jira_base=jira_base, jira_email=jira_email, jira_token=jira_token, project_key=project_key
        )
        st.session_state["_root"] = root_issue
        st.session_state["_nodes"], st.session_state["_edges"] = fetch_tree(st.session_state["_ctx"], root_issue, depth)
        st.session_state["_last_pull"] = time.time()

if "_nodes" not in st.session_state:
    st.info("Configure Jira connection and click **Fetch & Build Graph** to begin.")
    st.stop()

ctx = st.session_state["_ctx"]
nodes = st.session_state["_nodes"]
edges = st.session_state["_edges"]

# ====== Portfolio cards ======
col1,col2,col3,col4 = st.columns(4)
col1.metric("Nodes", len(nodes))
col2.metric("Edges", len(edges))
epics = sum(1 for n in nodes.values() if n.get("type")=="Epic")
col3.metric("Epics", epics)
col4.metric("Last Sync (s ago)", int(time.time()-st.session_state.get("_last_pull",0)))

st.divider()

# ====== Interactive Graph ======
st.subheader("Parent/Child/Linked Graph")
ga = GraphAgent(ctx)
g = ga.build_graph(nodes, edges)
html_path = ga.render(g)
with open(html_path, "r", encoding="utf-8") as f:
    st.components.v1.html(f.read(), height=640, scrolling=True)

st.divider()

# ====== Scope board (Kanban-like) ======
st.subheader("Scopes Board (Acceptance Criteria → Work Items)")

if "_scopes" not in st.session_state:
    st.session_state["_scopes"] = {}

# Seed scopes by parsing again with ParseAgent (quick pass)
parse = ParseAgent(ctx)
fetch = FetchAgent(ctx)
scope_agent = ScopeAgent(ctx)

def seed_scopes_for_issue(key):
    try:
        data = fetch.get_issue(key)
    except Exception as e:
        st.error(f"Failed to refetch {key}: {e}")
        return []
    fields = data.get("fields", {})
    desc = fields.get("description") or (data.get("renderedFields") or {}).get("description","")
    desc_text = desc if isinstance(desc,str) else ""
    ac_items = parse.extract_acceptance_criteria(desc_text)
    deps = parse.detect_dependencies(desc_text)
    scopes = []
    for i, it in enumerate(ac_items, start=1):
        scopes.append({
            "issue": key,
            "scope_id": f"{key}-S{i}",
            "text": it,
            "step_index": 0,
            "status": "Not Started",
            "owner": "",
            "due_date": str(date.today()+timedelta(days=7)),
            "dependencies": [d for d in deps if d!=key]
        })
    return scopes

# create/refresh button
if st.button("Refresh Scopes from Issues"):
    all_scopes = []
    for key in nodes.keys():
        all_scopes.extend(seed_scopes_for_issue(key))
    for sc in all_scopes:
        st.session_state["_scopes"][sc["scope_id"]] = sc
    st.success(f"Seeded/updated {len(all_scopes)} scopes from Acceptance Criteria.")

# Manage scopes table
scopes_df = pd.DataFrame(list(st.session_state["_scopes"].values())) if st.session_state["_scopes"] else pd.DataFrame(columns=["issue","scope_id","text","step_index","status","owner","due_date","dependencies"])
st.dataframe(scopes_df, use_container_width=True)

# ====== Gantt Timeline ======
st.subheader("Scope Timeline (Gantt)")
if not scopes_df.empty:
    # convert dates
    df = scopes_df.copy()
    df["Start"] = pd.to_datetime(date.today())
    df["Finish"] = pd.to_datetime(df["due_date"], errors="coerce")
    fig = px.timeline(df, x_start="Start", x_end="Finish", y="scope_id", color="status", hover_data=["text","issue","owner"])
    fig.update_yaxes(autorange="reversed")
    st.plotly_chart(fig, use_container_width=True)
else:
    st.info("No scopes yet. Click **Refresh Scopes from Issues**.")

# ====== Risk & Dependencies ======
st.subheader("Risks & Dependencies")
if not scopes_df.empty:
    scopes_df["risk"] = scopes_df.apply(lambda r: ScopeAgent(ctx).risk_score(pd.to_datetime(r["due_date"], errors="coerce").date() if r["due_date"] else None, r["status"]), axis=1)
    risky = scopes_df[scopes_df["risk"]>=10].sort_values("risk", ascending=False)
    st.write("**At-Risk Scopes (≥10):**")
    st.dataframe(risky[["scope_id","issue","status","owner","due_date","risk","dependencies","text"]], use_container_width=True)
else:
    st.info("No risk computed.")

# ====== Inline updates (single-page UX) ======
st.subheader("Update Scope Inline")
with st.form("update_scope"):
    sid = st.selectbox("Scope ID", options=list(scopes_df["scope_id"]) if not scopes_df.empty else [])
    new_status = st.selectbox("Status", options=["Not Started","In Progress","Waiting","Blocked","Ready","Done"])
    new_owner = st.text_input("Owner (email or name)")
    new_due = st.date_input("Due Date", value=date.today()+timedelta(days=7))
    add_comment = st.checkbox("Post update as Jira comment (root issue)")
    submitted = st.form_submit_button("Update")
    if submitted and sid:
        st.session_state["_scopes"][sid]["status"] = new_status
        st.session_state["_scopes"][sid]["owner"] = new_owner
        st.session_state["_scopes"][sid]["due_date"] = str(new_due)
        st.success(f"Updated {sid}.")
        if add_comment and "_root" in st.session_state:
            ok, err = SyncAgent(ctx).add_comment(st.session_state["_root"], f"Scope {sid} updated: {new_status} | owner={new_owner} | due={new_due}")
            if ok: st.info("Comment posted to Jira.")
            else: st.warning(f"Failed to post comment: {err}")

st.caption("All features run in a single-page UI. Agents: FetchAgent (Jira), ParseAgent (AC & deps), ScopeAgent (workflow/risk), GraphAgent (networks), SyncAgent (write-backs).")
