# Onboard360 AI — Jira Scope Dashboard (Agentic MVP v2)

**What’s new in v2 (single-page UX):**
- Agentic toolkit with agents: `FetchAgent`, `ParseAgent`, `ScopeAgent`, `GraphAgent`, `SyncAgent`.
- Interactive **graph** of parent/child/linked Jira issues.
- Extract **Acceptance Criteria → Scopes** and manage them inline.
- **Gantt timeline** for scope due dates.
- **Risk & dependency** view.
- Inline updates with optional **Jira comment** write-back.

## Run
1. `python -m venv .venv && source .venv/bin/activate`
2. `pip install -r requirements.txt`
3. `streamlit run app.py` (set Jira creds in sidebar)

> Set env vars JIRA_BASE_URL, JIRA_EMAIL, JIRA_API_TOKEN, JIRA_PROJECT_KEY or type them in sidebar.
