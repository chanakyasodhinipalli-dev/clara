package ai.clara.convertedagent;

import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/echo")
public class EchoController {
    @PostMapping
    public Map<String,Object> echo(@RequestBody Map<String,Object> body) {
        return Map.of("module","converted-agent","received",body);
    }
}
