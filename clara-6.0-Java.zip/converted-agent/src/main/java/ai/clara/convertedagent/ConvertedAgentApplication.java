package ai.clara.convertedagent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConvertedAgentApplication {
    public static void main(String[] args) {
        SpringApplication.run(ConvertedAgentApplication.class, args);
    }
}
