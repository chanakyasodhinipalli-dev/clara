package ai.clara.groupingagent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroupingAgentApplication {
    public static void main(String[] args) {
        SpringApplication.run(GroupingAgentApplication.class, args);
    }
}
