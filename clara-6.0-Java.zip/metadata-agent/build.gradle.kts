plugins {
    id("org.springframework.boot")
    id("io.spring.dependency-management")
    java
}

description = "Metadata Agent"

dependencies {
    implementation("org.springframework.boot:spring-boot-starter-web")
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation(project(":common"))
    implementation("org.apache.pdfbox:pdfbox:2.0.30")

    testImplementation("org.springframework.boot:spring-boot-starter-test")
}

tasks.jar {
    enabled = true
}
