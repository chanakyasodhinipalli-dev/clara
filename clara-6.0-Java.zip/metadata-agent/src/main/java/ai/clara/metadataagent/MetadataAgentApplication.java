package ai.clara.metadataagent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetadataAgentApplication {
    public static void main(String[] args) {
        SpringApplication.run(MetadataAgentApplication.class, args);
    }
}
