package ai.clara.metadataagent;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.springframework.http.MediaType;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.io.ByteArrayInputStream;
import java.util.Map;

@RestController
@RequestMapping("/metadata")
public class MetadataController {

    @PostMapping(value="/pdf", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Mono<Map<String,Object>> pdf(@RequestPart("file") FilePart file) {
        return file.content().aggregate().asByteArray().map(bytes -> {
            try (PDDocument doc = PDDocument.load(new ByteArrayInputStream(bytes))) {
                return Map.of("pages", doc.getNumberOfPages());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }
}
