package ai.clara.mergeragent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MergerAgentApplication {
    public static void main(String[] args) {
        SpringApplication.run(MergerAgentApplication.class, args);
    }
}
