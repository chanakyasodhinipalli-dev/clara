package ai.clara.mergeragent;

import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Base64;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/merge")
public class MergerController {

    public record MergeRequest(List<String> documentsBase64) {}

    @PostMapping(value="/pdf", consumes = MediaType.APPLICATION_JSON_VALUE)
    public Mono<Map<String,Object>> merge(@RequestBody MergeRequest req) {
        return Mono.fromSupplier(() -> {
            try {
                PDFMergerUtility util = new PDFMergerUtility();
                for (String b64 : req.documentsBase64()) {
                    util.addSource(new ByteArrayInputStream(Base64.getDecoder().decode(b64)));
                }
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                util.setDestinationStream(out);
                util.mergeDocuments(null);
                String result = Base64.getEncoder().encodeToString(out.toByteArray());
                return Map.of("mergedBase64", result);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }
}
