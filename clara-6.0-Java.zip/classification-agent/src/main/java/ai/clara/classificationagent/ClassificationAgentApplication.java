package ai.clara.classificationagent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassificationAgentApplication {
    public static void main(String[] args) {
        SpringApplication.run(ClassificationAgentApplication.class, args);
    }
}
