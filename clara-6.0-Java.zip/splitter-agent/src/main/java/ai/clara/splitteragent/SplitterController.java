package ai.clara.splitteragent;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.multipdf.Splitter;
import org.springframework.http.MediaType;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.*;

@RestController
@RequestMapping("/split")
public class SplitterController {

    @PostMapping(value="/pdf", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Mono<Map<String,Object>> splitPdf(@RequestPart("file") FilePart file) {
        return file.content().aggregate().asByteArray().map(bytes -> {
            try (PDDocument doc = PDDocument.load(new ByteArrayInputStream(bytes))) {
                Splitter splitter = new Splitter();
                List<PDDocument> pages = splitter.split(doc);
                List<String> encoded = new ArrayList<>();
                for (PDDocument p : pages) {
                    try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                        p.save(out);
                        encoded.add(Base64.getEncoder().encodeToString(out.toByteArray()));
                    }
                }
                return Map.of("pages", encoded.size(), "documentsBase64", encoded);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }
}
