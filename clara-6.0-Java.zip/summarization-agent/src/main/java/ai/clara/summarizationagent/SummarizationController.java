package ai.clara.summarizationagent;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.MediaType;
import org.springframework.http.codec.multipart.FilePart;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/summarize")
public class SummarizationController {

    @PostMapping(value="/text", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Mono<Map<String,Object>> summarize(@RequestPart("file") FilePart file) {
        return file.content().aggregate().asByteArray().map(bytes -> {
            String text = new String(bytes, StandardCharsets.UTF_8);
            String first = text.lines().findFirst().orElse("");
            return Map.of(
                "language", "en",
                "sentences", List.of(first.isBlank() ? "No text content detected." : first),
                "keywords", List.of()
            );
        });
    }
}
