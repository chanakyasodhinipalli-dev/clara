plugins {
    id("org.springframework.boot")
    id("io.spring.dependency-management")
    java
}

description = "Summarization Agent"

dependencies {
    implementation("org.springframework.boot:spring-boot-starter-web")
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation(project(":common"))
    implementation("org.springframework.ai:spring-ai-openai-spring-boot-starter:1.0.0-M3")

    testImplementation("org.springframework.boot:spring-boot-starter-test")
}

tasks.jar {
    enabled = true
}
