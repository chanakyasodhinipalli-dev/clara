package ai.clara.preprocessoragent;

import org.apache.tika.Tika;
import org.springframework.http.MediaType;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/preprocess")
public class PreprocessController {
    private final Tika tika = new Tika();

    @PostMapping(value = "/detect", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Mono<Map<String, Object>> detect(@RequestPart("file") FilePart file) {
        return file.content().aggregate().asByteArray().map(bytes -> {
            String mt = tika.detect(bytes, file.filename());
            return Map.of(
                "jobId", UUID.randomUUID().toString(),
                "filename", file.filename(),
                "mediaType", mt
            );
        });
    }
}
