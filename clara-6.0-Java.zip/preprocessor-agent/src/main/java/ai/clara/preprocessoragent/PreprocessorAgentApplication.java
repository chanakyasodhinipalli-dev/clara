package ai.clara.preprocessoragent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PreprocessorAgentApplication {
    public static void main(String[] args) {
        SpringApplication.run(PreprocessorAgentApplication.class, args);
    }
}
