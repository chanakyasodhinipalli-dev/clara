plugins {
    java
}

dependencies {
    api("com.fasterxml.jackson.core:jackson-databind:2.17.2")
    api("org.apache.tika:tika-core:2.9.2")
    api("org.apache.pdfbox:pdfbox:2.0.30")
}
