package ai.clara.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

public class McpSchemas {
    private static final ObjectMapper om = new ObjectMapper();

    public static Map<String,Object> load(String name) {
        String path = "/mcp/schemas/" + name + ".json";
        try (InputStream is = McpSchemas.class.getResourceAsStream(path)) {
            if (is == null) throw new IllegalArgumentException("Schema not found: " + path);
            return om.readValue(is, Map.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
