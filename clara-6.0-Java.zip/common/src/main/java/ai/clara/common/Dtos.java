package ai.clara.common;

import java.util.Map;
import java.util.List;

public record DocumentJob(
    String jobId,
    String filename,
    String mediaType,
    byte[] content,
    Map<String, Object> metadata
) {}

public record AgentResult(
    String agent,
    String status,
    Map<String, Object> data,
    List<String> logs
) {}
