plugins {
    id("org.springframework.boot")
    id("io.spring.dependency-management")
    java
}

description = "Examples and fixtures"

dependencies {
    implementation("org.springframework.boot:spring-boot-starter-web")
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation(project(":common"))

    testImplementation("org.springframework.boot:spring-boot-starter-test")
}

tasks.jar {
    enabled = true
}
