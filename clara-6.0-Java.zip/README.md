# Clara 6.0 (Java + Spring AI + MCP)

Enterprise-grade, multi-module Gradle project implementing an Agentic AI Workflow Orchestrator with Spring patterns.

## Build

```bash
./gradlew clean build
```

## Run (example)

```bash
./gradlew :orchestrator:bootRun
```

## Modules

- `common`: DTOs, MCP schemas
- `orchestrator`: Workflow engine (chain/parallel demo)
- Agents: preprocessor, splitter, merger, summarization, metadata, etc.
- `api-gateway`: unified API façade
