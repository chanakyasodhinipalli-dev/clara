import org.gradle.kotlin.dsl.dependencies

plugins {
    id("org.springframework.boot") version "3.3.3" apply false
    id("io.spring.dependency-management") version "1.1.6" apply false
    java
}

allprojects {
    group = "ai.clara"
    version = "6.0.0"
    repositories {
        mavenCentral()
        maven { url = uri("https://repo.spring.io/release") }
    }
}

subprojects {
    apply(plugin = "java")
    apply(plugin = "io.spring.dependency-management")

    java {
        toolchain {
            languageVersion.set(JavaLanguageVersion.of(21))
        }
    }

    tasks.withType<JavaCompile> {
        options.encoding = "UTF-8"
    }

    dependencies {
        constraints {
            api("org.springframework.boot:spring-boot-dependencies:3.3.3")
            api(platform("org.springframework.ai:spring-ai-bom:1.0.0-M3"))
        }
        testImplementation("org.junit.jupiter:junit-jupiter:5.10.3")
    }

    tasks.test {
        useJUnitPlatform()
    }
}
