package ai.clara.ocragent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OcrAgentApplication {
    public static void main(String[] args) {
        SpringApplication.run(OcrAgentApplication.class, args);
    }
}
