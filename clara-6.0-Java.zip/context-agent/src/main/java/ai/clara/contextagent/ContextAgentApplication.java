package ai.clara.contextagent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContextAgentApplication {
    public static void main(String[] args) {
        SpringApplication.run(ContextAgentApplication.class, args);
    }
}
