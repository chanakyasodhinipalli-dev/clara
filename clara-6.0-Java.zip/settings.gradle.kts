rootProject.name = "clara-6.0"

include(
    "common",
    "orchestrator",
    "api-gateway",
    "preprocessor-agent",
    "splitter-agent",
    "merger-agent",
    "context-agent",
    "translation-agent",
    "summarization-agent",
    "classification-agent",
    "metadata-agent",
    "grouping-agent",
    "converted-agent",
    "ocr-agent",
    "examples"
)
