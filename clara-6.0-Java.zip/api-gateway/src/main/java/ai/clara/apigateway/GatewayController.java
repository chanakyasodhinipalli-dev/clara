package ai.clara.apigateway;

import org.springframework.http.MediaType;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api")
public class GatewayController {

    @PostMapping(value="/process", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Mono<String> process(@RequestPart("file") FilePart file) {
        return Mono.just("Received: " + file.filename());
    }
}
