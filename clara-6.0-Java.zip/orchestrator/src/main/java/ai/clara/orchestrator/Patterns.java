package ai.clara.orchestrator;

import ai.clara.common.AgentResult;
import ai.clara.common.DocumentJob;

import java.util.*;
import java.util.concurrent.*;
import java.util.function.Function;

public class Patterns {

    public static List<AgentResult> chain(DocumentJob job, List<Function<DocumentJob, AgentResult>> steps) {
        List<AgentResult> results = new ArrayList<>();
        for (Function<DocumentJob, AgentResult> step : steps) {
            AgentResult r = step.apply(job);
            results.add(r);
        }
        return results;
    }

    public static List<AgentResult> parallel(DocumentJob job, List<Function<DocumentJob, AgentResult>> workers) {
        ExecutorService exec = Executors.newFixedThreadPool(Math.max(2, workers.size()));
        try {
            List<Future<AgentResult>> futures = new ArrayList<>();
            for (Function<DocumentJob, AgentResult> w : workers) {
                futures.add(exec.submit(() -> w.apply(job)));
            }
            List<AgentResult> out = new ArrayList<>();
            for (Future<AgentResult> f : futures) out.add(f.get());
            return out;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            exec.shutdown();
        }
    }
}
