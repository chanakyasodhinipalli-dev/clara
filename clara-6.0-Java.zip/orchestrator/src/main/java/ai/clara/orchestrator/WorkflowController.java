package ai.clara.orchestrator;

import ai.clara.common.AgentResult;
import ai.clara.common.DocumentJob;
import org.springframework.http.MediaType;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.*;

@RestController
@RequestMapping("/workflow")
public class WorkflowController {

    @PostMapping(value="/process", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Mono<Map<String,Object>> process(@RequestPart("file") FilePart file) {
        return file.content().aggregate().asByteArray().map(bytes -> {
            DocumentJob job = new DocumentJob(UUID.randomUUID().toString(), file.filename(), "application/octet-stream", bytes, Map.of());
            List<AgentResult> results = List.of(
                new AgentResult("preprocessor", "OK", Map.of("detected","binary"), List.of("processed")),
                new AgentResult("summarizer", "OK", Map.of("sentences", List.of("Summary sample output")), List.of()),
                new AgentResult("metadata", "OK", Map.of("pages", 1), List.of())
            );
            return Map.of("jobId", job.jobId(), "results", results);
        });
    }
}
