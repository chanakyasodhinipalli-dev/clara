import React from 'react'
import Header from '../../components/Header'
import { Tabs } from '../../components/Tabs'
import SimpleTable from '../../components/SimpleTable'
import ChatbotDrawer from '../../components/ChatbotDrawer'

export default function OTM(){
  const [active,setActive]=React.useState('Dashboard')
  const [data,setData]=React.useState<any>(null)
  const [chatOpen,setChatOpen]=React.useState(false)
  const [threadId,setThreadId]=React.useState<string|null>(null)

  React.useEffect(()=>{
    const map:any = {
      'Dashboard':'/api/otm/dashboard',
      'Current Sprint Activities':'/api/otm/sprint',
      'My Action Items':'/api/otm/my-action-items',
      'Team Action Items':'/api/otm/team-action-items'
    }
    fetch(map[active],{credentials:'include'}).then(r=>r.json()).then(setData)
  },[active])

  return <div>
    <Header/>
    <Tabs items={['Dashboard','Current Sprint Activities','My Action Items','Team Action Items']} active={active} onSelect={setActive}/>
    <div className='container'>
      {active==='Dashboard' && data && <div className='card'><pre>{JSON.stringify(data,null,2)}</pre></div>}
      {active==='Current Sprint Activities' && data && <div>
        {data.map((f:any)=>(<div key={f.key} className='card'>
          <strong>{f.key} — {f.name}</strong>
          {f.tasks.map((t:any)=>(<div key={t.id} style={{display:'flex',justifyContent:'space-between'}}>
            <span>{t.title} — {t.status}</span>
            <button className='button' onClick={()=>setChatOpen(true)}>Chat</button>
          </div>))}
        </div>))}
      </div>}
      {(active==='My Action Items' || active==='Team Action Items') && data && <div className='card'>
        <SimpleTable columns={['ID','Title','Status','Assignee']} rows={data.map((r:any)=>[r.id,r.title,r.status,r.assignee])}/>
      </div>}
    </div>
    <ChatbotDrawer open={chatOpen} onClose={()=>setChatOpen(false)} threadId={threadId} setThreadId={setThreadId}/>
  </div>
}