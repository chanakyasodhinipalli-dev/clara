import React from 'react'
import { useAuthStore } from '../../store/auth'
export default function Login(){
  const [username,setUsername]=React.useState('partner1')
  const [password,setPassword]=React.useState('P@ssw0rd!')
  const [err,setErr]=React.useState<string|null>(null)
  const submit=async(e:React.FormEvent)=>{
    e.preventDefault(); setErr(null)
    const r=await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({username,password})})
    if(r.ok){ const d=await r.json(); useAuthStore.getState().setUser(d.user) } else setErr('Login failed')
  }
  return <div className='login'>
    <h2>Login</h2>
    <form onSubmit={submit}>
      <input className='input' value={username} onChange={e=>setUsername(e.target.value)} placeholder='Username'/>
      <input className='input' type='password' value={password} onChange={e=>setPassword(e.target.value)} placeholder='Password'/>
      {err && <div style={{color:'red'}}>{err}</div>}
      <button className='button' type='submit'>Login</button>
    </form>
  </div>
}