import React from 'react'
import Header from '../../components/Header'
import { Tabs } from '../../components/Tabs'
import SimpleTable from '../../components/SimpleTable'
import ChatbotDrawer from '../../components/ChatbotDrawer'

type Intake = {key:string, summary:string, status:string, fixVersion?:string, targetVersion?:string, stages:any[]}

export default function Partner(){
  const [active,setActive]=React.useState('Dashboard')
  const [counts,setCounts]=React.useState({draft:0,submitted:0,completed:0})
  const [list,setList]=React.useState<Intake[]>([])
  const [showTable,setShowTable]=React.useState(false)
  const [chatOpen,setChatOpen]=React.useState(false)
  const [threadId,setThreadId]=React.useState<string|null>(null)

  React.useEffect(()=>{
    if(active==='Dashboard'){
      fetch('/api/partner/dashboard',{credentials:'include'}).then(r=>r.json()).then(d=>{setCounts({draft:d.draft,submitted:d.submitted,completed:d.completed}); setList(d.list)})
    }
    if(active==='Track my Intakes'){
      fetch('/api/partner/intakes',{credentials:'include'}).then(r=>r.json()).then(d=>setList(d))
    }
  },[active])

  return <div>
    <Header/>
    <Tabs items={['Dashboard','Raise New Intake','Track my Intakes','My Action Items']} active={active} onSelect={setActive}/>
    <div className='container'>
      {active==='Dashboard' && <div>
        <div className='grid'>
          <div className='card'><div>Draft Intakes</div><h2 className='link' onClick={()=>setShowTable(true)}>{counts.draft}</h2></div>
          <div className='card'><div>Submitted Intakes</div><h2 className='link' onClick={()=>setShowTable(true)}>{counts.submitted}</h2></div>
          <div className='card'><div>Completed Intakes</div><h2 className='link' onClick={()=>setShowTable(true)}>{counts.completed}</h2></div>
        </div>
        {showTable && <div className='card'>
          <SimpleTable columns={['Key','Summary','Status','Fix Version','Target Version']}
            rows={list.map(i=>[i.key,i.summary,i.status,i.fixVersion||'-',i.targetVersion||'-'])}/>
        </div>}
      </div>}

      {active==='Raise New Intake' && <div className='card'>
        <p>Start a new intake using the chatbot. You can upload documents too.</p>
        <button className='button' onClick={()=>setChatOpen(true)}>Open Chatbot</button>
      </div>}

      {active==='Track my Intakes' && <div>
        {list.map(i=>(
          <div className='card' key={i.key}>
            <strong>{i.key} — {i.summary}</strong>
            <div style={{marginTop:8, display:'flex', gap:8}}>
              {i.stages.map((s:any,idx:number)=>{
                const cls = s.state==='completed'?'badge': s.state==='ongoing' ? 'badge '+(s.health||'') : 'badge'
                const style: any = s.state==='completed' ? {opacity:.5} : {}
                return <span key={idx} className={cls} style={style}>{s.name}</span>
              })}
            </div>
          </div>
        ))}
      </div>}

      {active==='My Action Items' && <MyActions openChat={()=>setChatOpen(true)} />}
    </div>
    <ChatbotDrawer open={chatOpen} onClose={()=>setChatOpen(false)} threadId={threadId} setThreadId={setThreadId}/>
  </div>
}

function MyActions({openChat}:{openChat:()=>void}){
  const [rows,setRows]=React.useState<any[]>([])
  const [panel,setPanel]=React.useState<any|null>(null)
  React.useEffect(()=>{
    fetch('/api/partner/action-items',{credentials:'include'}).then(r=>r.json()).then(d=>setRows(d))
  },[])
  return <div className='card'>
    <SimpleTable columns={['ID','Title','Status']}
      rows={rows.map((r:any)=>[r.id, r.title, r.status])}/>
    <div style={{marginTop:8}}>
      <p>Select a row to see details →</p>
      {rows.map((r:any)=>(<div key={r.id} className='link' onClick={()=>setPanel(r)}>{r.id}: {r.title}</div>))}
    </div>
    {panel && <div className='card'>
      <h3>{panel.title}</h3>
      <p>{panel.details}</p>
      <button className='button' onClick={openChat}>Chat</button>
    </div>}
  </div>
}
