import React from 'react'
import Header from '../../components/Header'
import { Tabs } from '../../components/Tabs'
import SimpleTable from '../../components/SimpleTable'

export default function PO(){
  const [active,setActive]=React.useState('Dashboard')
  const [data,setData]=React.useState<any>(null)
  React.useEffect(()=>{
    const map:any = {'Dashboard':'/api/po/dashboard','Current Sprint Activities':'/api/po/sprint','My Action Items':'/api/po/my-action-items','Team Action Items':'/api/po/team-action-items'}
    fetch(map[active],{credentials:'include'}).then(r=>r.json()).then(setData)
  },[active])
  return <div>
    <Header/>
    <Tabs items={['Dashboard','Current Sprint Activities','My Action Items','Team Action Items']} active={active} onSelect={setActive}/>
    <div className='container'>
      {active==='Dashboard' && data && <div className='card'><pre>{JSON.stringify(data.charts,null,2)}</pre></div>}
      {active==='Current Sprint Activities' && data && <div className='card'><pre>{JSON.stringify(data,null,2)}</pre></div>}
      {(active==='My Action Items' || active==='Team Action Items') && data && <div className='card'><SimpleTable columns={['ID','Title','Status','Assignee']} rows={data.map((r:any)=>[r.id,r.title,r.status,r.assignee])}/></div>}
    </div>
  </div>
}