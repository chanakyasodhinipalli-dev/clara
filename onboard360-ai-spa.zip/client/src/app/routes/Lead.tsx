import React from 'react'
import Header from '../../components/Header'
import { Tabs } from '../../components/Tabs'
import SimpleTable from '../../components/SimpleTable'
import { Bar } from 'react-chartjs-2'
import { Chart as ChartJS, BarElement, CategoryScale, LinearScale, Tooltip, Legend } from 'chart.js'
ChartJS.register(BarElement, CategoryScale, LinearScale, Tooltip, Legend)

export default function Lead(){
  const [active,setActive]=React.useState('Dashboard')
  const [data,setData]=React.useState<any>(null)
  React.useEffect(()=>{
    const path = active==='Dashboard' ? '/api/lead/dashboard' : '/api/lead/my-action-items'
    fetch(path,{credentials:'include'}).then(r=>r.json()).then(setData)
  },[active])
  return <div>
    <Header/>
    <Tabs items={['Dashboard','My Action Items']} active={active} onSelect={setActive}/>
    <div className='container'>
      {active==='Dashboard' && data && <div className='card'>
        <Bar data={{labels:Object.keys(data.charts.intakesByStatus), datasets:[{label:'Intakes', data:Object.values(data.charts.intakesByStatus)}]}}/>
      </div>}
      {active==='My Action Items' && data && <div className='card'>
        <SimpleTable columns={['ID','Title','Status']} rows={data.map((r:any)=>[r.id,r.title,r.status])}/>
      </div>}
    </div>
  </div>
}