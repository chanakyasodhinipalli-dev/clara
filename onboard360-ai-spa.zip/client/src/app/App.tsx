import React from 'react'
import { Routes, Route } from 'react-router-dom'
import { useAuthStore, type User } from '../store/auth'
import Login from './routes/Login'
import Partner from './routes/Partner'
import OTM from './routes/OTM'
import Lead from './routes/Lead'
import PO from './routes/PO'

export default function App(){
  const user = useAuthStore(s=>s.user)
  React.useEffect(()=>{
    fetch('/api/auth/me',{credentials:'include'}).then(r=>r.ok?r.json():null).then((u:User|null)=>{ if(u) useAuthStore.getState().setUser(u) })
  },[])
  if(!user) return <Login/>
  return (
    <Routes>
      {user.role==='partner_user' && <Route path='/*' element={<Partner/>} />}
      {user.role==='onboarding_team_member' && <Route path='/*' element={<OTM/>} />}
      {user.role==='icmp_leadership' && <Route path='/*' element={<Lead/>} />}
      {user.role==='product_owner' && <Route path='/*' element={<PO/>} />}
    </Routes>
  )
}