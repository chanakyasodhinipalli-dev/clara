import { create } from 'zustand'
export type User = { id:string, username:string, role:string, fullName:string }
type State = { user: User | null, setUser:(u:User|null)=>void }
export const useAuthStore = create<State>((set)=>({ user:null, setUser:(u)=>set({user:u}) }))