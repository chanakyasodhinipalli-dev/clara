import React from 'react'
export function Tabs({items, active, onSelect}:{items:string[], active:string, onSelect:(k:string)=>void}){
  return <div className='tabs'>
    {items.map(k=>(<div key={k} className={'tab'+(k===active?' active':'')} onClick={()=>onSelect(k)}>{k}</div>))}
  </div>
}