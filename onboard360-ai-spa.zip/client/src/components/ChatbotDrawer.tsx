import React from 'react'
import Drawer from './Drawer'
export default function ChatbotDrawer({open,onClose,threadId,setThreadId}:{open:boolean,onClose:()=>void,threadId:string|null,setThreadId:(id:string)=>void}){
  const [messages,setMessages]=React.useState<{from:string,text:string}[]>([])
  const [text,setText]=React.useState('')
  const send = async ()=>{
    const r = await fetch('/api/chat/send',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({threadId,message:text})})
    const d = await r.json(); setThreadId(d.threadId); setMessages(d.messages); setText('')
  }
  const onFile = async (e:React.ChangeEvent<HTMLInputElement>)=>{
    if(!e.target.files?.length) return
    const fd = new FormData(); fd.append('file', e.target.files[0])
    await fetch('/api/chat/upload',{method:'POST',credentials:'include',body:fd})
  }
  return <Drawer open={open} onClose={onClose} title='Chatbot'>
    <div style={{height:'60vh',overflow:'auto',border:'1px solid #eee',padding:8}}>
      {messages.map((m,i)=><div key={i}><strong>{m.from}:</strong> {m.text}</div>)}
    </div>
    <div style={{marginTop:8}}>
      <input value={text} onChange={e=>setText(e.target.value)} className='input' placeholder='Type message (e.g., "create intake")'/>
      <div style={{display:'flex',gap:8,marginTop:8}}>
        <button className='button' onClick={send}>Send</button>
        <label className='button'><input type='file' style={{display:'none'}} onChange={onFile}/>Upload</label>
      </div>
    </div>
  </Drawer>
}