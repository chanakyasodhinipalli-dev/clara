import React from 'react'
import { useAuthStore } from '../store/auth'
export default function Header(){
  const user = useAuthStore(s=>s.user)!
  const logout = async ()=>{ await fetch('/api/auth/logout',{method:'POST',credentials:'include'}); useAuthStore.getState().setUser(null); location.reload() }
  return <div className='header'>
    <div><strong>Welcome to Onboard360 AI</strong>, a one-stop for all your ICMP Onboarding Journey</div>
    <div>{user.fullName} ({user.role}) <button className='button' onClick={logout} style={{marginLeft:8}}>Logout</button></div>
  </div>
}