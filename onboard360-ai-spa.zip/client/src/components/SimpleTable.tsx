import React from 'react'
export default function SimpleTable({columns, rows}:{columns:string[], rows:(string|number)[][]}){
  return (<table className='table'>
    <thead><tr>{columns.map(c=><th key={c}>{c}</th>)}</tr></thead>
    <tbody>{rows.map((r,i)=>(<tr key={i}>{r.map((c,j)=><td key={j}>{c}</td>)}</tr>))}</tbody>
  </table>)
}