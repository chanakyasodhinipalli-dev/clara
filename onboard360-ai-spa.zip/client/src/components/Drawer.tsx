import React from 'react'
export default function Drawer({open,title,children,onClose}:{open:boolean,title:string,children:any,onClose:()=>void}){
  return <div style={{position:'fixed',top:0,right:0,width:380,height:'100vh',background:'#fff',borderLeft:'1px solid #ddd',boxShadow:'-4px 0 12px rgba(0,0,0,.06)',padding:12,transform:`translateX(${open?0:100}%)`,transition:'transform .2s'}}>
    <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}><h3>{title}</h3><button className='button' onClick={onClose}>Close</button></div>
    <div>{children}</div>
  </div>
}