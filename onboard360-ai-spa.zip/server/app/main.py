
from fastapi import FastAPI, Request, HTTPException, Response, UploadFile, File, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
import os, json, casbin

BASE = os.path.dirname(__file__)
DATA = os.path.join(BASE, "data")
MOCK = os.path.join(DATA, "mock")
CASBIN_DIR = os.path.join(BASE, "casbin")
UPLOADS = os.path.join(BASE, "uploads")

with open(os.path.join(DATA, "users.json"), "r") as f:
    USERS = json.load(f)

def get_user_by_name(username: str):
    for u in USERS:
        if u["username"] == username:
            return u
    return None

def current_user(request: Request):
    uname = request.cookies.get("session")
    if not uname: 
        return None
    return get_user_by_name(uname)

enforcer = casbin.Enforcer(os.path.join(CASBIN_DIR, "model.conf"), os.path.join(CASBIN_DIR, "policy.csv"))

def require(obj: str, act: str):
    def _inner(request: Request):
        user = current_user(request)
        if not user:
            raise HTTPException(401, "Not authenticated")
        if not enforcer.enforce(user["role"], obj, act):
            raise HTTPException(403, "Forbidden")
        return user
    return _inner

app = FastAPI(title="Onboard360 AI API")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173","http://127.0.0.1:5173"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.mount("/uploads", StaticFiles(directory=UPLOADS), name="uploads")

@app.get("/api/health")
def health(): return {"ok": True}

# ---- Auth ----
@app.post("/api/auth/login")
def login(payload: dict, response: Response):
    uname, pwd = payload.get("username"), payload.get("password")
    user = get_user_by_name(uname)
    if not user or user["password"] != pwd:
        raise HTTPException(401, "Invalid credentials")
    response.set_cookie("session", uname, httponly=True, samesite="Lax")
    return {"user": {k: user[k] for k in ["id","username","role","fullName"]}, "token": "session-cookie"}

@app.post("/api/auth/logout")
def logout(response: Response):
    response.delete_cookie("session")
    return {"ok": True}

@app.get("/api/auth/me")
def me(request: Request):
    user = current_user(request)
    if not user:
        raise HTTPException(401, "Not authenticated")
    return {k: user[k] for k in ["id","username","role","fullName"]}

# ---- Partner ----
@app.get("/api/partner/dashboard")
def partner_dashboard(user = Depends(require("partner:dashboard","read"))):
    with open(os.path.join(MOCK,"intakes.json")) as f:
        all_intakes = json.load(f)
    mine = [i for i in all_intakes if i["ownerUserId"]==user["username"]]
    counts = {
        "draft": sum(1 for i in mine if i["status"]=="draft"),
        "submitted": sum(1 for i in mine if i["status"]=="submitted"),
        "completed": sum(1 for i in mine if i["status"]=="completed"),
    }
    return {"draft": counts["draft"], "submitted": counts["submitted"], "completed": counts["completed"], "list": mine}

@app.get("/api/partner/intakes")
def partner_intakes(user = Depends(require("partner:track","read"))):
    with open(os.path.join(MOCK,"intakes.json")) as f:
        all_intakes = json.load(f)
    mine = [i for i in all_intakes if i["ownerUserId"]==user["username"]]
    return mine

@app.post("/api/partner/intakes")
def create_intake(payload: dict, user = Depends(require("partner:raise_intake","write"))):
    with open(os.path.join(MOCK,"intakes.json")) as f:
        all_intakes = json.load(f)
    new_key = f"INT-{len(all_intakes)+1:04d}"
    payload.setdefault("key", new_key)
    payload.setdefault("ownerUserId", user["username"])
    payload.setdefault("status","draft")
    all_intakes.append(payload)
    with open(os.path.join(MOCK,"intakes.json"), "w") as f:
        json.dump(all_intakes, f, indent=2)
    return payload

@app.get("/api/partner/action-items")
def partner_actions(user = Depends(require("partner:my_actions","read"))):
    with open(os.path.join(MOCK,"action_items.json")) as f:
        items = json.load(f)
    mine = [a for a in items if a["assignee"]==user["username"]]
    return mine

# ---- OTM ----
@app.get("/api/otm/dashboard")
def otm_dashboard(user = Depends(require("otm:dashboard","read"))):
    with open(os.path.join(MOCK,"action_items.json")) as f:
        items = json.load(f)
    tasks = [a for a in items if a["assignee"]==user["username"]]
    data = {"totals":{"featuresAllocated":5,"tasks":len(tasks)},
            "pendingPartnerResponses":[a for a in items if a.get("waitingOn")=="partner"],
            "myPending":[a for a in tasks if a["status"] in ("todo","in-progress")],
            "teamPending":[a for a in items if a["status"] in ("todo","in-progress")]}
    return data

@app.get("/api/otm/sprint")
def otm_sprint(user = Depends(require("otm:sprint","read"))):
    with open(os.path.join(MOCK,"features.json")) as f:
        feats = json.load(f)
    return feats

@app.get("/api/otm/my-action-items")
def otm_my_actions(user = Depends(require("otm:my_actions","read"))):
    with open(os.path.join(MOCK,"action_items.json")) as f:
        items = json.load(f)
    mine = [a for a in items if a["assignee"]==user["username"]]
    return mine

@app.get("/api/otm/team-action-items")
def otm_team_actions(user = Depends(require("otm:team_actions","read"))):
    with open(os.path.join(MOCK,"action_items.json")) as f:
        items = json.load(f)
    return items

# ---- Leadership ----
@app.get("/api/lead/dashboard")
def lead_dashboard(user = Depends(require("lead:dashboard","read"))):
    with open(os.path.join(MOCK,"charts.json")) as f:
        charts = json.load(f)
    return {"charts": charts}

@app.get("/api/lead/my-action-items")
def lead_my_actions(user = Depends(require("lead:my_actions","read"))):
    with open(os.path.join(MOCK,"action_items.json")) as f:
        items = json.load(f)
    mine = [a for a in items if a["assignee"]==user["username"]]
    return mine

# ---- PO/SM ----
@app.get("/api/po/dashboard")
def po_dashboard(user = Depends(require("po:dashboard","read"))):
    with open(os.path.join(MOCK,"charts.json")) as f:
        charts = json.load(f)
    return {"charts": charts}

@app.get("/api/po/sprint")
def po_sprint(user = Depends(require("po:sprint","read"))):
    with open(os.path.join(MOCK,"features.json")) as f:
        feats = json.load(f)
    return feats

@app.get("/api/po/my-action-items")
def po_my_actions(user = Depends(require("po:my_actions","read"))):
    with open(os.path.join(MOCK,"action_items.json")) as f:
        items = json.load(f)
    mine = [a for a in items if a["assignee"]==user["username"]]
    return mine

@app.get("/api/po/team-action-items")
def po_team_actions(user = Depends(require("po:team_actions","read"))):
    with open(os.path.join(MOCK,"action_items.json")) as f:
        items = json.load(f)
    return items

# ---- Chat ----
THREADS = os.path.join(MOCK, "chat_threads.json")
def load_threads():
    with open(THREADS, "r") as f: return json.load(f)
def save_threads(data):
    with open(THREADS, "w") as f: json.dump(data, f, indent=2)

@app.post("/api/chat/send")
def chat_send(payload: dict, request: Request):
    user = current_user(request)
    if not user: raise HTTPException(401, "Not authenticated")
    threads = load_threads()
    tid = payload.get("threadId") or user["username"]
    thread = threads.get(tid, {"messages":[]})
    message = payload.get("message","")
    thread["messages"].append({"from": user["username"], "text": message})
    reply = "Acknowledged."
    if "create intake" in message.lower():
        reply = "Provide: summary, lob, targetVersion."
    thread["messages"].append({"from":"assistant","text":reply})
    threads[tid] = thread
    save_threads(threads)
    return {"threadId": tid, "messages": thread["messages"]}

@app.get("/api/chat/history")
def chat_history(threadId: str, request: Request):
    user = current_user(request)
    if not user: raise HTTPException(401, "Not authenticated")
    threads = load_threads()
    return threads.get(threadId, {"messages":[]})

@app.post("/api/chat/upload")
def chat_upload(request: Request, file: UploadFile = File(...)):
    user = current_user(request)
    if not user: raise HTTPException(401, "Not authenticated")
    os.makedirs(UPLOADS, exist_ok=True)
    path = os.path.join(UPLOADS, file.filename)
    with open(path, "wb") as f:
        f.write(file.file.read())
    return {"fileId": file.filename, "name": file.filename, "size": os.path.getsize(path)}
