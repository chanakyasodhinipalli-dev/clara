# Onboard360 AI — Jira Scope Dashboard (Agentic v3 with Email Alerts)

**What’s new in v3:**
- **EmailAgent** with SMTP settings (TLS) for deadline reminders & follow-ups.
- UI block to filter scopes due soon/overdue and send batched emails.
- Everything still in a **single Streamlit page** with Agentic toolkit (Fetch/Parse/Scope/Graph/Sync/Email).

## Run
1. `python -m venv .venv && source .venv/bin/activate`
2. `pip install -r requirements.txt`
3. `streamlit run app.py` and fill Jira + SMTP in the sidebar.

### SMTP Notes
- Works with standard SMTP (e.g., Office365: `smtp.office365.com:587` with TLS). 
- Use an app password if your provider requires it.
- The email body supports `{TABLE}` placeholder to inject a compact table of due items.
