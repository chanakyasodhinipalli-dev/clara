
import os
import re
import json
import time
import smtplib
from email.message import EmailMessage
import pandas as pd
import plotly.express as px
import networkx as nx
from pyvis.network import Network
import httpx
import streamlit as st
from pydantic import BaseModel, Field
from datetime import date, timedelta
from typing import List

# ====================== Agentic A Toolkit (lightweight) ======================
class AgentContext(BaseModel):
    jira_base: str
    jira_email: str
    jira_token: str
    project_key: str

class BaseAgent:
    def __init__(self, ctx: AgentContext):
        self.ctx = ctx

class FetchAgent(BaseAgent):
    def client(self):
        return httpx.Client(base_url=self.ctx.jira_base, auth=(self.ctx.jira_email, self.ctx.jira_token), timeout=30.0)
    def get_issue(self, key: str):
        with self.client() as c:
            r = c.get(f"/rest/api/3/issue/{key}", params={"expand":"renderedFields"})
            r.raise_for_status()
            return r.json()

class ParseAgent(BaseAgent):
    AC_HEADERS = [r"^Acceptance Criteria", r"^AC:?", r"^Acceptance:" ]
    BULLET = re.compile(r"^(?:[-*]|\d+\.)\s+", re.I)
    def extract_acceptance_criteria(self, desc_text: str)->List[str]:
        if not desc_text: return []
        lines = [l.strip() for l in desc_text.splitlines()]
        ac_block, in_ac = [], False
        for ln in lines:
            if any(re.match(h, ln, flags=re.I) for h in self.AC_HEADERS):
                in_ac = True; continue
            if in_ac:
                if ln=="" or re.match(r"^[A-Za-z].*:\s*$", ln):
                    if ac_block: break
                    else: continue
                ac_block.append(ln)
        items = []
        for ln in ac_block:
            if self.BULLET.match(ln): items.append(self.BULLET.sub("", ln))
            elif ln: items.append(ln)
        if len(items)==1 and ";" in items[0]:
            items = [x.strip() for x in items[0].split(";") if x.strip()]
        return [i for i in items if i]
    def detect_dependencies(self, text: str)->List[str]:
        if not text: return []
        keys = re.findall(r"\b[A-Z]{2,10}-\d+\b", text)
        words = ["blocked by", "depends on", "dependency", "waiting for"]
        if any(w in text.lower() for w in words): 
            return list(set(keys))
        return list(set(keys))

class ScopeAgent(BaseAgent):
    WORKFLOW = ["Not Started","In Progress","Waiting","Blocked","Ready","Done"]
    def risk_score(self, due: date, status: str)->int:
        score = 0
        if due:
            days = (due - date.today()).days
            if days < 0: score += min(20, abs(days))  # overdue penalty
            elif days <= 2: score += 5
        if status in ["Blocked","Waiting"]: score += 10
        return score

class GraphAgent(BaseAgent):
    def build_graph(self, nodes, edges):
        g = networkx.DiGraph()
        for k, data in nodes.items():
            g.add_node(k, **data)
        for u, v in edges:
            g.add_edge(u, v)
        return g
    def render(self, g):
        net = Network(height="620px", width="100%", bgcolor="#ffffff", font_color="black", directed=True)
        for n, data in g.nodes(data=True):
            lbl = data.get("label", n)
            color = data.get("color", "#a3d5ff")
            net.add_node(n, label=lbl, color=color, title=lbl)
        for u, v in g.edges():
            net.add_edge(u, v)
        html_path = "graph.html"
        net.show(html_path)
        return html_path

class SyncAgent(BaseAgent):
    def add_comment(self, issue_key: str, text: str):
        with httpx.Client(base_url=self.ctx.jira_base, auth=(self.ctx.jira_email, self.ctx.jira_token)) as c:
            body = {"body": text}
            r = c.post(f"/rest/api/3/issue/{issue_key}/comment", json=body)
            if r.status_code not in (200,201): 
                return False, r.text
            return True, None

# ====================== Email Agent ======================
class EmailAgent:
    def __init__(self, host:str, port:int, username:str, password:str, use_tls:bool=True, from_addr:str="no-reply@onboard360.ai"):
        self.host=host; self.port=port; self.username=username; self.password=password; self.use_tls=use_tls; self.from_addr=from_addr
    def send(self, to_addrs:List[str], subject:str, body:str):
        if not to_addrs: 
            return False, "No recipients"
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = self.from_addr
        msg["To"] = ", ".join(to_addrs)
        msg.set_content(body)
        try:
            with smtplib.SMTP(self.host, self.port, timeout=20) as server:
                if self.use_tls: server.starttls()
                if self.username and self.password:
                    server.login(self.username, self.password)
                server.send_message(msg)
            return True, None
        except Exception as e:
            return False, str(e)

# ====================== Helpers & Data ======================
def within_project(key:str, project_key:str):
    try: return key.upper().startswith(project_key.upper()+"-")
    except: return False

@st.cache_data(show_spinner=False)
def fetch_tree(ctx: AgentContext, root_key: str, max_depth: int=3):
    fetch = FetchAgent(ctx); parse = ParseAgent(ctx)
    nodes = {}
    edges = []
    seen = set()
    def add_issue(key, depth=0, via=None):
        if key in seen or depth>max_depth: return
        seen.add(key)
        try:
            data = fetch.get_issue(key)
        except Exception as e:
            st.error(f"Failed to fetch {key}: {e}")
            return
        fields = data.get("fields", {})
        summary = fields.get("summary","(no summary)")
        status  = (fields.get("status") or {}).get("name","Unknown")
        issue_type = (fields.get("issuetype") or {}).get("name","Issue")
        desc = fields.get("description") or (data.get("renderedFields") or {}).get("description","")
        desc_text = desc if isinstance(desc,str) else ""
        # store
        nodes[key] = {
            "label": f"{key}: {summary}", "status": status, "type": issue_type,
            "color": "#ffd1a3" if issue_type=="Epic" else "#d1ffa3" if issue_type=="Story" else "#a3d5ff",
            "description": desc_text
        }
        if via: edges.append((via, key))
        # subtasks
        for stask in fields.get("subtasks",[]) or []:
            skey = stask.get("key")
            if skey and within_project(skey, ctx.project_key):
                add_issue(skey, depth+1, via=key)
        # parent
        parent = (fields.get("parent") or {}).get("key")
        if parent and within_project(parent, ctx.project_key):
            if parent not in nodes: add_issue(parent, depth+1)
            edges.append((parent, key))
        # links
        for link in fields.get("issuelinks",[]) or []:
            inward = (link.get("inwardIssue") or {}).get("key")
            outward = (link.get("outwardIssue") or {}).get("key")
            for lk in [inward, outward]:
                if lk and within_project(lk, ctx.project_key):
                    edges.append((key, lk))
                    add_issue(lk, depth+1, via=key)
    add_issue(root_key, 0, None)
    return nodes, edges

# ====================== UI ======================
st.set_page_config(page_title="Onboard360 · Jira Scope Dashboard", layout="wide")
st.title("Onboard360 AI · Jira Scope Dashboard (Agentic MVP v3 with Email Alerts)")

with st.sidebar:
    st.subheader("Jira Connection")
    jira_base = st.text_input("Jira Base URL", value=os.getenv("JIRA_BASE_URL","https://your-domain.atlassian.net"))
    jira_email = st.text_input("Jira User Email", value=os.getenv("JIRA_EMAIL",""))
    jira_token = st.text_input("Jira API Token", value=os.getenv("JIRA_API_TOKEN",""), type="password")
    project_key = st.text_input("Project Key Restriction", value=os.getenv("JIRA_PROJECT_KEY","SSAT"))
    root_issue = st.text_input("Root Issue Key", placeholder=f"{project_key}-1234")
    depth = st.slider("Traversal Depth", 1, 6, 3)

    st.subheader("Email Settings")
    smtp_host = st.text_input("SMTP Host", value=os.getenv("SMTP_HOST","smtp.office365.com"))
    smtp_port = st.number_input("SMTP Port", value=int(os.getenv("SMTP_PORT","587")))
    smtp_user = st.text_input("SMTP Username / From", value=os.getenv("SMTP_USER",""))
    smtp_pass = st.text_input("SMTP Password", value=os.getenv("SMTP_PASS",""), type="password")
    smtp_tls  = st.checkbox("Use TLS", value=True)
    from_addr = st.text_input("From Address", value=os.getenv("FROM_ADDR", smtp_user or "no-reply@onboard360.ai"))
    reminder_days = st.slider("Remind when due within (days)", 1, 14, 3)

    if st.button("Fetch & Build Graph"):
        st.session_state["_ctx"] = AgentContext(
            jira_base=jira_base, jira_email=jira_email, jira_token=jira_token, project_key=project_key
        )
        st.session_state["_root"] = root_issue
        st.session_state["_nodes"], st.session_state["_edges"] = fetch_tree(st.session_state["_ctx"], root_issue, depth)
        st.session_state["_last_pull"] = time.time()

if "_nodes" not in st.session_state:
    st.info("Configure Jira connection and click **Fetch & Build Graph** to begin.")
    st.stop()

ctx = st.session_state["_ctx"]
nodes = st.session_state["_nodes"]
edges = st.session_state["_edges"]

# ====== Portfolio cards ======
col1,col2,col3,col4 = st.columns(4)
col1.metric("Nodes", len(nodes))
col2.metric("Edges", len(edges))
epics = sum(1 for n in nodes.values() if n.get("type")=="Epic")
col3.metric("Epics", epics)
col4.metric("Last Sync (s ago)", int(time.time()-st.session_state.get("_last_pull",0)))

st.divider()

# ====== Graph ======
st.subheader("Parent/Child/Linked Graph")
net = Network(height="640px", width="100%", bgcolor="#ffffff", font_color="black", directed=True)
for k, data in nodes.items():
    net.add_node(k, label=data["label"], color=data["color"], title=data["label"])
for u, v in edges:
    net.add_edge(u, v)
_html = "graph.html"
net.show(_html)
with open(_html, "r", encoding="utf-8") as f:
    st.components.v1.html(f.read(), height=660, scrolling=True)

st.divider()

# ====== Scopes from AC (seed/manage) ======
st.subheader("Scopes (Acceptance Criteria → Work Items)")

parse = ParseAgent(ctx)
fetch = FetchAgent(ctx)
scope_agent = ScopeAgent(ctx)

if "_scopes" not in st.session_state:
    st.session_state["_scopes"] = {}

def seed_scopes_for_issue(key):
    try:
        data = fetch.get_issue(key)
    except Exception as e:
        st.error(f"Failed to fetch {key}: {e}")
        return []
    fields = data.get("fields", {})
    desc = fields.get("description") or (data.get("renderedFields") or {}).get("description","")
    desc_text = desc if isinstance(desc,str) else ""
    ac_items = parse.extract_acceptance_criteria(desc_text)
    deps = parse.detect_dependencies(desc_text)
    scopes = []
    for i, it in enumerate(ac_items, start=1):
        scopes.append({
            "issue": key,
            "scope_id": f"{key}-S{i}",
            "text": it,
            "status": "Not Started",
            "owner": "",
            "due_date": str(date.today()+timedelta(days=7)),
            "dependencies": [d for d in deps if d!=key]
        })
    return scopes

c1,c2 = st.columns([1,3])
if c1.button("Refresh Scopes from Issues"):
    count=0
    for key in nodes.keys():
        for sc in seed_scopes_for_issue(key):
            st.session_state["_scopes"][sc["scope_id"]] = sc; count+=1
    st.success(f"Seeded/updated {count} scopes.")

scopes_df = pd.DataFrame(list(st.session_state["_scopes"].values())) if st.session_state["_scopes"] else pd.DataFrame(columns=["issue","scope_id","text","status","owner","due_date","dependencies"])
c2.dataframe(scopes_df, use_container_width=True)

# ====== Timeline ======
st.subheader("Gantt Timeline")
if not scopes_df.empty:
    df = scopes_df.copy()
    df["Start"] = pd.to_datetime(date.today())
    df["Finish"] = pd.to_datetime(df["due_date"], errors="coerce")
    fig = px.timeline(df, x_start="Start", x_end="Finish", y="scope_id", color="status", hover_data=["text","issue","owner"])
    fig.update_yaxes(autorange="reversed")
    st.plotly_chart(fig, use_container_width=True)
else:
    st.info("No scopes yet.")

# ====== Risks & Dependencies ======
st.subheader("Risks & Dependencies")
if not scopes_df.empty:
    scopes_df["risk"] = scopes_df.apply(lambda r: ScopeAgent(ctx).risk_score(pd.to_datetime(r["due_date"], errors="coerce").date() if r["due_date"] else None, r["status"]), axis=1)
    risky = scopes_df[scopes_df["risk"]>=10].sort_values("risk", ascending=False)
    st.write("**At-Risk Scopes (≥10):**")
    st.dataframe(risky[["scope_id","issue","status","owner","due_date","risk","dependencies","text"]], use_container_width=True)

# ====== Inline update & Email alerts ======
st.subheader("Update Scope & Send Alerts")

with st.form("update_scope"):
    sid = st.selectbox("Scope ID", options=list(scopes_df["scope_id"]) if not scopes_df.empty else [])
    new_status = st.selectbox("Status", options=["Not Started","In Progress","Waiting","Blocked","Ready","Done"])
    new_owner = st.text_input("Owner email(s) (comma-separated)")
    new_due = st.date_input("Due Date", value=date.today()+timedelta(days=7))
    post_comment = st.checkbox("Post update as Jira comment on root issue")
    submit = st.form_submit_button("Save Update")
    if submit and sid:
        st.session_state["_scopes"][sid]["status"] = new_status
        st.session_state["_scopes"][sid]["owner"] = new_owner
        st.session_state["_scopes"][sid]["due_date"] = str(new_due)
        st.success(f"Updated {sid}.")
        if post_comment and "_root" in st.session_state:
            ok, err = SyncAgent(ctx).add_comment(st.session_state["_root"], f"[Onboard360] {sid} → {new_status} | owner={new_owner} | due={new_due}")
            if ok: st.info("Comment posted to Jira."); 
            else: st.warning(f"Failed to post comment: {err}")

st.markdown("### Email Reminders")
if scopes_df.empty:
    st.info("No scopes to remind.")
else:
    # compute targets
    reminder_targets = []
    for sc in st.session_state["_scopes"].values():
        due = pd.to_datetime(sc["due_date"], errors="coerce")
        if pd.isna(due): continue
        days_left = (due.date() - date.today()).days
        if days_left <= int(os.getenv("REMINDER_DAYS", "3")):
            reminder_targets.append((sc, days_left))

    st.caption("We include items due soon or overdue. You can also filter below.")
    filt_status = st.multiselect("Statuses to include", ["Not Started","In Progress","Waiting","Blocked","Ready"], default=["Not Started","In Progress","Waiting","Blocked"])
    max_days = st.slider("Include if due within days", 0, 14, 3)
    rows = []
    for sc, dl in reminder_targets:
        if sc["status"] not in filt_status: continue
        if dl > max_days: continue
        rows.append({
            "scope_id": sc["scope_id"],
            "owner": sc["owner"],
            "due_date": sc["due_date"],
            "status": sc["status"],
            "issue": sc["issue"],
            "days_left": dl,
            "text": sc["text"]
        })
    reminders_df = pd.DataFrame(rows)
    st.dataframe(reminders_df, use_container_width=True)

    # Email sending controls
    to_override = st.text_input("Additional recipients (comma-separated)")
    subj = st.text_input("Email subject", value="[Onboard360] Upcoming deadlines & blockers")
    body_template = st.text_area("Email body (template)", value=(
        "Hello,\n\nThe following scope items are due soon or overdue:\n\n"
        "{TABLE}\n\n"
        "Please update status/owner or reply with any blockers.\n\n"
        "— Onboard360 AI Dashboard"
    ), height=160)

    if st.button("Send Reminders Now"):
        if not smtp_host or not smtp_user:
            st.error("SMTP settings missing. Configure in the sidebar.")
        else:
            ea = EmailAgent(smtp_host, int(smtp_port), smtp_user, smtp_pass, smtp_tls, from_addr)
            if reminders_df.empty:
                st.info("No items matched reminder filter.")
            else:
                # build a text table
                lines = ["scope_id | issue | status | due | owner | days_left", "-"*70]
                for _, r in reminders_df.iterrows():
                    lines.append(f"{r['scope_id']} | {r['issue']} | {r['status']} | {r['due_date']} | {r['owner']} | {r['days_left']}")
                table_txt = "\n".join(lines)
                # recipients
                to_set = set()
                for owner in reminders_df["owner"]:
                    if isinstance(owner,str) and owner.strip():
                        for addr in owner.split(","):
                            if "@" in addr: to_set.add(addr.strip())
                if to_override:
                    for addr in to_override.split(","):
                        if "@" in addr: to_set.add(addr.strip())
                success, err = ea.send(sorted(list(to_set)), subj, body_template.replace("{TABLE}", table_txt))
                if success:
                    st.success(f"Sent reminders to: {', '.join(sorted(list(to_set)))}")
                else:
                    st.warning(f"Failed to send email: {err}")

st.caption("Agents: FetchAgent (Jira), ParseAgent (AC/deps), ScopeAgent (risk), GraphAgent (viz), SyncAgent (write-back), EmailAgent (alerts). Single-page UX.")
