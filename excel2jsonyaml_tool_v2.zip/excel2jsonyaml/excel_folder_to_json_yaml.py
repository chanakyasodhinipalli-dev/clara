#!/usr/bin/env python3
"""
excel_folder_to_json_yaml.py
--------------------------------
Scan an input folder for Excel workbooks and export their sheet data to JSON and YAML.
- Supports .xlsx (openpyxl engine). .xls can be handled via pandas+xlrd if installed.
- Infers header row or accepts a fixed header row index.
- Normalizes values (dates to ISO 8601, numbers, booleans, empty cells -> None).
- Produces a per-workbook folder containing per-sheet JSON and YAML files.
- Also writes a master index.json & index.yaml with metadata.

Usage:
  python excel_folder_to_json_yaml.py --input ./sheets --output ./out
  python excel_folder_to_json_yaml.py --input ./sheets --output ./out --header-mode auto
  python excel_folder_to_json_yaml.py --input ./sheets --output ./out --header-mode row --header-row 1
  python excel_folder_to_json_yaml.py --input ./sheets --output ./out --include "*.xlsx" --exclude "~$*"

Requirements:
  - openpyxl
  - PyYAML
  - (optional) pandas + xlrd for legacy .xls
"""
from __future__ import annotations

import argparse
import fnmatch
import json
import os
import re
import sys
from dataclasses import dataclass, asdict
from datetime import datetime, date, time
from typing import Any, Dict, List, Optional, Tuple

# Third-party
try:
    import openpyxl
except Exception as e:
    print("ERROR: openpyxl is required. Please install with: pip install openpyxl", file=sys.stderr)
    raise

try:
    import yaml
except Exception as e:
    print("ERROR: PyYAML is required. Please install with: pip install pyyaml", file=sys.stderr)
    raise


@dataclass
class SheetExport:
    workbook_name: str
    sheet_name: str
    header_row_index: int
    columns: List[str]
    n_rows: int
    n_cols: int
    path_json: str
    path_yaml: str


@dataclass
class WorkbookExport:
    workbook_name: str
    path: str
    sheets: List[SheetExport]


def isoformat_value(value: Any) -> Any:
    """Normalize cell values to JSON/YAML-friendly types."""
    # openpyxl returns Python datetime/date/time for Excel date cells when data_only=True if possible
    if isinstance(value, datetime):
        try:
            # keep timezone-naive ISO 8601
            return value.isoformat(timespec="seconds")
        except Exception:
            return value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, time):
        return value.isoformat(timespec="seconds")
    if isinstance(value, (int, float, bool)) or value is None:
        return value
    # Strip strings, convert empty to None
    if isinstance(value, str):
        v = value.strip()
        return v if v != "" else None
    # Fallback: stringify
    return str(value)


def first_non_empty_row(ws) -> Optional[int]:
    """Find the first row index (1-based) that has at least 2 non-empty cells (heuristic for header)."""
    for row in ws.iter_rows(min_row=1, max_row=50):  # scan first 50 rows
        non_empty = sum(1 for c in row if c.value not in (None, ""))
        if non_empty >= 2:
            return row[0].row
    return None


def extract_table(ws, header_mode: str, header_row: Optional[int]) -> Tuple[List[str], List[List[Any]], int]:
    """
    Return (columns, rows, header_row_index).
    - columns: list of column names (deduped)
    - rows: list of row lists (same length as columns)
    - header_row_index: 1-based row number of header
    """
    if header_mode == "auto":
        hdr = first_non_empty_row(ws)
        if hdr is None:
            raise ValueError(f"Could not determine a header row automatically on sheet '{ws.title}'.")
    else:
        if not header_row or header_row < 1:
            raise ValueError("header_row must be >= 1 when header-mode=row")
        hdr = header_row

    # Read header cells
    header_cells = [c.value for c in ws[hdr]]
    # Normalize names
    columns_raw = [str(h).strip() if h not in (None, "") else f"col_{i+1}" for i, h in enumerate(header_cells)]
    # Deduplicate column names: partner, partner -> partner, partner_2
    seen = {}
    columns = []
    for name in columns_raw:
        base = re.sub(r"\s+", "_", name)  # spaces to underscore
        base = re.sub(r"[^\w\-]+", "_", base).strip("_") or "col"
        if base not in seen:
            seen[base] = 1
            columns.append(base)
        else:
            seen[base] += 1
            columns.append(f"{base}_{seen[base]}")

    # Determine max columns to read based on header length
    max_col = len(columns)

    # Read data rows after header
    data_rows: List[List[Any]] = []
    for row in ws.iter_rows(min_row=hdr + 1, max_row=ws.max_row, max_col=max_col):
        values = [isoformat_value(c.value) for c in row]
        # Skip rows that are completely empty
        if all(v in (None, "") for v in values):
            continue
        data_rows.append(values)

    return columns, data_rows, hdr


def rows_to_records(columns: List[str], data_rows: List[List[Any]]) -> List[Dict[str, Any]]:
    """Map row lists to dicts by column names, trimming/padding as needed."""
    out = []
    n = len(columns)
    for r in data_rows:
        if len(r) < n:
            r = r + [None] * (n - len(r))
        elif len(r) > n:
            r = r[:n]
        out.append({columns[i]: r[i] for i in range(n)})
    return out


def save_json(path: str, data: Any) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def save_yaml(path: str, data: Any) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)


def should_include(fname: str, includes: List[str], excludes: List[str]) -> bool:
    base = os.path.basename(fname)
    if excludes and any(fnmatch.fnmatch(base, pat) for pat in excludes):
        return False
    if includes:
        return any(fnmatch.fnmatch(base, pat) for pat in includes)
    # default: include if Excel-like
    return base.lower().endswith((".xlsx", ".xls")) and not base.startswith("~$")


def export_workbook(path: str, out_root_json: str, out_root_yaml: str, header_mode: str, header_row: Optional[int], emit_json: bool, emit_yaml: bool) -> WorkbookExport:
    wb_name = os.path.splitext(os.path.basename(path))[0]
    try:
        wb = openpyxl.load_workbook(path, data_only=True, read_only=False)
    except Exception as e:
        # Try pandas for legacy .xls if available
        if path.lower().endswith(".xls"):
            try:
                import pandas as pd  # optional
                xls = pd.ExcelFile(path)
                sheets = []
                meta_sheets = []
                for sheet_name in xls.sheet_names:
                    df = pd.read_excel(xls, sheet_name=sheet_name, dtype=object)
                    # Pandas will handle header row at 0 by default; we assume first row is header
                    df.columns = [str(c).strip() if c is not None else f"col_{i+1}" for i, c in enumerate(df.columns)]
                    records = df.where(pd.notna(df), None).to_dict(orient="records")
                    # Save
                    json_path = os.path.join(out_root_json, wb_name, f"{sheet_name}.json")
                    yaml_path = os.path.join(out_root_yaml, wb_name, f"{sheet_name}.yaml")
                    if emit_json:
                        save_json(json_path, records)
                    if emit_yaml:
                        save_yaml(yaml_path, records)
                    sheets.append(SheetExport(
                        workbook_name=wb_name,
                        sheet_name=sheet_name,
                        header_row_index=1,
                        columns=list(df.columns),
                        n_rows=len(records),
                        n_cols=len(df.columns),
                        path_json=json_path,
                        path_yaml=yaml_path
                    ))
                idx = WorkbookExport(workbook_name=wb_name, path=path, sheets=sheets)
                return idx
            except Exception as e2:
                raise RuntimeError(f"Failed to open workbook '{path}': {e2}") from e2
        else:
            raise RuntimeError(f"Failed to open workbook '{path}': {e}") from e

    sheets_meta: List[SheetExport] = []

    for ws in wb.worksheets:
        sheet_name = ws.title
        try:
            columns, data_rows, hdr = extract_table(ws, header_mode, header_row)
            records = rows_to_records(columns, data_rows)
        except Exception as e:
            # If a sheet is empty or header not found, export empty with metadata
            columns, records, hdr = [], [], header_row or 1

        # Save outputs
        json_path = os.path.join(out_root_json, wb_name, f"{sheet_name}.json")
        yaml_path = os.path.join(out_root_yaml, wb_name, f"{sheet_name}.yaml")

        if emit_json:
            save_json(json_path, records)
        if emit_yaml:
            save_yaml(yaml_path, records)

        sheets_meta.append(SheetExport(
            workbook_name=wb_name,
            sheet_name=sheet_name,
            header_row_index=hdr,
            columns=columns,
            n_rows=len(records),
            n_cols=len(columns),
            path_json=json_path,
            path_yaml=yaml_path
        ))

    # Write a per-workbook index file as well
    wb_index_json = os.path.join(out_root_json, wb_name, "_index.json")
    wb_index_yaml = os.path.join(out_root_yaml, wb_name, "_index.yaml")
    wb_index = {
        "workbook": wb_name,
        "source_path": path,
        "sheets": [asdict(s) for s in sheets_meta]
    }
    if emit_json:
        save_json(wb_index_json, wb_index)
    if emit_yaml:
        save_yaml(wb_index_yaml, wb_index)

    return WorkbookExport(workbook_name=wb_name, path=path, sheets=sheets_meta)


def main():
    parser = argparse.ArgumentParser(description="Export Excel folder → JSON & YAML.")
    parser.add_argument("--input", "-i", required=True, help="Input folder containing Excel files")
    parser.add_argument("--output", "-o", required=True, help="Output folder (will create /json and /yaml subfolders)")
    parser.add_argument("--include", action="append", default=[], help="Glob pattern(s) to include (e.g., *.xlsx). Can repeat.")
    parser.add_argument("--exclude", action="append", default=[], help="Glob pattern(s) to exclude (e.g., ~*$). Can repeat.")
    parser.add_argument("--header-mode", choices=["auto", "row"], default="auto", help="Infer header row automatically or use a fixed row index")
    parser.add_argument("--header-row", type=int, help="1-based header row index (required if --header-mode=row)")
    parser.add_argument("--index-filename", default="index", help="Base name for master index files (without extension)")
    parser.add_argument("--formats", default="json,yaml", help="Comma-separated formats to emit: json,yaml (default: both)")
    args = parser.parse_args()

    in_root = os.path.abspath(args.input)
    out_root = os.path.abspath(args.output)
    formats = [f.strip().lower() for f in args.formats.split(",") if f.strip()]
    emit_json = "json" in formats
    emit_yaml = "yaml" in formats
    out_json = os.path.join(out_root, "json")
    out_yaml = os.path.join(out_root, "yaml")
    if emit_json:
        os.makedirs(out_json, exist_ok=True)
    if emit_yaml:
        os.makedirs(out_yaml, exist_ok=True)

    excel_files: List[str] = []
    for root, _, files in os.walk(in_root):
        for f in files:
            full = os.path.join(root, f)
            if should_include(full, args.include, args.exclude):
                excel_files.append(full)

    if not excel_files:
        print("No Excel files matched. Check your --include/--exclude patterns.", file=sys.stderr)
        sys.exit(2)

    master: Dict[str, Any] = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "input_root": in_root,
        "output_root": out_root,
        "workbooks": []
    }

    exports: List[WorkbookExport] = []
    for fpath in sorted(excel_files):
        try:
            wb_export = export_workbook(
                path=fpath,
                out_root_json=out_json,
                out_root_yaml=out_yaml,
                header_mode=args.header_mode,
                header_row=args.header_row,
                emit_json=emit_json,
                emit_yaml=emit_yaml
            )
            exports.append(wb_export)
            master["workbooks"].append({
                "workbook_name": wb_export.workbook_name,
                "source_path": wb_export.path,
                "sheets": [asdict(s) for s in wb_export.sheets]
            })
            print(f"✓ {fpath} -> {len(wb_export.sheets)} sheet(s)")
        except Exception as e:
            print(f"✗ {fpath} failed: {e}", file=sys.stderr)

    # Master index
    master_index_json = os.path.join(out_root, f"{args.index_filename}.json")
    master_index_yaml = os.path.join(out_root, f"{args.index_filename}.yaml")
    if emit_json:
        save_json(master_index_json, master)
    if emit_yaml:
        save_yaml(master_index_yaml, master)

    print("\nDone.")
    if emit_json:
        print(f"JSON master index: {master_index_json}")
        print(f"JSON outputs under: {out_json}")
    if emit_yaml:
        print(f"YAML master index: {master_index_yaml}")
        print(f"YAML outputs under: {out_yaml}")


if __name__ == "__main__":
    main()
