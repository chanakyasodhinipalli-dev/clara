from __future__ import annotations
from typing import Dict, Any, List, DefaultDict
from collections import defaultdict
from .base import BaseAgent

class GroupingAgent(BaseAgent):
    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        groups: DefaultDict[int, List[str]] = defaultdict(list)
        for r in context.get("context_results", []):
            groups[int(r.get("group", 99))].append(r["path"])
        context["groups"] = [{"group_id": k, "paths": v} for k, v in groups.items()]
        if self.cfg.ai_enabled:
            self.prompt.run_prompt("grouping", {"groups": context["groups"]})
        return context
