from __future__ import annotations
from typing import Dict, Any
from .base import BaseAgent

class SummarizationAgent(BaseAgent):
    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        context["summary"] = {
            "english": "Summary not available because rule-based summarizer is minimal.",
            "native": "Summary (native) not available in rule mode.",
        }
        if self.cfg.ai_enabled:
            self.prompt.run_prompt("summarization", {"chunks": []})
        return context
