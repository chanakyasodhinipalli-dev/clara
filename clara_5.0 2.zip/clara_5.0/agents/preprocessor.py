from __future__ import annotations
from typing import Dict, Any, List
from pathlib import Path
from langdetect import detect, DetectorFactory
import chardet
from core.utils import detect_mime
from .base import BaseAgent

DetectorFactory.seed = 42

def detect_language_of_text(text: str) -> str:
    try:
        return detect(text)
    except Exception:
        return "unknown"

class PreprocessorAgent(BaseAgent):
    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        items: List[Path] = context.get("items", [])
        results = []
        for p in items:
            mime = detect_mime(p)
            lang = "unknown"
            if p.suffix.lower() == ".txt" and p.exists():
                data = p.read_bytes()
                enc = chardet.detect(data).get("encoding") or "utf-8"
                try:
                    lang = detect_language_of_text(data.decode(enc, errors="ignore"))
                except Exception:
                    lang = "unknown"
            results.append({"path": str(p), "mime": mime, "language": lang, "multi_context": False})
        context["preprocess"] = results
        if self.cfg.ai_enabled:
            self.prompt.run_prompt("preprocess_language_detection", {"items": [r["path"] for r in results]})
        return context
