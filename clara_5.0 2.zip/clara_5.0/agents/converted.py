from __future__ import annotations
from typing import Dict, Any, List
from pathlib import Path
from PIL import Image
from core.utils import is_pdf, is_image, is_office, safe_filename
from PyPDF2 import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from .base import BaseAgent

class ConvertedAgent(BaseAgent):
    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        outdir = self.cfg.outputs_dir
        outdir.mkdir(parents=True, exist_ok=True)
        outputs: List[Dict[str, Any]] = []
        for p in context.get("items", []):
            target = outdir / f"{safe_filename(p.stem)}.pdf"
            if is_pdf(p) and p.exists():
                reader = PdfReader(str(p))
                writer = PdfWriter()
                for page in reader.pages:
                    writer.add_page(page)
                with target.open("wb") as f:
                    writer.write(f)
            elif is_image(p) and p.exists():
                Image.open(p).convert("RGB").save(target, "PDF")
            elif is_office(p) and p.exists():
                c = canvas.Canvas(str(target), pagesize=A4)
                c.setFont("Helvetica", 12)
                c.drawString(50, 800, f"Converted placeholder for {p.name}")
                c.drawString(50, 780, "Install LibreOffice for rich conversion; this is a text-only export.")
                c.showPage(); c.save()
            else:
                continue
            outputs.append({"filename": target.name, "path": str(target), "download": f"/download/{target.name}"})
        context["converted"] = outputs
        return context
