from __future__ import annotations
from typing import Dict, Any, List
import re
from .base import BaseAgent

AADHAAR_RE = re.compile(r"\b(\d{4}\s\d{4}\s\d{4})\b")
PAN_RE = re.compile(r"\b([A-Z]{5}\d{4}[A-Z])\b")
ACC_RE = re.compile(r"\b\d{9,18}\b")

class MetadataAgent(BaseAgent):
    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        results: List[Dict[str, Any]] = []
        for p in context.get("items", []):
            text = p.stem.replace("_", " ")
            aad = AADHAAR_RE.search(text)
            pan = PAN_RE.search(text)
            acc = ACC_RE.search(text)
            results.append({
                "path": str(p),
                "name": None,
                "customer_id": None,
                "aadhaar": aad.group(1) if aad else None,
                "pan": pan.group(1) if pan else None,
                "account_number": acc.group(0) if acc else None,
                "address": None,
                "note": "Filename-derived metadata due to demo constraints.",
            })
        context["metadata"] = results
        if self.cfg.ai_enabled:
            self.prompt.run_prompt("metadata_extraction", {"results": results})
        return context
