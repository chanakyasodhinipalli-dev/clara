from __future__ import annotations
from typing import Dict, Any
from pathlib import Path
from core.logger import get_logger
from core.config import AppConfig
from core.prompt_manager import PromptManager

class BaseAgent:
    def __init__(self, cfg: AppConfig, prompt: PromptManager) -> None:
        self.cfg = cfg
        self.prompt = prompt
        self.logger = get_logger(self.__class__.__name__)

    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError

    def process(self, item: Path) -> Dict[str, Any]:
        return {"item": str(item), "ok": True}
