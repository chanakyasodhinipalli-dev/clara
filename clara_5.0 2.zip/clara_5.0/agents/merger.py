from __future__ import annotations
from typing import Dict, Any
from pathlib import Path
from PyPDF2 import PdfReader, PdfWriter
from PIL import Image
from core.utils import is_pdf, is_image, safe_filename
from .base import BaseAgent

class MergerAgent(BaseAgent):
    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        items = context.get("items", [])
        outdir = self.cfg.outputs_dir
        outdir.mkdir(parents=True, exist_ok=True)
        base = items[0].stem if items else "documents"
        out = outdir / f"merged_{safe_filename(base)}.pdf"
        writer = PdfWriter()
        for p in items:
            if is_pdf(p) and p.exists():
                reader = PdfReader(str(p))
                for page in reader.pages:
                    writer.add_page(page)
            elif is_image(p) and p.exists():
                im = Image.open(p).convert("RGB")
                temp_pdf = outdir / f"{safe_filename(p.stem)}.pdf"
                im.save(temp_pdf, "PDF")
                reader = PdfReader(str(temp_pdf))
                for page in reader.pages:
                    writer.add_page(page)
        with out.open("wb") as f:
            writer.write(f)
        context["merged"] = {"filename": out.name, "path": str(out), "download": f"/download/{out.name}"}
        return context
