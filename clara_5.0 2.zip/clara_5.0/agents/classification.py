from __future__ import annotations
from typing import Dict, Any
from pathlib import Path
import csv, re
from .base import BaseAgent

class ClassificationAgent(BaseAgent):
    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        config_csv = Path("config/classification_rules.csv")
        rules = []
        if config_csv.exists():
            with config_csv.open(newline="", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    rules.append(row)
        results = []
        for p in context.get("items", []):
            name = p.name.lower()
            matched = None
            for r in rules:
                rule = r.get("rule", ".")
                try:
                    if re.search(rule, name):
                        matched = r
                        break
                except re.error:
                    continue
            if matched:
                results.append({
                    "path": str(p),
                    "doctype_code": matched.get("doctype_code"),
                    "doctype_name": matched.get("doctype_name"),
                    "description": matched.get("description"),
                })
            else:
                results.append({"path": str(p), "doctype_code": "UNK", "doctype_name": "Unknown", "description": ""})
        context["classification"] = results
        if self.cfg.ai_enabled:
            self.prompt.run_prompt("classification", {"results": results})
        return context
