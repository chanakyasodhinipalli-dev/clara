from __future__ import annotations
from typing import Dict, Any, List
from pathlib import Path
from PyPDF2 import PdfReader, PdfWriter
from PIL import Image
from core.utils import is_pdf, is_image, safe_filename
from .base import BaseAgent

class SplitterAgent(BaseAgent):
    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        outputs: List[Dict[str, Any]] = []
        outdir = self.cfg.outputs_dir
        outdir.mkdir(parents=True, exist_ok=True)

        for p in context.get("items", []):
            if is_pdf(p) and p.exists():
                reader = PdfReader(str(p))
                for i, page in enumerate(reader.pages):
                    writer = PdfWriter()
                    writer.add_page(page)
                    out = outdir / f"{safe_filename(p.stem)}_page_{i+1}.pdf"
                    with out.open("wb") as f:
                        writer.write(f)
                    outputs.append({"filename": out.name, "path": str(out), "download": f"/download/{out.name}"})
            elif is_image(p) and p.exists():
                img = Image.open(p)
                out = outdir / f"{safe_filename(p.stem)}_page_1.png"
                img.save(out)
                outputs.append({"filename": out.name, "path": str(out), "download": f"/download/{out.name}"})
            else:
                self.logger.info("Splitter skipping non-PDF/image", extra={"path": str(p)})
        context["split"] = outputs
        return context
