from __future__ import annotations
from typing import Dict, Any
from pathlib import Path
from .base import BaseAgent
import re

class ContextAgent(BaseAgent):
    def process(self, item: Path) -> Dict[str, Any]:
        name = item.name.lower()
        if re.search(r"aadhaar|aadhar", name):
            group = 1
        elif re.search(r"\bpan\b", name):
            group = 2
        elif re.search(r"bank|statement", name):
            group = 3
        elif re.search(r"address|utility", name):
            group = 4
        else:
            group = 99
        return {"path": str(item), "group": group, "continuation": False}

    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        if "context_results" not in context:
            results = [self.process(p) for p in context.get("items", [])]
            context["context_results"] = results
        if self.cfg.ai_enabled:
            self.prompt.run_prompt("context_grouping", {"results": context["context_results"]})
        return context
