from __future__ import annotations
from typing import Dict, Any, List
from pathlib import Path
from PIL import Image
import pytesseract
from core.utils import is_image, is_pdf, safe_filename
from pdf2image import convert_from_path
from .base import BaseAgent

class OCRAgent(BaseAgent):
    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        texts: List[Dict[str, Any]] = []
        outdir = self.cfg.outputs_dir
        outdir.mkdir(parents=True, exist_ok=True)
        for p in context.get("items", []):
            images = []
            if is_image(p) and p.exists():
                images = [Image.open(p)]
            elif is_pdf(p) and p.exists():
                try:
                    images = convert_from_path(str(p))
                except Exception as e:
                    self.logger.error("PDF to image conversion failed", extra={"error": str(e)})
                    images = []
            for idx, img in enumerate(images, start=1):
                try:
                    text = pytesseract.image_to_string(img, lang=self.cfg.ocr_lang)
                except Exception as e:
                    self.logger.warning("Tesseract failure; returning empty text", extra={"error": str(e)})
                    text = ""
                out_txt = outdir / f"{safe_filename(p.stem)}_page_{idx}.txt"
                out_txt.write_text(text, encoding="utf-8")
                texts.append({"source": str(p), "page": idx, "text_path": str(out_txt), "download": f"/download/{out_txt.name}"})
        context["ocr_texts"] = texts
        return context
