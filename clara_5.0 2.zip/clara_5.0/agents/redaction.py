from __future__ import annotations
from typing import Dict, Any, List
from pathlib import Path
from io import BytesIO
from PyPDF2 import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.lib.colors import black
from reportlab.lib.pagesizes import letter
from .base import BaseAgent

class RedactionAgent(BaseAgent):
    def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        items = context.get("items", [])
        outdir = self.cfg.outputs_dir
        outdir.mkdir(parents=True, exist_ok=True)
        redacted_list: List[Dict[str, Any]] = []
        for p in items:
            if p.suffix.lower() != ".pdf" or not p.exists():
                self.logger.info("Redaction demo handles PDFs only in this sample.", extra={"path": str(p)})
                continue
            reader = PdfReader(str(p))
            writer = PdfWriter()
            for _ in reader.pages:
                packet = BytesIO()
                c = canvas.Canvas(packet, pagesize=letter)
                c.setFillColor(black)
                c.rect(0, 730, 612, 20, stroke=0, fill=1)
                c.save()
                packet.seek(0)
                overlay_page = PdfReader(packet).pages[0]
                page = reader.pages[0]
                page.merge_page(overlay_page)
                writer.add_page(page)
            out = outdir / f"redacted_{p.name}"
            with out.open("wb") as f:
                writer.write(f)
            redacted_list.append({"filename": out.name, "path": str(out), "download": f"/download/{out.name}"})
        context["redacted"] = redacted_list
        return context
