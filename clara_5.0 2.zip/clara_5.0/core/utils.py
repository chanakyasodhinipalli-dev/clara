from __future__ import annotations
from pathlib import Path
import mimetypes, re

def detect_mime(path: Path) -> str:
    mt, _ = mimetypes.guess_type(str(path))
    return mt or "application/octet-stream"

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".tiff", ".tif", ".bmp"}
PDF_EXT = {".pdf"}
DOCX_EXT = {".docx"}
PPTX_EXT = {".pptx"}
XLSX_EXT = {".xlsx"}

def is_image(path: Path) -> bool:
    return path.suffix.lower() in IMAGE_EXT

def is_pdf(path: Path) -> bool:
    return path.suffix.lower() in PDF_EXT

def is_office(path: Path) -> bool:
    return path.suffix.lower() in (DOCX_EXT | PPTX_EXT | XLSX_EXT)

def safe_filename(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", name)
