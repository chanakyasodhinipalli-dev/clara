from __future__ import annotations
import logging, json, sys, os
from logging import Logger

class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "level": record.levelname,
            "time": self.formatTime(record, datefmt="%Y-%m-%dT%H:%M:%S"),
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)
        base = logging.LogRecord(name="", level=0, pathname="", lineno=0, msg="", args=(), exc_info=None).__dict__.keys()
        extra_keys = set(record.__dict__.keys()) - set(base)
        for k in extra_keys:
            if k.startswith("_"):
                continue
            try:
                json.dumps(record.__dict__[k])
                payload[k] = record.__dict__[k]
            except Exception:
                payload[k] = str(record.__dict__[k])
        return json.dumps(payload, ensure_ascii=False)

def get_logger(name: str = "clara") -> Logger:
    level = os.getenv("CLARA_LOG_LEVEL", "INFO").upper()
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter())
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.addHandler(handler)
    logger.setLevel(level)
    logger.propagate = False
    return logger
