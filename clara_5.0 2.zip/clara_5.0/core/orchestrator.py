from __future__ import annotations
from pathlib import Path
from typing import Dict, Any, List
from concurrent.futures import ThreadPoolExecutor, as_completed
from .logger import get_logger
from .config import AppConfig
from .prompt_manager import PromptManager
from importlib import import_module

logger = get_logger("clara.orchestrator")

AGENT_MAP = {
    "preprocessor": "agents.preprocessor:PreprocessorAgent",
    "splitter": "agents.splitter:SplitterAgent",
    "merger": "agents.merger:MergerAgent",
    "context": "agents.context_agent:ContextAgent",
    "translation": "agents.translation:TranslationAgent",
    "summarization": "agents.summarization:SummarizationAgent",
    "classification": "agents.classification:ClassificationAgent",
    "metadata": "agents.metadata:MetadataAgent",
    "grouping": "agents.grouping:GroupingAgent",
    "converted": "agents.converted:ConvertedAgent",
    "ocr": "agents.ocr:OCRAgent",
    "redaction": "agents.redaction:RedactionAgent",
}

def load_agent(path: str, cfg: AppConfig, prompt: PromptManager):
    mod_name, cls_name = path.split(":")
    mod = import_module(mod_name)
    cls = getattr(mod, cls_name)
    return cls(cfg, prompt)

class Orchestrator:
    def __init__(self, cfg: AppConfig) -> None:
        self.cfg = cfg
        self.prompt = PromptManager(cfg.ai_enabled)

    def run_workflow(self, workflow: List[str], items: List[Path]) -> Dict[str, Any]:
        ctx: Dict[str, Any] = {"items": items, "artifacts": [], "groups": []}
        for step in workflow:
            if step not in AGENT_MAP:
                raise ValueError(f"Unknown workflow step: {step}")
            agent = load_agent(AGENT_MAP[step], self.cfg, self.prompt)
            logger.info("Running step", extra={"step": step, "count": len(ctx.get("items", []))})
            if step == "context" and self.cfg.allow_parallel:
                results = []
                with ThreadPoolExecutor() as ex:
                    futures = [ex.submit(agent.process, item) for item in ctx["items"]]
                    for fut in as_completed(futures):
                        results.append(fut.result())
                ctx["context_results"] = results
                ctx = agent.run(ctx)
            else:
                ctx = agent.run(ctx)
        return ctx
