from __future__ import annotations
from typing import Dict, Any
from .logger import get_logger

logger = get_logger("clara.prompt")

class PromptManager:
    def __init__(self, ai_enabled: bool = False) -> None:
        self.ai_enabled = ai_enabled

    def run_prompt(self, purpose: str, context: Dict[str, Any]) -> Dict[str, Any]:
        if not self.ai_enabled:
            return {"mode": "rule_fallback", "purpose": purpose, "result": None}
        logger.warning("AI mode enabled but no provider configured; falling back to rules.", extra={"purpose": purpose})
        return {"mode": "ai_fallback_to_rules", "purpose": purpose, "result": None}
