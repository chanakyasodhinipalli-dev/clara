from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict
import yaml, json

@dataclass
class AppConfig:
    ai_enabled: bool = False
    outputs_dir: Path = Path("outputs")
    temp_dir: Path = Path("temp")
    ocr_lang: str = "eng"
    allow_parallel: bool = True

    @staticmethod
    def from_file(path: Path) -> "AppConfig":
        if path.suffix.lower() in {".yaml", ".yml"}:
            data: Dict[str, Any] = yaml.safe_load(path.read_text())
        else:
            data = json.loads(path.read_text())
        return AppConfig(
            ai_enabled=bool(data.get("ai_enabled", False)),
            outputs_dir=Path(data.get("outputs_dir", "outputs")),
            temp_dir=Path(data.get("temp_dir", "temp")),
            ocr_lang=str(data.get("ocr_lang", "eng")),
            allow_parallel=bool(data.get("allow_parallel", True)),
        )

def load_workflows(path: Path) -> Dict[str, Any]:
    if path.suffix.lower() in {".yaml", ".yml"}:
        return yaml.safe_load(path.read_text())
    return json.loads(path.read_text())
