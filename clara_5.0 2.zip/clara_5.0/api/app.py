from __future__ import annotations
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import JSONResponse, FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi import Request
from pathlib import Path
from core.config import AppConfig, load_workflows
from core.orchestrator import Orchestrator
from core.logger import get_logger

app = FastAPI(title="Clara 5.0 API")
logger = get_logger("clara.api")

app.mount("/static", StaticFiles(directory="ui/static"), name="static")
templates = Jinja2Templates(directory="ui/templates")

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/api/upload")
async def upload(file: UploadFile = File(...), workflow: str = Form("full_pipeline")):
    cfg = AppConfig.from_file(Path("config/app.yaml"))
    workflows = load_workflows(Path("config/workflows.yaml"))
    wf = workflows.get(workflow, [])
    temp_dir = cfg.temp_dir
    temp_dir.mkdir(parents=True, exist_ok=True)
    dest = temp_dir / file.filename
    dest.write_bytes(await file.read())
    orch = Orchestrator(cfg)
    ctx = orch.run_workflow(wf, [dest])
    return JSONResponse(ctx)

@app.post("/api/process-folder")
async def process_folder(folder: str = Form(...), workflow: str = Form("full_pipeline")):
    cfg = AppConfig.from_file(Path("config/app.yaml"))
    workflows = load_workflows(Path("config/workflows.yaml"))
    wf = workflows.get(workflow, [])
    p = Path(folder)
    items = [x for x in p.iterdir() if x.is_file()]
    orch = Orchestrator(cfg)
    ctx = orch.run_workflow(wf, items)
    return JSONResponse(ctx)

@app.get("/download/{filename}")
async def download(filename: str):
    path = Path("outputs") / filename
    if not path.exists():
        return JSONResponse({"error": "File not found"}, status_code=404)
    return FileResponse(str(path), filename=filename)
