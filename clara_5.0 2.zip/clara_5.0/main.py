from __future__ import annotations
from pathlib import Path
import typer, json
from core.config import AppConfig, load_workflows
from core.orchestrator import Orchestrator

cli = typer.Typer(help="Clara 5.0 CLI")

@cli.command()
def run(workflow: str = typer.Argument("full_pipeline"), folder: str = typer.Option(None), file: str = typer.Option(None)):
    cfg = AppConfig.from_file(Path("config/app.yaml"))
    workflows = load_workflows(Path("config/workflows.yaml"))
    wf = workflows.get(workflow, [])
    items = []
    if folder:
        items = [p for p in Path(folder).iterdir() if p.is_file()]
    elif file:
        items = [Path(file)]
    else:
        raise typer.BadParameter("Provide --folder or --file.")
    orch = Orchestrator(cfg)
    ctx = orch.run_workflow(wf, items)
    print(json.dumps(ctx, indent=2, default=str))

if __name__ == "__main__":
    cli()
