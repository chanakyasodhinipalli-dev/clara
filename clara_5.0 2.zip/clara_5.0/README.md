# Clara 5.0 – Agentic AI Workflow Orchestrator

Enterprise-grade, self-contained Python project for multi-lingual & multi-contextual document processing.

## Features
- Orchestrated workflows with parallel steps
- Agents: preprocessor, splitter, merger, context, translation, summarization, classification, metadata, grouping, converted, OCR, redaction
- API (FastAPI) + lightweight UI with upload, preview, JSON output & downloads
- CLI via Typer
- Unit tests (pytest)
- Works on Windows & Linux

## Setup
1. **Python 3.11+** required.
2. Create venv and install deps:
   ```bash
   python -m venv .venv && . .venv/bin/activate  # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   ```
3. (Optional) Add Tesseract and Poppler to PATH for OCR/PDF image conversion.
4. Run API:
   ```bash
   python run_api.py
   ```
5. Open UI at `http://localhost:8000`.

## CLI
```bash
python main.py run full_pipeline --folder samples
```

## Config
- `config/app.yaml` toggles `ai_enabled`, paths, OCR lang.
- `config/workflows.yaml` defines workflows.
- `config/classification_rules.csv` controls rule-based classification.

## Notes
- AI paths fall back to rules unless you wire a provider.
- Redaction is a visual overlay demo, not content stream redaction.
- Office-doc conversion uses simple text export unless LibreOffice is integrated.

## Testing
```bash
pytest -q
```
