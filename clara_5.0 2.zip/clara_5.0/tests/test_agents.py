from core.config import AppConfig
from core.prompt_manager import PromptManager
from agents.grouping import GroupingAgent
from agents.context_agent import ContextAgent
from pathlib import Path

def test_grouping(tmp_path):
    cfg = AppConfig()
    prompt = PromptManager(False)
    ctx_agent = ContextAgent(cfg, prompt)
    items = []
    for name in ['aadhaar_front.pdf', 'pan_card.pdf', 'bank_statement.pdf']:
        p = tmp_path / name
        p.write_text('dummy')
        items.append(p)
    ctx = {'items': items}
    ctx = ctx_agent.run(ctx)
    grp = GroupingAgent(cfg, prompt).run(ctx)
    assert 'groups' in grp
    assert any(g['group_id'] == 1 for g in grp['groups'])
