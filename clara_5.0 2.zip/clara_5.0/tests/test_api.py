from fastapi.testclient import TestClient
from api.app import app

def test_index():
    client = TestClient(app)
    r = client.get('/')
    assert r.status_code == 200

def test_upload_route_exists():
    client = TestClient(app)
    r = client.post('/api/process-folder', data={'folder': 'samples', 'workflow': 'preprocessor_only'})
    assert r.status_code == 200
