const form = document.getElementById('uploadForm');
const jsonOut = document.getElementById('jsonOut');
const downloads = document.getElementById('downloads');
const pdfPreview = document.getElementById('pdfPreview');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(form);
  const res = await fetch('/api/upload', { method: 'POST', body: fd });
  const data = await res.json();
  jsonOut.textContent = JSON.stringify(data, null, 2);
  downloads.innerHTML = '';
  const dlKeys = ['split', 'merged', 'converted', 'ocr_texts', 'redacted'];
  dlKeys.forEach(k => {
    if (data[k]) {
      if (Array.isArray(data[k])) {
        data[k].forEach(x => addLink(x));
      } else {
        addLink(data[k]);
      }
    }
  });
  const firstPdf = document.querySelector('#downloads a[data-ext="pdf"]');
  if (firstPdf) pdfPreview.src = firstPdf.href;
});

function addLink(obj) {
  const a = document.createElement('a');
  a.href = obj.download || (`/download/${obj.filename}`);
  a.textContent = obj.filename || obj.text_path || 'download';
  const ext = (a.textContent.split('.').pop() || '').toLowerCase();
  a.dataset.ext = ext;
  a.download = a.textContent;
  downloads.appendChild(a);
}
