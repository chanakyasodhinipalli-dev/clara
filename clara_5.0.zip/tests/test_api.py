from __future__ import annotations
from fastapi.testclient import TestClient
from run_api import app

client = TestClient(app)

def test_index():
    r = client.get('/')
    assert r.status_code == 200

def test_upload_sample(tmp_path):
    # upload the sample file
    with open('samples/invoice_en.pdf','rb') as f:
        files = [('files', ('invoice_en.pdf', f, 'application/pdf'))]
        r = client.post('/api/upload', data={'workflow':'preprocessor_only'}, files=files)
        assert r.status_code == 200
