from __future__ import annotations
import os, json
from core.orchestrator import Orchestrator

def test_full_pipeline_runs(tmp_path):
    # copy sample to temp
    src = os.path.join('samples','invoice_en.pdf')
    dst = tmp_path / 'invoice_en.pdf'
    with open(src,'rb') as r, open(dst,'wb') as w:
        w.write(r.read())
    orch = Orchestrator()
    res = orch.run_workflow('full_pipeline', [str(dst)])
    assert 'contexts' in res
    assert 'groups' in res

def test_splitter_only(tmp_path):
    src = os.path.join('samples','multipage.pdf')
    dst = tmp_path / 'multipage.pdf'
    with open(src,'rb') as r, open(dst,'wb') as w:
        w.write(r.read())
    orch = Orchestrator()
    res = orch.run_workflow('splitter_only', [str(dst)])
    assert len(res.get('pages', [])) == 3
