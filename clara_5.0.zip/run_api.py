from __future__ import annotations
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.templating import Jinja2Templates
import os

from api.routes import router as api_router
from core.logger import get_logger

app = FastAPI(title="Clara 5.0")
log = get_logger("server")

app.mount("/static", StaticFiles(directory="ui/static"), name="static")
templates = Jinja2Templates(directory="ui/templates")

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/download/{filename}")
def download(filename: str):
    path = os.path.join("outputs", filename)
    if not os.path.exists(path):
        path = os.path.join("temp","uploads", filename)
    return FileResponse(path)

app.include_router(api_router, prefix="/api")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
