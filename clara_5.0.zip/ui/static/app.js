const form = document.getElementById('uploadForm');
const fileInput = document.getElementById('fileInput');
const jsonOutput = document.getElementById('jsonOutput');
const downloads = document.getElementById('downloads');
const pdfPreview = document.getElementById('pdfPreview');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const wf = document.getElementById('workflow').value;
  const fd = new FormData();
  fd.append('workflow', wf);
  const files = fileInput.files;
  for (let i=0; i<files.length; i++) fd.append('files', files[i]);

  const resp = await fetch('/api/upload', { method: 'POST', body: fd });
  const data = await resp.json();
  jsonOutput.textContent = JSON.stringify(data, null, 2);

  downloads.innerHTML = '';
  if (data.merged && data.merged.download) {
    const a = document.createElement('a');
    a.href = data.merged.download;
    a.textContent = 'Download merged';
    downloads.appendChild(a);
    pdfPreview.src = data.merged.download;
  }
  if (data.redacted) {
    data.redacted.forEach(p => {
      const a = document.createElement('a');
      const fn = p.split('/').pop();
      a.href = '/download/' + fn;
      a.textContent = 'Download ' + fn;
      downloads.appendChild(a);
    });
  }
});
