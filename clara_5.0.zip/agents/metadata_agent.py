from __future__ import annotations
from typing import Dict, Any
from core.logger import get_logger
import os

class MetadataAgent:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.log = get_logger("agent.metadata")

    def execute(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        metas = []
        for p in ctx.get("pages", ctx.get("inputs", [])):
            size = os.path.getsize(p) if os.path.exists(p) else 0
            metas.append({"path": p, "filename": os.path.basename(p), "size": size})
        ctx["metadata"] = metas
        return ctx
