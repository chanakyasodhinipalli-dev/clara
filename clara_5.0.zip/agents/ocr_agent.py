from __future__ import annotations
from typing import Dict, Any, List, Optional
from core.logger import get_logger
import os

class OCRAgent:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.log = get_logger("agent.ocr")
        try:
            import pytesseract # noqa
            self.available = True
        except Exception:
            self.available = False

    def execute(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        results = []
        if not self.available:
            self.log.warning("Tesseract not available. OCR skipped.")
            ctx["ocr"] = results
            return ctx
        import pytesseract
        from PIL import Image
        for p in ctx.get("pages", ctx.get("inputs", [])):
            if p.lower().endswith((".png",".jpg",".jpeg",".tif",".tiff")) and os.path.exists(p):
                try:
                    text = pytesseract.image_to_string(Image.open(p))
                except Exception as e:
                    self.log.error("OCR error on %s: %s", p, e)
                    text = ""
                results.append({"path": p, "text": text})
        ctx["ocr"] = results
        return ctx
