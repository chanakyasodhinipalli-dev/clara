from __future__ import annotations
from typing import Dict, Any, List
from core.logger import get_logger

class ContextAgent:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.log = get_logger("agent.context")

    def execute(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        pages = ctx.get("pages") or ctx.get("inputs", [])
        contexts = []
        last_context_id = ""
        for i, p in enumerate(pages):
            # Simple rule: same filename stem => same context
            stem = p.split("_p")[0]
            ctx_id = stem
            continuation = (ctx_id == last_context_id)
            contexts.append({"page": p, "context_id": ctx_id, "continuation": continuation})
            last_context_id = ctx_id
        ctx["contexts"] = contexts
        return ctx
