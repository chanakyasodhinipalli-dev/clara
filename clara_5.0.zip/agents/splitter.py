from __future__ import annotations
from typing import Dict, Any, List
from core.logger import get_logger
from core.utils import gen_id
from PyPDF2 import PdfReader, PdfWriter
from PIL import Image
import os

class SplitterAgent:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.log = get_logger("agent.split")

    def _split_pdf(self, path: str, out_dir: str) -> List[str]:
        reader = PdfReader(path)
        outputs = []
        for i, _ in enumerate(reader.pages):
            writer = PdfWriter()
            writer.add_page(reader.pages[i])
            out_path = os.path.join(out_dir, f"{os.path.splitext(os.path.basename(path))[0]}_p{i+1}.pdf")
            with open(out_path, "wb") as f:
                writer.write(f)
            outputs.append(out_path)
        return outputs

    def _split_tiff(self, path: str, out_dir: str) -> List[str]:
        im = Image.open(path)
        outputs = []
        try:
            i = 0
            while True:
                im.seek(i)
                out_path = os.path.join(out_dir, f"{os.path.splitext(os.path.basename(path))[0]}_p{i+1}.tiff")
                im.save(out_path)
                outputs.append(out_path)
                i += 1
        except EOFError:
            pass
        return outputs

    def execute(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        out_dir = self.cfg.paths.get("outputs","outputs")
        os.makedirs(out_dir, exist_ok=True)
        pieces: List[str] = []
        for path in ctx.get("inputs", []):
            if path.lower().endswith(".pdf"):
                pieces += self._split_pdf(path, out_dir)
            elif path.lower().endswith((".tif",".tiff")):
                pieces += self._split_tiff(path, out_dir)
            else:
                self.log.info("No splitting needed for %s", path)
                pieces.append(path)
        ctx["pages"] = pieces
        return ctx
