from __future__ import annotations
from typing import Dict, Any, List
from core.logger import get_logger
import os

class GroupingAgent:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.log = get_logger("agent.group")

    def execute(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        contexts = ctx.get("contexts", [])
        groups = {}
        for c in contexts:
            groups.setdefault(c["context_id"], []).append(c["page"])
        out = []
        for gid, pages in groups.items():
            out.append({"group_id": os.path.basename(gid), "pages": pages})
        ctx["groups"] = out
        return ctx
