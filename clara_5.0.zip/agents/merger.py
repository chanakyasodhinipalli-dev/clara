from __future__ import annotations
from typing import Dict, Any, List
from core.logger import get_logger
from PyPDF2 import PdfMerger, PdfReader, PdfWriter
from PIL import Image
import os

class MergerAgent:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.log = get_logger("agent.merge")

    def _merge_pdfs(self, inputs: List[str], out_path: str) -> str:
        merger = PdfMerger()
        for p in inputs:
            merger.append(p)
        with open(out_path, "wb") as f:
            merger.write(f)
        merger.close()
        return out_path

    def _merge_tiffs(self, inputs: List[str], out_path: str) -> str:
        images = [Image.open(p).convert("RGB") for p in inputs]
        head, *tail = images
        head.save(out_path, save_all=True, append_images=tail)
        return out_path

    def execute(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        out_dir = self.cfg.paths.get("outputs","outputs")
        os.makedirs(out_dir, exist_ok=True)
        inputs = ctx.get("pages") or ctx.get("inputs") or []
        pdfs = [p for p in inputs if p.lower().endswith(".pdf")]
        tiffs = [p for p in inputs if p.lower().endswith((".tif",".tiff"))]
        out_file = os.path.join(out_dir, "merged.pdf" if pdfs else "merged.tiff")
        if pdfs:
            path = self._merge_pdfs(pdfs, out_file)
        elif tiffs:
            path = self._merge_tiffs(tiffs, out_file)
        else:
            path = inputs[0] if inputs else ""
        ctx["merged"] = {"path": path, "download": f"/download/{os.path.basename(path)}" if path else ""}
        return ctx
