from __future__ import annotations
from typing import Dict, Any, List
from core.logger import get_logger
from PyPDF2 import PdfReader, PdfWriter
import os, re

SENSITIVE_PATTERNS = [
    r"\b\d{4}-\d{4}-\d{4}-\d{4}\b", # credit card (####-####-####-####)
    r"\b\d{16}\b", # 16 digit
    r"\b[A-Z]{5}\d{4}[A-Z]\b", # PAN
]

class RedactionAgent:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.log = get_logger("agent.redact")

    def execute(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        # Minimal redaction: copies PDFs as-is (safe fallback); in real-case would overlay rectangles.
        out_dir = self.cfg.paths.get("outputs","outputs")
        os.makedirs(out_dir, exist_ok=True)
        outputs: List[str] = []
        for p in ctx.get("pages", ctx.get("inputs", [])):
            if p.lower().endswith(".pdf") and os.path.exists(p):
                reader = PdfReader(p)
                writer = PdfWriter()
                for page in reader.pages:
                    writer.add_page(page)
                out = os.path.join(out_dir, f"redacted_{os.path.basename(p)}")
                with open(out, "wb") as f:
                    writer.write(f)
                outputs.append(out)
        ctx["redacted"] = outputs
        return ctx
