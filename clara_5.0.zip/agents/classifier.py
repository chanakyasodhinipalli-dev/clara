from __future__ import annotations
from typing import Dict, Any, List
from core.logger import get_logger
from core.config import load_classification_rules

class ClassificationAgent:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.log = get_logger("agent.classify")
        self.rules = load_classification_rules()

    def execute(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        results = []
        pages = ctx.get("pages", ctx.get("inputs", []))
        for p in pages:
            label = "UNK"
            for r in self.rules:
                kws = [k.strip() for k in r["keywords"].split(",")]
                # heuristic: filename contains any keyword token
                if any(k.replace(" ","_") in p.lower() for k in kws):
                    label = r["code"]
                    break
            results.append({"path": p, "label": label})
        ctx["classes"] = results
        return ctx
