from __future__ import annotations
from typing import Dict, Any
from core.logger import get_logger

class SummarizerAgent:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.log = get_logger("agent.summarize")

    def execute(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        # Rule-mode: filenames as summaries
        summaries = [{"path": p, "summary_native": p, "summary_en": p} for p in ctx.get("pages", [])]
        ctx["summaries"] = summaries
        return ctx
