from __future__ import annotations
from typing import Dict, Any, List
from core.logger import get_logger
from core.utils import detect_mime, sha256_of_file
from langdetect import detect_langs

LANG_MAP = {
    "en": "English", "hi": "Hindi", "ta": "Tamil", "te":"Telugu", "bn":"Bengali",
    "mr":"Marathi","gu":"Gujarati","ml":"Malayalam","kn":"Kannada","pa":"Punjabi"
}

class PreprocessorAgent:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.log = get_logger("agent.preprocess")

    def execute(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        outputs = []
        for path in ctx["inputs"]:
            mime = detect_mime(path)
            valid = mime in self.cfg.allowed_mime_types
            info = {
                "path": path, "mime": mime, "valid": valid,
                "sha256": sha256_of_file(path),
                "languages": [], "multi_context": False
            }
            if not valid:
                self.log.warning("Unsupported MIME type: %s", mime)
            # Heuristic language detection from filename text cue
            text_hint = path.lower()
            langs = []
            try:
                langs = [p.lang for p in detect_langs(text_hint)]
            except Exception:
                langs = []
            info["languages"] = [{"code": l, "name": LANG_MAP.get(l, l)} for l in langs[:2]]
            info["multi_context"] = False
            outputs.append(info)
        ctx["artifacts"] = outputs
        return ctx
