from __future__ import annotations
from typing import Dict, Any, List
from core.logger import get_logger
from PyPDF2 import PdfWriter
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
import os

class ConverterAgent:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.log = get_logger("agent.convert")

    def _image_to_pdf(self, img_path: str, out_path: str) -> str:
        img = Image.open(img_path)
        img = img.convert("RGB")
        img.save(out_path)
        return out_path

    def _docx_to_pdf(self, docx_path: str, out_path: str) -> str:
        from docx import Document
        doc = Document(docx_path)
        c = canvas.Canvas(out_path, pagesize=A4)
        width, height = A4
        y = height - 50
        for para in doc.paragraphs:
            text = para.text
            if not text:
                y -= 20
                continue
            for line in self._wrap_text(text, 90):
                c.drawString(40, y, line)
                y -= 16
                if y < 60:
                    c.showPage()
                    y = height - 50
        c.save()
        return out_path

    def _wrap_text(self, text: str, width: int):
        words = text.split()
        line = []
        count = 0
        for w in words:
            if count + len(w) + 1 > width:
                yield " ".join(line)
                line = [w]
                count = len(w)
            else:
                line.append(w)
                count += len(w) + 1
        if line:
            yield " ".join(line)

    def execute(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        out_dir = self.cfg.paths.get("outputs","outputs")
        os.makedirs(out_dir, exist_ok=True)
        outputs: List[str] = []
        for p in ctx.get("inputs", []):
            stem = os.path.splitext(os.path.basename(p))[0]
            if p.lower().endswith((".png",".jpg",".jpeg",".tif",".tiff")):
                out_path = os.path.join(out_dir, f"{stem}.pdf")
                outputs.append(self._image_to_pdf(p, out_path))
            elif p.lower().endswith(".docx"):
                out_path = os.path.join(out_dir, f"{stem}.pdf")
                outputs.append(self._docx_to_pdf(p, out_path))
        ctx["converted"] = outputs
        return ctx
