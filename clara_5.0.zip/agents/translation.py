from __future__ import annotations
from typing import Dict, Any
from core.logger import get_logger

class TranslationAgent:
    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self.log = get_logger("agent.translate")

    def execute(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        # Rule-mode: no-op translation (offline safe)
        texts = []
        for p in ctx.get("pages", ctx.get("inputs", [])):
            texts.append({"path": p, "text_en": None})
        ctx["translations"] = texts
        return ctx
