# Clara 5.0 — Agentic AI Workflow Orchestrator Framework

An enterprise-grade, end-to-end Python project for **multi-lingual, multi-contextual document processing**.  
Self-contained, runnable on **Windows & Linux**. AI/LLM features are config-gated; rule-based fallbacks always available.

## ✨ Features
- FastAPI backend + HTML UI (Jinja templates).
- Orchestrator-driven workflows (sequential/parallel) from YAML config.
- Agents for pre-processing, split/merge, context detection, translation, summarization, classification, metadata extraction, grouping, conversion, OCR.
- File inputs: **PNG, JPEG, TIFF (single/multi), PDF, DOCX**.
- Enterprise logging, type hints, graceful fallbacks (offline safe).

## 📦 Setup
1. **Python 3.11+** is required.
2. Create a virtual environment and install dependencies:
   ```bash
   python -m venv .venv
   .venv/Scripts/activate    # on Windows
   source .venv/bin/activate # on Linux/Mac
   pip install -r requirements.txt
   ```
3. Install system binaries and add to PATH (if available):
   - **Tesseract OCR** (for OCR)
   - **Poppler** (for `pdf2image`)
   The app will auto-fallback if not available.

## 🚀 Run
```bash
python run_api.py
```
Open http://localhost:8000 and use the UI.

## 🧠 AI/LLM Usage
AI is disabled by default. Enable per-agent in `config/app.yaml`:
```yaml
ai_enabled: true
ai:
  provider: "mock"
  max_tokens: 512
```
When disabled, deterministic logic is used.

## 🧪 Testing
```bash
pytest -q
```

## 📂 Project Layout
See repository tree in the root request. Logs and outputs will be created at runtime.
