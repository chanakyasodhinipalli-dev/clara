from __future__ import annotations
from typing import Dict
from core.config import load_prompts

class PromptManager:
    def __init__(self) -> None:
        self.prompts = load_prompts().get("prompts", {})

    def get(self, name: str) -> str:
        return self.prompts.get(name, "")
