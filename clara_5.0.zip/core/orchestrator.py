from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, Any, List
import os, json

from core.logger import get_logger
from core.config import load_app_config, load_workflows
from core.utils import ensure_dirs

from agents.preprocessor import PreprocessorAgent
from agents.splitter import SplitterAgent
from agents.merger import MergerAgent
from agents.context_agent import ContextAgent
from agents.translation import TranslationAgent
from agents.summarizer import SummarizerAgent
from agents.classifier import ClassificationAgent
from agents.metadata_agent import MetadataAgent
from agents.grouping import GroupingAgent
from agents.converter import ConverterAgent
from agents.ocr_agent import OCRAgent
from agents.redactor import RedactionAgent

class Orchestrator:
    def __init__(self) -> None:
        self.cfg = load_app_config()
        self.workflows = load_workflows().get("workflows", {})
        ensure_dirs(self.cfg.paths.get("outputs","outputs"), self.cfg.paths.get("temp","temp"))
        self.log = get_logger("orchestrator")

        # Initialize agents
        self.agents = {
            "preprocess": PreprocessorAgent(self.cfg),
            "split": SplitterAgent(self.cfg),
            "merge": MergerAgent(self.cfg),
            "context": ContextAgent(self.cfg),
            "translate": TranslationAgent(self.cfg),
            "summarize": SummarizerAgent(self.cfg),
            "classify": ClassificationAgent(self.cfg),
            "metadata": MetadataAgent(self.cfg),
            "group": GroupingAgent(self.cfg),
            "convert": ConverterAgent(self.cfg),
            "ocr": OCRAgent(self.cfg),
            "redact": RedactionAgent(self.cfg),
        }

    def run_workflow(self, workflow_name: str, inputs: List[str]) -> Dict[str, Any]:
        if workflow_name not in self.workflows:
            raise ValueError(f"Unknown workflow: {workflow_name}")
        steps: List[str] = self.workflows[workflow_name]["steps"]
        self.log.info(f"Running workflow '{workflow_name}' with steps: {steps}")
        context: Dict[str, Any] = {"inputs": inputs, "artifacts": [], "pages": [], "groups": []}

        for step in steps:
            agent = self.agents[step]
            self.log.info(f"Executing step: {step}")
            context = agent.execute(context)
        return context
