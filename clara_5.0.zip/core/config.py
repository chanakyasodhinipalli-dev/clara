from __future__ import annotations
from pydantic import BaseModel, Field
from typing import List, Dict, Any
import yaml, os

class AppConfig(BaseModel):
    app_name: str
    version: str
    debug: bool = False
    ai_enabled: bool = False
    concurrency: Dict[str, int] = Field(default_factory=lambda: {"max_workers": 2})
    paths: Dict[str, str] = Field(default_factory=dict)
    allowed_mime_types: List[str] = Field(default_factory=list)
    ai: Dict[str, Any] = Field(default_factory=dict)
    ui: Dict[str, Any] = Field(default_factory=dict)

def load_yaml(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def load_app_config() -> AppConfig:
    data = load_yaml(os.path.join("config","app.yaml"))
    return AppConfig(**data)

def load_workflows() -> dict:
    return load_yaml(os.path.join("config","workflows.yaml"))

def load_prompts() -> dict:
    return load_yaml(os.path.join("config","prompts.yaml"))

def load_classification_rules() -> List[Dict[str, str]]:
    import csv
    rules = []
    with open(os.path.join("config","classification_rules.csv"), newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            rules.append(row)
    return rules
