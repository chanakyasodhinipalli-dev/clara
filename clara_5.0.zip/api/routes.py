from __future__ import annotations
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from typing import List
import os, shutil

from core.orchestrator import Orchestrator
from core.logger import get_logger

router = APIRouter()
log = get_logger("api")

@router.post("/process-folder")
def process_folder(folder_path: str = Form(...), workflow: str = Form("full_pipeline")):
    if not os.path.isdir(folder_path):
        raise HTTPException(status_code=400, detail="Invalid folder")
    files = [os.path.join(folder_path, f) for f in os.listdir(folder_path)]
    orch = Orchestrator()
    result = orch.run_workflow(workflow, files)
    return result

@router.post("/upload")
async def upload(workflow: str = Form("full_pipeline"), files: List[UploadFile] = File(...)):
    out_dir = "temp/uploads"
    os.makedirs(out_dir, exist_ok=True)
    saved = []
    for f in files:
        path = os.path.join(out_dir, f.filename)
        with open(path, "wb") as w:
            shutil.copyfileobj(f.file, w)
        saved.append(path)
    orch = Orchestrator()
    result = orch.run_workflow(workflow, saved)
    return result
