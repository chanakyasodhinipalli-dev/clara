from __future__ import annotations
import argparse, json
from core.orchestrator import Orchestrator

def main():
    ap = argparse.ArgumentParser(description="Clara 5.0 Orchestrator CLI")
    ap.add_argument("--workflow", default="full_pipeline")
    ap.add_argument("inputs", nargs="+", help="File paths")
    args = ap.parse_args()
    orch = Orchestrator()
    result = orch.run_workflow(args.workflow, args.inputs)
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
