# Excel Folder → JSON & YAML Exporter (Python)

A simple, production-friendly CLI that scans an **input folder** for Excel workbooks and exports every sheet to **JSON** and **YAML** (YAML files have extension `.yaml`).

> ✅ If you actually meant **YARN** files instead of YAML, clarify the target format. This tool currently emits **YAML** (industry-standard).

---

## Features
- Supports `.xlsx` natively (openpyxl). Legacy `.xls` via pandas+xlrd (optional).
- Auto-detects the header row (first row with ≥2 non-empty cells) **or** use a fixed header row with `--header-mode row --header-row 1`.
- Normalizes values:
  - Dates → ISO 8601 (`YYYY-MM-DD` / `YYYY-MM-DDTHH:MM:SS`)
  - Empty strings → `null`
  - Keeps numbers/bools as-is
- Skips completely empty rows.
- Deduplicates duplicate column names (`name`, `name_2`, …).
- Writes a master index (`index.json` / `index.yaml`) and per-workbook `_index` files.
- Include/exclude via glob patterns.

---

## Install

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Usage

```bash
python excel_folder_to_json_yaml.py --input ./sheets --output ./out
# Force header row 1
python excel_folder_to_json_yaml.py --input ./sheets --output ./out --header-mode row --header-row 1
# Only .xlsx, ignore temp files
python excel_folder_to_json_yaml.py --input ./sheets --output ./out --include "*.xlsx" --exclude "~$*"
```

**Output layout**
```
out/
  index.json
  index.yaml
  json/
    <workbook-name>/
      <sheet-name>.json
      _index.json
  yaml/
    <workbook-name>/
      <sheet-name>.yaml
      _index.yaml
```

## Notes

- Auto header detection scans the first 50 rows and picks the first row with ≥2 non-empty cells.
- For complex templates (merged headers, multi-line headers), pass `--header-mode row` and `--header-row N` for precision.
- For `.xls` files, pandas tries to use the first row as header.

## License
MIT
