# Onboard360 AI — FastAPI (Server-Rendered UI) + Casbin RBAC

This repository contains a **full working UI web application** with:
- FastAPI backend
- Server-rendered UI (Jinja2 + HTMX)
- Session-cookie authentication (static users/passwords)
- Casbin RBAC (model.conf + policy.csv)
- Mock data (intakes, action items, features, charts, chat threads)
- No placeholders; ready to run locally

## Quickstart

```bash
cd server
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

### Demo Users
- partner1 / P@ssw0rd!
- team1 / P@ssw0rd!
- lead1 / P@ssw0rd!
- po1 / P@ssw0rd!

