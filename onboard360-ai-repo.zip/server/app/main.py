from fastapi import FastAPI, Request, Form, HTTPException, Response, UploadFile, File, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
import os, json, uuid
import casbin

BASE = os.path.dirname(__file__)
DATA = os.path.join(BASE, "data")
MOCK = os.path.join(DATA, "mock")
CASBIN_DIR = os.path.join(BASE, "casbin")

with open(os.path.join(DATA, "users.json"), "r") as f:
    USERS = json.load(f)

def current_user(request: Request):
    uname = request.cookies.get("session")
    if not uname:
        return None
    for u in USERS:
        if u["username"] == uname:
            return u
    return None

enforcer = casbin.Enforcer(os.path.join(CASBIN_DIR, "model.conf"), os.path.join(CASBIN_DIR, "policy.csv"))

def require(obj: str, act: str):
    def _inner(request: Request):
        user = current_user(request)
        if not user:
            raise HTTPException(401, "Not authenticated")
        if not enforcer.enforce(user["role"], obj, act):
            raise HTTPException(403, "Forbidden")
        return user
    return _inner

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory=os.path.join(BASE, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(BASE, "templates"))

@app.get("/", response_class=HTMLResponse)
def root(request: Request):
    user = current_user(request)
    if not user:
        return templates.TemplateResponse("login.html", {"request": request, "user": None})
    # redirect based on role
    role = user["role"]
    target = "/partner/dashboard" if role=="partner_user" else \
             "/otm/dashboard" if role=="onboarding_team_member" else \
             "/lead/dashboard" if role=="icmp_leadership" else \
             "/po/dashboard"
    return RedirectResponse(target, status_code=302)

@app.post("/login")
def login(request: Request, response: Response, username: str = Form(...), password: str = Form(...)):
    user = next((u for u in USERS if u["username"]==username and u["password"]==password), None)
    if not user:
        return templates.TemplateResponse("login.html", {"request": request, "user": None, "error":"Invalid credentials"}, status_code=401)
    response = RedirectResponse("/", status_code=302)
    response.set_cookie("session", username, httponly=True, samesite="Lax")
    return response

@app.post("/logout")
def logout():
    resp = RedirectResponse("/", status_code=302)
    resp.delete_cookie("session")
    return resp

# ---- Partner ----
@app.get("/partner/dashboard", response_class=HTMLResponse)
def partner_dashboard(request: Request, user = Depends(require("partner:dashboard","read"))):
    with open(os.path.join(MOCK,"intakes.json")) as f:
        all_intakes = json.load(f)
    mine = [i for i in all_intakes if i["ownerUserId"]==user["username"]]
    counts = {
        "draft": sum(1 for i in mine if i["status"]=="draft"),
        "submitted": sum(1 for i in mine if i["status"]=="submitted"),
        "completed": sum(1 for i in mine if i["status"]=="completed"),
    }
    return templates.TemplateResponse("partner_dashboard.html", {"request":request,"user":user,"tab":"partner:dashboard","counts":counts,"intakes":mine})

@app.get("/partner/raise", response_class=HTMLResponse)
def partner_raise(request: Request, user = Depends(require("partner:raise_intake","write"))):
    return templates.TemplateResponse("partner_raise.html", {"request":request,"user":user,"tab":"partner:raise_intake"})

@app.get("/partner/track", response_class=HTMLResponse)
def partner_track(request: Request, user = Depends(require("partner:track","read"))):
    with open(os.path.join(MOCK,"intakes.json")) as f:
        all_intakes = json.load(f)
    mine = [i for i in all_intakes if i["ownerUserId"]==user["username"]]
    return templates.TemplateResponse("partner_track.html", {"request":request,"user":user,"tab":"partner:track","intakes":mine})

@app.get("/partner/actions", response_class=HTMLResponse)
def partner_actions(request: Request, user = Depends(require("partner:my_actions","read"))):
    with open(os.path.join(MOCK,"action_items.json")) as f:
        items = json.load(f)
    mine = [a for a in items if a["assignee"]==user["username"]]
    return templates.TemplateResponse("actions.html", {"request":request,"user":user,"tab":"partner:my_actions","items":mine})

# ---- OTM ----
@app.get("/otm/dashboard", response_class=HTMLResponse)
def otm_dashboard(request: Request, user = Depends(require("otm:dashboard","read"))):
    with open(os.path.join(MOCK,"action_items.json")) as f:
        items = json.load(f)
    tasks = [a for a in items if a["assignee"]==user["username"]]
    data = {"totals":{"featuresAllocated":5,"tasks":len(tasks)},"myPending":[a for a in tasks if a["status"] in ("todo","in-progress")]}
    return templates.TemplateResponse("simple_list.html", {"request":request,"user":user,"tab":"otm:dashboard","data":data})

@app.get("/otm/sprint", response_class=HTMLResponse)
def otm_sprint(request: Request, user = Depends(require("otm:sprint","read"))):
    with open(os.path.join(MOCK,"features.json")) as f: feats = json.load(f)
    return templates.TemplateResponse("simple_list.html", {"request":request,"user":user,"tab":"otm:sprint","data":feats})

@app.get("/otm/my-actions", response_class=HTMLResponse)
def otm_my_actions(request: Request, user = Depends(require("otm:my_actions","read"))):
    with open(os.path.join(MOCK,"action_items.json")) as f: items = json.load(f)
    mine = [a for a in items if a["assignee"]==user["username"]]
    return templates.TemplateResponse("actions.html", {"request":request,"user":user,"tab":"otm:my_actions","items":mine})

@app.get("/otm/team-actions", response_class=HTMLResponse)
def otm_team_actions(request: Request, user = Depends(require("otm:team_actions","read"))):
    with open(os.path.join(MOCK,"action_items.json")) as f: items = json.load(f)
    return templates.TemplateResponse("actions.html", {"request":request,"user":user,"tab":"otm:team_actions","items":items})

# ---- Leadership ----
@app.get("/lead/dashboard", response_class=HTMLResponse)
def lead_dashboard(request: Request, user = Depends(require("lead:dashboard","read"))):
    with open(os.path.join(MOCK,"charts.json")) as f: charts = json.load(f)
    return templates.TemplateResponse("lead_dashboard.html", {"request":request,"user":user,"tab":"lead:dashboard","charts":charts})

@app.get("/lead/my-actions", response_class=HTMLResponse)
def lead_my_actions(request: Request, user = Depends(require("lead:my_actions","read"))):
    with open(os.path.join(MOCK,"action_items.json")) as f: items = json.load(f)
    mine = [a for a in items if a["assignee"]==user["username"]]
    return templates.TemplateResponse("actions.html", {"request":request,"user":user,"tab":"lead:my_actions","items":mine})

# ---- Product Owner ----
@app.get("/po/dashboard", response_class=HTMLResponse)
def po_dashboard(request: Request, user = Depends(require("po:dashboard","read"))):
    with open(os.path.join(MOCK,"charts.json")) as f: charts = json.load(f)
    return templates.TemplateResponse("lead_dashboard.html", {"request":request,"user":user,"tab":"po:dashboard","charts":charts})

@app.get("/po/sprint", response_class=HTMLResponse)
def po_sprint(request: Request, user = Depends(require("po:sprint","read"))):
    with open(os.path.join(MOCK,"features.json")) as f: feats = json.load(f)
    return templates.TemplateResponse("simple_list.html", {"request":request,"user":user,"tab":"po:sprint","data":feats})

@app.get("/po/my-actions", response_class=HTMLResponse)
def po_my_actions(request: Request, user = Depends(require("po:my_actions","read"))):
    with open(os.path.join(MOCK,"action_items.json")) as f: items = json.load(f)
    mine = [a for a in items if a["assignee"]==user["username"]]
    return templates.TemplateResponse("actions.html", {"request":request,"user":user,"tab":"po:my_actions","items":mine})

@app.get("/po/team-actions", response_class=HTMLResponse)
def po_team_actions(request: Request, user = Depends(require("po:team_actions","read"))):
    with open(os.path.join(MOCK,"action_items.json")) as f: items = json.load(f)
    return templates.TemplateResponse("actions.html", {"request":request,"user":user,"tab":"po:team_actions","items":items})

# ---- Chatbot ----
THREADS_PATH = os.path.join(MOCK,"chat_threads.json")
def load_threads():
    with open(THREADS_PATH, "r") as f: return json.load(f)
def save_threads(data): 
    with open(THREADS_PATH, "w") as f: json.dump(data, f, indent=2)

@app.post("/chat/send")
def chat_send(request: Request, message: str = Form("")):
    user = current_user(request)
    if not user: raise HTTPException(401, "Not authenticated")
    threads = load_threads()
    tid = threads.get(user["username"], {"messages":[]})
    tid["messages"].append({"from":user["username"], "text": message})
    reply = "Acknowledged."
    if "create intake" in message.lower():
        reply = "Provide: summary, lob, targetVersion."
    tid["messages"].append({"from":"assistant","text":reply})
    threads[user["username"]] = tid
    save_threads(threads)
    html = "<br/>".join([f"<b>{m['from']}:</b> {m['text']}" for m in tid["messages"]])
    return HTMLResponse(html)

@app.post("/chat/upload")
def chat_upload(request: Request, file: UploadFile = File(...)):
    user = current_user(request)
    if not user: raise HTTPException(401, "Not authenticated")
    content = file.file.read()
    return HTMLResponse(f"Uploaded: {file.filename} ({len(content)} bytes)")
